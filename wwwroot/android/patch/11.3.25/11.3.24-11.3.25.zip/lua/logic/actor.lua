

require "logic/ShiftMove"
require "logic/CharBuffData"
require "logic/AssetLoadManager"
require "Config/actor_shadow_dir";
require "logic/hudex"
-- Fc Actor 接口
------------------------------------------------
-- 角色模板
local LocalCharAudioListenerEnable = false;

local ActorStage_None = 0; -- 无效阶段
local ActorStage_Appearing = 1;	-- 出生
local ActorStage_Alive = 2;		-- 或者
local ActorStage_Dead = 3;		-- 死亡躺尸阶段
local ActorStage_Disappearing = 4;	-- 消失阶段
local ActorStage_Destroyed = 5;		-- 已销毁阶段

-- 阴影
local ACTOR_SIMPLE_SHADOW_AB = "base_other";
local ACTOR_SIMPLE_SHADOW_ASSET = "yinying";

local HUD_LAYER = 17;
------------------------------------------------
Actor =
{
    -- 模型
    _transform = nil;
    _nav = nil;
    _animator = nil;
   -- _changeBodyAnimator = nil;
    _model = nil;
	_modelLoadSerial = 0;
  --  _changeBodyModel = nil;
    _layer = nil;

	_modelRoot = nil;

	_shadow = nil;
	_shadowLoadSerial = 0;
	
	--_hudTrans = nil;
	_weaponModel = nil;
	_weaponLoadSerial = 0;
   -- _needCreateHud = false;
	
	_waitLoadTime = -1;
	_needLoadModel = true;
    _collider = nil;
	_scaleValue = 1;

    _hud = nil;
    _model_dir = nil;
    _model_dir_controller = nil;

    _isBorning = false;

    _roleFightAttr = nil;
    _roleFightAttrWithoutBuff = nil;
    _baseSpeed = 1;
    _baseAnimSpeed = 1;
    _animSpeed = 1;
	_runAnimationRunSpeed = 4;--動作本身適配的一秒走多少個單位  然後根據當前速度去縮放動作速度
    -- 标识
    _actorKey = 0;
    _name = "Master";
    _title = nil;
    _prefix = "";

    -- rolekey --服务器交互相关

    -- 角色类型：
    _type = 0;-- 类型 ActorType_Player
    _camp = 0;-- 阵营
    _pro = 0; --职业
    _sex = 1;
    _isLocalEnemy = false; --是否是localchar的敌人 敌对判断在多阵营下要做一些运算 索性在改变阵营后 存下来
    _relation_id = {0,0,-1,0,0,0,0,0};
    _official = 0; --官职
              -- 配置信息
    _templateID = 0;
    _template = nil;
    _changeBodyTemplate = nil;
    _changeBodyID = 0; --当前变身id（不是typeid）


    _target = nil;-- 选中的角色

    _curAnim = "idle01";
    _animTime = 0;
    _animPriority = 0;

    -- 状态信息
    _isMoving = false;
    _isFighting = false;
    _isNaving = false;
    _isReading = false;

    _stage = ActorStage_None;

    _appearTime = 0;
    _deadTime = 0;
    _disappearTime = 0;

    -- 记录一下硬直时间，没到时间就不让干
    _moveLimitTime = 0;
    _attackLimitTime = 0;
    _normalAttackLimitTime = 0;
    _beAttackLimitTime = 0; --顺便加一个类似无敌的状态

    -- 位移差值器
    _shiftMove = nil;

    ---------------------------------
    -- 是否在目标场景
    _ifOnTargetMap = false;

    -- 模型是否加载
    _ifModelLoaded = false;

    -- 当前是否隐藏了 刷出来   但是逻辑上还是不存在滴  大于0表示隐藏
    _hideRef = 0;

    -- 是否为即使人数超过也不隐藏人物
    _fixedShowIgnoreNumber = 0;

    _isDead = false;
    -- 路径update的信息
    _routeInfo = nil;
    _routeDraw = nil; --用来调试用的
    _routeToWalk = nil; --还没ongotomap setpath会失效的 存起来先

	--当前读条的effectId,
	_readBarEffectId = nil;
	_readBarActions = nil;

    --硬直等级
    _hardLevel = 0;

    --被击范围
    _hitRange = 0;

    --状态限制
    _stateCanAttack = true; --可以普通攻击
    _stateCanCastSkill = true; --可以放技能
    _stateCanMove = true; --可以跑了
    _stateCanBeAttack = true;

    --血量监视接口 现在先给boss血条用
    _hpChangeHandler = nil;

    _footDownEventHandler = nil;
    _onTheWater = false; --當前是否在水上面走  以後可能用到這個玩意
	
	-- ai相关
	_ai = nil;

    _changeBodyInfo = nil;
	
	-- 外观相关
	_showData = nil;
	_equipEffecActiontList = nil;


    --坐骑相关
    _riding = false; --逻辑层的 是否上坐骑 
    _ridingTrans = nil; --是否加载了坐骑 就用这个判断！
    _ridingTransassetBundle = "base_sound"; --这个表示当前ridingtrans引用的名字
    _ridingTransAssetName = "";
    _ridingAnimator = nil;
    _ridingassetBundle = "base_sound"; --这个表示逻辑上的名字
    _ridingAssetName = "";
    _ridingLoadSerial = 0;
    _ridingFlying = false;
    _ridingFlyAgent = nil;
	
	--_weaponConfig = nil;
	_bodyEquipConfig = nil;
	
	_isDaemonMode = false;
	_ifHideHud = false;
	
	_autoFlying = false;
	_autoFlyEnding = false;
	
	-- 结婚称号
	_coupleTitle = nil;

    --助战模式，0表示为正常模式  1表示为助战模式
    _helpFight = 0;
    --交互状态
    _isInteraction = false;
};
Actor.__index = Actor;

function Actor.SetLocalCharAudioListenerEnable(enable)
    LocalCharAudioListenerEnable = enable;

    if LOCAL_CHAR then
        LOCAL_CHAR:SetAudioListnerEnable(enable);
    end;
end;
function Actor.New()
    local o = { _DestroyListenerList = { }; _DeadListenerList = {}; _materials = {}; _roleBaseAttr = {}; _weaponTrails = {} ;_showData = {_equipEffectList = {}}}; 
    setmetatable(o, Actor);
    return o;
end;

function Actor.Create(id, actorType, npcType, unitConfig, id2)
	local actor = Actor.New();
	return actor:InitByInfo(id, actorType, npcType, unitConfig, id2);
end;

function Actor:GetReadBarEffectId()
	return self._readBarEffectId;
end

function Actor:SetReadBarEffectId(value)
	if self._readBarEffectId ~= nil then
		self:OverReadBar();
	end
	self._readBarEffectId = value;

end

--播放被击表现, 先白色, 然后由红变回去
function Actor:PlayBeHitEffects()
	local renderList = self:GetRoleRenderList();
	if renderList == nil then return end;
	
	if self._beHitTweenList == nil then
		self._beHitTweenList = {};
	end;
	
	for k,v in pairs(renderList) do
		local render = v;
		if not IsNil(render) and not IsNil(render.material) then
			local material = render.material;
			self:PlayBlinkWhite(render);
		
			--红色的变化
			if material:HasProperty("_Color") then
				if self._beHitTweenList[render.name] == nil then
					local startVal = Vector4.New(1, 0, 0, 1);
					local endtVal = Vector4.New(1, 1, 1, 1);
					local duration = 0.8;
					local loopType = 1;
					local loopTimes = 0;
					
					self._beHitTweenList[render.name] = DoTweenHelper.DoSetShaderProperty_Vector4_Loop(material, 
						"_Color", 
						startVal, 
						endtVal, 
						duration, 
						loopType, 
						loopTimes);
					DoTweenHelper.SetAutoKill(self._beHitTweenList[render.name] , false);
					DoTweenHelper.ReplayTween(self._beHitTweenList[render.name]);
				else
					DoTweenHelper.ReplayTween(self._beHitTweenList[render.name]);
				end
			end;
		end
	end;
--	PromptPanel.ShowDebugMessage("Actor:PlayBeHitEffects()")
	
	--[[--亮度, 这个没法变成纯白色, 目前shader也不支持,先整体曝光一瞬间吧
	if material:HasProperty("_Intensity") then
		if self._originalIntensity == nil then
			self._originalIntensity = material:GetFloat("_Intensity") 
		end;
		
		if self._intensityTween == nil then
			local startVal = self._originalIntensity * 10;
			local endtVal = self._originalIntensity;
			local duration = 0.2;
			local loopType = 1;
			local loopTimes = 0;
			
			self._intensityTween = DoTweenHelper.DoSetShaderProperty_Float_Loop(material, 
				"_Intensity", 
				startVal, 
				endtVal, 
				duration, 
				loopType, 
				loopTimes);
			DoTweenHelper.SetAutoKill(self._intensityTween , false);
		else
			DoTweenHelper.ReplayTween(self._intensityTween);
		end
	end--]]
end

function Actor:GetHitRange()
    return self._hitRange;
end;

function Actor:GetCharType()
	return ActorManager.ClientTypeToSvr(self._type);

end

function Actor:GetCharKey()
	local charType = self:GetCharType();
	local charKey = {
		character_type_ = charType;
		character_id_1_ = self._roleKey.uid;
        character_id_2_ = self._roleKey.id2;
	};
	return charKey;
end

function Actor:GetUid()
	return self._roleKey.uid;
end

--读条
function Actor:OnReadBarBegin(barEffectId, time)
   
    self:StopNav(false);

    time = time or 1;
	local config = ReadBarClientGetConfig(barEffectId);
	if config == nil then
		--error(string.format("Actor:OnReadBarBegin config is nil ,barEffectId = %d,", barEffectId));
		return;
	end
	local num = #config.appears;
    if self:IsReadBar() then
	    self:OnReadBarOver();
	    
    end;
    self.__readBarActions = {};
	for i=1,num do
		local action = FcActionFactory.CreateAction(config.appears[i], self, nil, config.appears[i]);
		
		table.insert(self.__readBarActions, action);
	end;

    self._isReading = true;

    if self == LOCAL_CHAR then
        ReadBarPanel.SetReadBar(time, 0)
        ReadBarPanel.SetName(config.name or "")
        JoyStickPanel.OnLocalCharReadBar(true);

    end;

    if self._hud and self ~= LOCAL_CHAR then
        self._hud:BeginReadBar(time);
    end;
end

function Actor:OnReadBarBreak()
	self:OnReadBarOver();

end

function Actor:OnReadBarOver()
   
	if self.__readBarActions ~= nil then
		for k,v in pairs(self.__readBarActions) do
			v:Stop();

            if v._type == FcActionType_Animation and not self:IsRiding() then
                self:ResetAnimation();
            end
		end
	end

	self.__readBarActions = nil;
    self._isReading = false;

    if self == LOCAL_CHAR then
        ReadBarPanel.HideBar()
        JoyStickPanel.OnLocalCharReadBar(false);
    end;

    if self._hud and self ~= LOCAL_CHAR then
        self._hud:EndReadBar();
    end;
end

function Actor:IsReadBar()
    return self._isReading ;
end;
--/读条

function Actor:DrawBodyRange()
	local radius = self._hitRange;
	local t = FightDebug.DrawCircle(Vector3.zero, radius, 1000000, self._modelRoot)
	self._bodyRangeObject = t.lrObject;
end

-- 新增的初始化 以后会代替原来的 npcType 可以传id也可以传配置table 兼容两者
function Actor:InitByInfo(id, actorType, npcType, unitConfig, id2)
	
    self._roleKey = {
        actorType = actorType;
        uid = id;
        id2 = id2;
    };
	
	self._actorKey = ActorManager.MakeActorKey(actorType, id, id2);
    self._type = actorType;
    local typeConfig = npcType;
    local typeid = npcType;
    --print("typeConfig  "  ..  typeConfig)
    if type(typeConfig) == 'number' then
        typeConfig = NpcTypeConfig.GetConfig(typeConfig);
    end;
    if not typeConfig then
        error("can not find npc templateid"..typeid );
        return;
    end;

    self._template = typeConfig;
    self._unitConfig = unitConfig;

    self._hitRange = typeConfig.scale * typeConfig.bodyrange;
	
    if id==201300010 then
        --error("我是們")    
    end;
    local fightAttrLevel = typeConfig.level;
    if fightAttrLevel == 666  then
        if LOCAL_CHAR then
            fightAttrLevel = LOCAL_CHAR:GetLevel();
        else
            fightAttrLevel = 1;
        end
    end;
    if unitConfig and unitConfig.level and unitConfig.level > 0 then
        fightAttrLevel = unitConfig.level;
    end;

    

    local fightAttrConfig = FightAttrConfig.GetConfig(typeConfig.pro, fightAttrLevel);
    if fightAttrConfig then
        -- self._roleFightAttr =  fightAttrConfig;--ConfigTableBase.Clone(fightAttrConfig);
        --ConfigTableBase.PrintConfig(fightAttrConfig);
        if FightAttrUseSqlite3  then
            self._roleFightAttr = copyTable(fightAttrConfig);
        else
            self._roleFightAttr = ConfigTableBase.CloneConfig(fightAttrConfig);
        end
        
    else
       -- fightAttrConfig = FightAttrConfig.GetConfig(11, 1);
        self._roleFightAttr = {value_16_={}; value_32_={}; value_64_={};}
    end;

  --  self._id = id;


    --self._camp = typeConfig.camp;
    --[[self._baseActionConfig = BaseActionConfig.GetConfig(self._template.baseaction);
    local aiConfig = AIManager.GetConfig(self._template.aiid);
    if aiConfig then
        self._aiConfig = copyTable(aiConfig)
    end;



    if self._baseActionConfig then
         --设置阵营
        self._camp = self._baseActionConfig.camp;

        self._hardLevel = self._baseActionConfig.normalhard;

        self:SetMaxSpeed(self._baseActionConfig.runspeed);
    end;]]

    self._baseActionConfig = BaseActionConfig.GetConfig(typeConfig.baseaction);
	if actorType == ActorType_Player then
		self._hardLevel = 1
    elseif self._baseActionConfig then
        self._hardLevel = self._baseActionConfig.normalhard;
    end;

    self._baseSpeed = self:GetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_RUN_SPEED);

    self._baseAnimSpeed = 1;
    self._animSpeed = 1;
    --self._camp = typeConfig.camp;
    self._npcFuncType = typeConfig.functype;
    -- self._attackDistance = template.attackDistance;
	self._stage = ActorStage_Alive;
	self:SetName(self._prefix..typeConfig.name);
    self:RefreshNameColor();
	
	self:CreateActorRoot();
	
	return self;
end;

local _defaultActorTriggerSize = Vector3.New(2, 8, 2);
function Actor:CreateActorRoot()
	
	 -- 创建根节点
	local hierarchy = ActorManager.AllocActorHierarchy();
	self._hierarchy = hierarchy;

	self._transform = hierarchy._hierarchyRoot;
	self._transform.localRotation = Quaternion.identity;
	self._transform.localScale = Vector3.one;
	self._transform.localPosition = Vector3.zero;
	
	if AppConst.DebugMode then
		self._transform.gameObject.name = "actor_" ..self:GetType().."_"..self._roleKey.uid.."_"..(self._roleKey.id2 or 0).."_"..self._template.id;
	end;
	
	self._actorRoot = hierarchy._actorRoot;
	self._scaleRoot = hierarchy._scaleRoot;
	self._rideRoot = hierarchy._rideRoot;
	self._modelRoot = hierarchy._modelRoot;
	self._midCamFocus = hierarchy._midCamFocus;

	-- 缩放
	self._scaleValue = Vector3.one*self._template.scale;
	self._scaleRoot.localScale = self._scaleValue;
	
	self._collider = hierarchy._collider;
	self._actorTag = hierarchy._actorTag;
	self._luaCom = hierarchy._luaCom;
	
	-- 添加一个包围盒
    local needBox = false;
    if self._type == ActorType_Player then
		if not InFightMap then
			needBox = true;
		end;
    elseif self._type == ActorType_Npc then
        local funtype = self:GetFuncType();
        if funtype ~= NpcFuncType_FreeFight and funtype ~= NpcFuncType_Obstacle then
            needBox = true;
        end;
    end;

    if needBox then
		self._collider.enabled = true;
		
		-- 如果是传送门，则增加触发器处理
		if self:GetFuncType() == NpcFuncType_TransDoor then
			--error("TransDoor Created!!Name = "..self:GetName());
			self._collider.isTrigger = true;
			self._collider.size = _defaultActorTriggerSize;
			
			self._luaCom:SetCustomValue(self._roleKey.uid);
			self._luaCom:SetLuaOnTriggerEnterFunc(MapManager.TransDoorOnTriggerEnter);
		else
			self._actorTag.enabled = true;
			self._actorTag._actorType = self._type;
			self._actorTag._actorID = self._roleKey.uid;
			self._actorTag._actorTemplateID = self._template.id;
			self._actorTag._actorID2 = self._roleKey.id2 or 0;
		end;
    end;

    -- 计算位置，其实在这里不应该算位置
    -- todo
    if self._unitConfig then
        self._transform.position = Vector3.New(self._unitConfig.posX, self._unitConfig.posY, self._unitConfig.posZ);

        self._transform:Rotate(0, self._unitConfig.rotation, 0);
    else
        self._transform.position = Vector3.New(0, 0, 0)
    end;

	self._runAnimationRunSpeed = self._template.runAnimationRunSpeed;
	if self._runAnimationRunSpeed == 0 then
		self._runAnimationRunSpeed = 4;
	end
	
	if debugSvrFight then
		self:DrawBodyRange();
	end
	    --加上一个飞行代理 开销不大 避免后面跟navmeshagent的冲突
    self._ridingFlyAgent = hierarchy._ridingFlyAgent;
    self._ridingFlyAgent.enabled = true;
	
	self._transform.gameObject:SetActive(true);
end;

--单人副本由假服务器调用 一般不会用到
--加载baseaction和ai配置
function Actor:BuildBaseActionAndAI()

    if not self._template then
        return ;
    end;
    if not self._baseActionConfig then
        self._baseActionConfig = BaseActionConfig.GetConfig(self._template.baseaction);
    end;
    local aiConfig = AIManager.GetConfig(self._template.aiid);
    if aiConfig then
        self._aiConfig = copyTable(aiConfig)
    end;

    if self._baseActionConfig then
         --设置阵营
        self._camp = self._baseActionConfig.camp;

        self:SetMaxSpeed(self._baseActionConfig.runspeed);
    end;


end;

function Actor:GetBaseActionAndAI()
    return self._baseActionConfig, self._aiConfig;
end;

function Actor:CheckIsCollectNpc()
	local template = self:GetTypeConfig();
	if template == nil then
		--error("Actor:CheckIsCollectNpc template is nil, uid = "..self._roleKey.uid)
		return false;
	end

	if template.functype == NpcFuncType_Collect then
		return true
	end
	return false;
end

function Actor:CheckIsNpcType()
	if self._type == ActorType_Npc then
		return true
	end
	return false;
end

function Actor:OnClick()
	if self:CheckIsCollectNpc() then
		ReadBarManager.CollectItem(LOCAL_CHAR:GetCharKey(), self:GetUid());
	end
end

function Actor:GetTypeConfig()
    return self._template;
end

function Actor:GetUnitConfig()
    return self._unitConfig;
end

function Actor:GetRoleKey()
    return self._roleKey;
end;

function Actor:GetServerRoleKey()
    local roleKey = {}
    roleKey.qy_uin_ = self._roleKey.uid
    roleKey.role_id_ = self._roleKey.id2
    return roleKey 
end

function Actor:RoleKeyEquals(pb_qy_role_key)
    return self._roleKey.uid == pb_qy_role_key.qy_uin_ and self._roleKey.id2 == pb_qy_role_key.role_id_;
end

function Actor:RoleSexEquals(sex)
    return self._sex == sex;
end

-- 加载阴影
function Actor:BeginLoadShadow()
	if self:GetFuncType() ~= NpcFuncType_Obstacle and self:GetFuncType() ~= NpcFuncType_FreeFight and self:GetType() ~= ActorType_UIModel then
		--AssetLoadManager.LoadAsset("objects/other/yinying", "yinying", Actor.OnShadowLoaded, self);
		self._shadowLoadSerial = 0;
		self._shadowLoadSerial = AssetLoadManager.GetAssetFromCacheOrLoad(ACTOR_SIMPLE_SHADOW_AB, ACTOR_SIMPLE_SHADOW_ASSET, Actor.OnShadowLoaded, self);
	else
		self:BeginLoadModel();
    end;
end;

function Actor:OnShadowLoaded(shadowTrans, serial, assetBundle, assetName)
	if serial > 0 and serial ~= self._shadowLoadSerial then
		return AssetLoadManager.ReleaseAsset(assetBundle, assetName, shadowTrans, true);
	end;
	
	self._shadow = shadowTrans;
	
	if shadowTrans then
		shadowTrans.parent = self._rideRoot;
		shadowTrans.localPosition = Vector3.zero;
		shadowTrans.localRotation =  Quaternion.identity;
		shadowTrans.localScale = Vector3.one;
		shadowTrans.gameObject:SetActive(true);
	end;
	
    if self == LOCAL_CHAR then
        local isCloseDynamicShadow = MapManager.GetCurMap().isCloseDynamicShadow or false;
        self._isCloseDynamicShadow = isCloseDynamicShadow;
        self:UpdateShadowState();
    end

    if self._isUseDynamic then
        self._shadow.localScale = Vector3.New(0.01, 0.01, 0.01);
    else
        self._shadow.localScale = Vector3.New(1, 1, 1);
    end;

    if self == LOCAL_CHAR then
--        self._shadow.localScale = Vector3.New(0.01, 0.01, 0.01);
        self._shadow.gameObject:SetActive(false);
    end;

	self:BeginLoadModel();
end;

-- 模型是否已经加载成功
function Actor:IsModelLoaded()
    return self._ifModelLoaded;
end;

function Actor:GetShownModelPath()
	if self._changeBodyTemplate then
		return Util_GetNpcTempModelPath(self._changeBodyTemplate, self._type);
	end;

	if (self:GetType() == ActorType_Player or self:GetType() == ActorType_UIModel) and self._showData and self._showData._bodyID then
		local fashionConfig =  EquipEffectManager.FindConfig(EquipEffectType.Equip_Body, 
			self:GetPro(), self._showData._bodyID, self:GetSex());
			
		if fashionConfig then
			local effectConfig = EffectManager.GetConfig(fashionConfig.effectID);
			if effectConfig then
				if self:GetType() == ActorType_UIModel and effectConfig.assetName_lod4 ~= nil then
					return effectConfig.assetBundle, effectConfig.assetName_lod4;
				else
					return effectConfig.assetBundle, effectConfig.assetName; 
				end;
			end;
		end;
	end;
	
	return Util_GetNpcTempModelPath(self._template, self._type);
end;

function Actor:BeginLoadModel()
    --AssetLoadManager.LoadAsset(self._template.modelPath, self._template.model, self.OnModelLoaded, self);
	-- error(" Actor:BeginLoadModel()");
	
	if self:NeedLoadModel() then
		self._ifModelLoaded = false;
		local modelPath, model = self:GetShownModelPath();
		
		--ErrorFormat(" Actor:BeginLoadModel():ab = %s, asset = %s, key = %s, dead = %s", modelPath, model, self:GetActorKey(), tostring(self:IsDead()));
		
		self._modelLoadSerial = 0;
		self._modelLoadSerial = AssetLoadManager.GetAssetFromCacheOrLoad(modelPath, model,
			self.OnModelLoaded, self);
	--	error(" Actor:BeginLoadModel():self._modelLoadSerial = "..self._modelLoadSerial.."; name = "..self:GetName());
	else
		self._ifModelLoaded = true;
		self:CreateHud();
	end;
end;

-- 模型加载回调
function Actor:OnModelLoaded(modelTrans, serial, assetBundle, assetName)
--	error(" Actor:OnModelLoaded(): Enter !!!!!!!!!serial = "..serial.."; self._modelLoadSerial = "..self._modelLoadSerial.."; name = "..self:GetName().."; assetName = "..assetName);
	if serial > 0 and serial ~= self._modelLoadSerial then
--		error(" Actor:OnModelLoaded(): model old !!!!!!!!!serial = "..serial.."; self._modelLoadSerial = "..self._modelLoadSerial.."; name = "..self:GetName().."; assetName = "..assetName);
		return AssetLoadManager.ReleaseAsset(assetBundle, assetName, modelTrans, true);
	end;
	
	if IsNil(modelTrans) then
		----error("Actor:OnModelLoaded(modelTrans):load model failed!");
		return;
	end;

	if self._model then
	--	error(" Actor:OnModelLoaded():has model !!!!!!!!!serial = "..serial.."; self._modelLoadSerial = "..self._modelLoadSerial.."; name = "..self:GetName().."; assetName = "..assetName);
		AssetLoadManager.ReleaseAsset(nil, nil, self._model, true);
		MessageBoxPanel.ShowMessage("", " Actor:OnModelLoaded():has model !!!!!!!!!serial = "..serial.."; self._modelLoadSerial = "..self._modelLoadSerial.."; name = "..self:GetName().."; assetName = "..assetName);
	end;
	
	self._model = modelTrans;
	
	--if self:IsDestroyed() then
		----error("Actor:OnModelLoaded(modelTrans):Destroyed!!!Name = "..self:GetName());
	--	return self:DestroyModel();
	--end;
	
	--if not self._ifOnTargetMap then
		----error("Actor:OnModelLoaded(modelTrans):Not On Target Map!!!Name = "..self:GetName());
	--	GameObject.Destroy(modelTrans.gameObject);
	--	return self:DestroyModel();
	--end;
	
	modelTrans.gameObject:SetActive(true);
	
    modelTrans:SetParent(self._modelRoot);
    modelTrans.localPosition = Vector3.zero;
    modelTrans.localScale = Vector3.one;
    modelTrans.localRotation = Quaternion.identity;
	
    if self:GetUid() == LOCAL_UIN and self._type == ActorType_Player then
        self._footDownEventHandler = self._model:GetComponent(FootDownEvent.GetClassType());
        if self._onTheWater and self._footDownEventHandler then
            self._footDownEventHandler.inWater = true;
        end;
    end;
	
	self._ifModelLoaded = true;
	
    --这里是挖坑处理剑客婚礼时装狗头挂点的问题
    if assetName == "jiannan_hf_lod4" or assetName == "fashion_hf" then
        local Bip001HeadObj = self._model:Find("Bip001 Head")
        if not IsNil(Bip001HeadObj) then
            local body_fxObj    = Bip001HeadObj.gameObject.transform:Find("body_fx")
            if IsNil(body_fxObj) then
                local body_fxObj = GameObject.New("body_fx");

                body_fxObj.gameObject.transform:SetParent(Bip001HeadObj)
                body_fxObj.gameObject.transform.localPosition = Vector3.New(0,0,0)
                body_fxObj.gameObject.transform.localEulerAngles = Vector3.New(270,90,0)
                body_fxObj.gameObject.transform.localScale = Vector3.New(1,1,1)
            end
        end        
    end
    --这里是挖坑处理wing_fx节点的位置问题,都是justin的锅
    local xiongbuObj = self._model:Find("xiongbu_1")
    if not IsNil(xiongbuObj) then
        local wingFxObj = xiongbuObj.gameObject.transform:Find("wing_fx")
        if not IsNil(wingFxObj) then
            wingFxObj.gameObject.transform.localPosition = Vector3.New(0,0,0)
            wingFxObj.gameObject.transform.localEulerAngles = Vector3.New(0,0,0)
            wingFxObj.gameObject.transform.localScale = Vector3.New(1,1,1)
        end
    end

    self:LoadOther();
    -- animator必须在模型加载上来以后才能获取
    self:CreateAnimator();
	
    self:AddAllBuffAfterLoaded();
  
    self:ReloadMaterials();
    self:ReloadActorObject();
	
	if self._type == ActorType_UIModel then
        self._layer = self._layer or LAYER_MARK.UIModel;
	else
        self._layer = self._layer or LAYER_MARK.Player;
	end;
	Util.SetAllLayer(self._transform.gameObject, self._layer);

	--设置阴影, 平面的
	--[[local skinedMeshrenderArr = modelTrans.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType());
	local shader = Shader.Find("ZTJ_Shaders/Lit/Actor_Specular_RimColor_Shadow");
	for i = 0, skinedMeshrenderArr.Length-1 do
		if self == LOCAL_CHAR then
			if ShadowManager.IsOpenLOCAL_CHARShadow() then
				skinedMeshrenderArr[i].material.shader = shader;
			end
		else
			if ShadowManager.IsOpenOtherShadow() then
				skinedMeshrenderArr[i].material.shader = shader;
			end
		end;
	end--]]
	
	--设置阴影, 平面的
    self:RefreshPlaneShadowState();
	
	
	if self == LOCAL_CHAR then
--		Util.SetAllLayer(modelTrans.gameObject, LAYER_MARK.GlobalProjectorLayer);
        --这里只把skinnedMeshrenderer设置为这个层级
        local skinedMeshrenderArr = modelTrans.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType());
        for i = 0, skinedMeshrenderArr.Length-1 do
            Util.SetAllLayer(skinedMeshrenderArr[i].gameObject, LAYER_MARK.GlobalProjectorLayer);
			
	    end;
	else
		--非主角也需要,但是是添加到阴影节点下的
		if self._shadow ~= nil then
			local shadowMesh = self._shadow:GetComponentInChildren(MeshRenderer.GetClassType());
			
			if not IsNil(shadowMesh) then
				local hideCom = shadowMesh.gameObject:GetComponent(HideUnuseCom.GetClassType());
				
				if IsNil(hideCom) then
					hideCom = shadowMesh.gameObject:AddComponent(HideUnuseCom.GetClassType());
				end
				
				if AppConst.IsIOS then
					hideCom._isForceUpdate = true;
				end
				
				hideCom._animator = self._animator;
				hideCom._ifDisableInStart = false;
                self._hideCom = hideCom;
			end;
		end
	end

    if self._autoFlying then
        AutoFlyManager.StartV3(self, 0);
    end;

	-- 动作事件
    local animtorEvent = self._model.gameObject:GetComponent(AnimatorEvent.GetClassType())
	if not animtorEvent then
		animtorEvent = self._model.gameObject:AddComponent(AnimatorEvent.GetClassType())
	end;
    animtorEvent.actorKey = self:GetActorKey();
	
--	self._needCreateHud = self:GetType() ~= ActorType_UIModel;
	
	if modelTrans ~= nil then
	local arr = modelTrans.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType())
		self._roleSkinRenderList = {};
		for i = 0, arr.Length-1 do
			self._roleSkinRenderList[i+1] = arr[i]
		end
		
		if arr.Length > 0 then
			self._roleSkinRender = arr[0];	--有多个的就不管了, 主角不会有多个,发生在npc上面
			--PromptPanel.ShowDebugMessage("actor set _roleSkinRender actorName = "..self:GetName());
		end;
	end
	
	if not self:IsChangeBody() then
		if self:GetType() == ActorType_Player or self:GetType() == ActorType_UIModel then
			self:BeginLoadWeapon();
		end;

		if self._riding then
			self:DoRide(self._ridingAssetBundle, self._ridingAssetName, self._ridingConfig);
		end;
	end;

    -- 染色
    FashionManager.SetActorFashionColor(self, ENUM_FASHION_TYPE.SUIT, self:GetBodyID(), self:GetBodyColors())
	
	self:CreateHud();
	
	self:RevertDissolveEffect();
end;


function Actor:LoadOther()
   -- error("Actor:LoadOther()");
	
	if self._model then
		local jiantou = self._model:Find("jiantou");
		if jiantou then
			self._model_dir = jiantou.gameObject;
			
			self._model_dir_controller = self._model_dir:GetComponent(AlwaysLookAt.GetClassType());
			self:HideDir();
		end;
	end;
end;


--模型加载后 拿到材质存下来  后面有用处
function Actor:ReloadMaterials()
    self._materials = {};
    if self._model then
        local renderers = self._model:GetComponentsInChildren(Renderer.GetClassType());
        local count = renderers.Length;
        for i=0,count - 1 do
            local renderer = renderers[0];
			if renderer.name ~= "Plane01" and renderer.gameObject.layer ~= HUD_LAYER then
				local mat = renderer.material;
            
				table.insert(self._materials, {material = mat; tween = nil;});
			end;
        end;
    end;
end;

--存着一些记录下来的点
function Actor:ReloadActorObject()
    self._weaponTrails = {};
    if self._model then
        local com = self._model:GetComponent(ActorObjectList.GetClassType());
        if com then
            self._weaponTrails[1] = com.weaponTrail1;
        end;
    end;
end;

function Actor:Exposure()
    do return end;
    local count = #self._materials;
    for i=1,count do
        local mat = self._materials[i].material;
        local tween = self._materials[i].tween;
        if tween then
           -- DoTweenHelper.StopTween(tween, false);
            DoTweenHelper.ReplayTween(tween);

        else
            local t =  DoTweenHelper.DoSetShaderProperty_Float(mat, "_Intensity", 5, 1, 0.75);
            self._materials[i].tween  = t;
            DoTweenHelper.SetAutoKill(t , false);
        end;



    --    local tween2 = DoTweenHelper.DoSetShaderProperty_Float(mat, "_Intensity", 4, 1, 0.05);
--[[
        local sequence = DG.Tweening.DOTween.Sequence();
        sequence = DG.Tweening.TweenSettingsExtensions.Append(sequence, tween1);
        sequence = DG.Tweening.TweenSettingsExtensions.Append(sequence, tween2);]]
    end;
end;

-- 是否需要加载模型
function Actor:SetNeedLoadModel(bNeedLoadModel)
	if self._needLoadModel ~= bNeedLoadModel then
		self._needLoadModel = bNeedLoadModel;
		self:ClearAllModel();
	
		self:SetLoadDirty();
	end;
end;

function Actor:NeedLoadModel()
	return self._needLoadModel;
end;

function Actor:ClearAllModel()
	self:DestroyHud();
	self:ClearEquipEffects(); -- 清空特效
	self:DestroyGuajianModel();
	self:DestroyWeapon();
	self:DestroyModel();
	self:DestroyShadow();
end;

function Actor:SetLoadDirty()
	
	if self._ifOnTargetMap then
		if self:GetType() == ActorType_Player then
			if self ~= LOCAL_CHAR then
				self._waitLoadTime = 0.5+math.random()*0.5;
			else
				self._waitLoadTime = 0.01;
			end;
		elseif self:GetType() == ActorType_UIModel then
			self._waitLoadTime = 0.01;
		else
			self._waitLoadTime = math.random()*0.5;
		end;
	end;
end;

function Actor:PreOnGotoTargetMap()
    self._ifOnTargetMap = false;
	
	self:StopAi();
	self:StopNav();
    self:DisableNav();
  --  self:DestroyHud();
	self:ClearAllModel();
	
	self._shiftMove = nil;
end;

function Actor:OnGotoTargetMap(bInit)


	--	 error("Actor:OnGotoTargetMap():" .. self._name);

	
    self._ifOnTargetMap = true;
	
	if self:IsDaemonMode() then
		return ;
	end;
	
	self:SetLoadDirty();

	-- 初始化时，位置信息还不全，所以不创建nav
	if self._type ~= ActorType_UIModel then
		self:EnableNav();

		if self._routeToWalk then
			self:SetPath(self._routeToWalk[1],self._routeToWalk[2],self._routeToWalk[3]);
			self._routeToWalk = nil;
		end;
	end;
	-- if LOCAL_CHAR == self then
	-- Util.LogError("ride flying state = " .. tostring(LOCAL_CHAR:IsRideFlying()))
    -- end;
    --设置一下 shadow的参数
    if self == LOCAL_CHAR then
        local isCloseDynamicShadow = MapManager.GetCurMap().isCloseDynamicShadow or false;
		
        self._isCloseDynamicShadow = isCloseDynamicShadow;
--        self:UpdateShadowState();

        --重新设置阴影方向
--        if self._shadowProjector ~= nil then
--            local sceneName = MapManager.GetCurMap().scene
--            if sceneName == nil then sceneName = "nil" end;

--            local dirInfo = ActorShadowDir[sceneName];
--            if dirInfo == nil then
--                --PromptPanel.ShowMessageBox("dirInfo is nil, sceneName = "..sceneName);
--                dirInfo = {x = 1, y = -1.5, z = 1};
--            end

--	        self._shadowProjector.GlobalProjectionDir = Vector3.New(dirInfo.x, dirInfo.y, dirInfo.z);
--        end;
		
		self:UpdateShadowState();
		
        --临时解决一下
        if self == LOCAL_CHAR then
            CameraEffectsManager.EndLowHpEffects();
			CameraEffectsManager.EndGray();
        end;
    end
	
	--self:ProcessEquipEffects();
end;

function Actor:BeginLoad()
	--error("Actor:BeginLoad()");
	self:BeginLoadShadow();
end;

function Actor:SetRoleFashion(part, id, lvl, pigmentList, showEffect)
    local type = FashionManager.FashionPartToType(part + 1)
    Log_Bird(3, "part = "..part, type == nil)
    FashionManager.SetActorFashionData(self, type, id, lvl, pigmentList and pigmentList[1] or 0)
end
--[[
local RoleShowData=
{
	_bodyID = 0;	-- 時裝
	_weaponID = 0;		-- 武器
	_guajianID = 0;	-- 掛件
	_equipEffects = {}; 	-- 特效
};
--]]
-- 显示外观信息
function Actor:SetRoleShowData(showData)
	--errorTable(showData, "Actor:SetRoleShowData(showData)");
	self:ClearAllModel();
	
	self._showData = showData;

	self:SetLoadDirty();
end;

function Actor:SetBodyEquip(typeID, colorList)
--	error("Actor:SetBodyEquip(typeID):typeid = "..typeID);
	
	if self._showData then
		self._showData._bodyID = typeID;
        self._showData._bodyColors = colorList;
		self:SetRoleShowData(self._showData);
	end;
end;

function Actor:SetHair(typeID, colorList)
    -- 头发实际上是身体的一部分，这里仅改变身体的染色
    if self._showData ~= nil and self._showData._bodyColors ~= nil then
        for k, v in pairs(colorList) do
            self._showData._bodyColors[k] = v
        end
        self:SetRoleShowData(self._showData);
    end
end

function Actor:GetBodyID()
    return self._showData._bodyID or 0;
end;

function Actor:GetBodyColors()
    return self._showData._bodyColors or {}
end

function Actor:SetWeapon(typeID, colorList)
    error("Actor:SetWeapon(typeID):typeID = "..typeID);

    if self._showData then
        self._showData._weaponID = typeID;
        self._showData._weaponColors = colorList;
        self:SetRoleShowData(self._showData);
    end;
end;
function Actor:GetWeaponID()
    return self._showData._weaponID or 0;
end;

function Actor:GetWeaponColors()
    return self._showData._weaponColors or {};
end

function Actor:SetGuajian(guajianID, colorList)
    if self._showData then
        self._showData._guajianID = guajianID;
        self._showData._guajianColors = colorList;
        self:SetRoleShowData(self._showData);
    end;
end;

function Actor:SetTalisman(talismanID)
    self:SetEquipEffect(EquipEffectType.Equip_Talisman, talismanID)
end

function Actor:GetGuajianID()
    return self._showData._guajianID or 0;
end;

function Actor:GetGuajianColors()
    return self._showData._guajianColors or {}
end

function Actor:SetEquipEffect(effectType, effectLvl)
    --	ErrorFormat(" Actor:SetEquipEffect(effectType:%s, effectLvl:%s)", effectType, effectLvl);

    local effect = self:FindEquipEffect(effectType);
    if not effect then
        effect = {};
        table.insert(self._showData._equipEffectList, effect);
    end;
    effect.effectType = effectType;
    effect.effectLvl = effectLvl;

    self:SetRoleShowData(self._showData);
end;

function Actor:FindEquipEffect(effectType)
    if not self._showData._equipEffectList then
        self._showData._equipEffectList = {};
    end;

    for i = 1, #self._showData._equipEffectList do
        local effect = self._showData._equipEffectList[i];
        if effect and effect.effectType == effectType then
            return effect;
        end;
    end;
end;

function Actor:CopyRoleShowData()
    return copyTable(self._showData, false);
end
----------------------------------------------------------------------
function Actor:DestroyWeapon()
    --	error(" Actor:DestroyWeapon()");

    --local weaponConfig, modelConfig  = self:GetShownWeaponConfig();
    --	if weaponConfig and modelConfig then
    if self._weaponModel then
        AssetLoadManager.ReleaseAsset(nil,
        nil, self._weaponModel, true);

        self._weaponModel = nil;
    end;
    --	end;

    self._weaponLoadSerial = 0;
end;

--获取身上的模型
function Actor:GetRoleRender()
    if IsNil(self._roleSkinRender) then
        return
    end

    return self._roleSkinRender
end

--主要是NPC的时候, GetRoleRender() 得到的有可能是武器
function Actor:GetRoleRenderList()
	return self._roleSkinRenderList
end

function Actor:GetWeaponModel()
    if IsNil(self._weaponModel) then
        return
    end

    return self._weaponModel;
end;

function Actor:GetWeaponRender()
    if self._weaponRender == nil then
        local model = self:GetWeaponModel();
        if model == nil then return end;

        local arr = model.gameObject:GetComponentsInChildren(MeshRenderer.GetClassType());
        if arr.Length > 0 then
            self._weaponRender = arr[0];
        else
            --也有可能是SkinMeshRender
            arr = model.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType());
            if arr.Length > 0 then
                self._weaponRender = arr[0];
            end
        end
    end
    return self._weaponRender;
end

function Actor:GetShownWeaponConfig()
    -- 武器
    --errorTable(showData, "Actor:SetRoleShowData(showData)");
    if (self:GetType() == ActorType_Player or self:GetType() == ActorType_UIModel) and self._showData then
        local weaponConfig =  EquipEffectManager.FindConfig(EquipEffectType.Equip_Weapon,
        self:GetPro(), self._showData._weaponID or 0, self:GetSex());

        return weaponConfig, weaponConfig and EffectManager.GetConfig(weaponConfig.effectID);
    end;
end;

function Actor:BeginLoadWeapon()
    error("Actor:BeginLoadWeapon()");
    local weaponConfig, weaponModelConfig = self:GetShownWeaponConfig();
    if weaponConfig and weaponModelConfig then
        error("Actor:BeginLoadWeapon()name = "..self:GetName());
        self._weaponLoadSerial = 0;
        self._weaponLoadSerial = AssetLoadManager.GetAssetFromCacheOrLoad(weaponModelConfig.assetBundle,
        weaponModelConfig.assetName, self.OnWeaponLoaded, self);
    else
        self:BeginLoadGuajian();
    end;
end;

function Actor:OnWeaponLoaded(weaponTrans, serial, assetBundle, assetName)
    error("Actor:OnWeaponLoaded(weaponTrans, serial, assetBundle, assetName)name = "..self:GetName()..";serial = "..serial.."; loadSerial = "..self._weaponLoadSerial);
    local weaponConfig = self:GetShownWeaponConfig();
    local processed = false;
    if (serial == 0 or serial == self._weaponLoadSerial) and weaponTrans and weaponConfig then
        local attachNode = findRecursive(self:GetTransform(), weaponConfig.attachName);
        if attachNode then
            weaponTrans:SetParent(attachNode, false);
            weaponTrans.localPosition = Vector3.zero;
            weaponTrans.localScale = Vector3.one*weaponConfig.scale;
            weaponTrans.localRotation = Quaternion.identity;
            weaponTrans.gameObject:SetActive(true);
            weaponTrans.gameObject.name = weaponConfig.name;
            Util.SetAllLayer(weaponTrans.gameObject, attachNode.gameObject.layer);

            self._weaponModel = weaponTrans;

            --self:ProcessEquipEffects();
            processed = true;
        end;
    end;

    if not processed then
        AssetLoadManager.ReleaseAsset(assetBundle,
        assetName, weaponTrans, true);
    else
        -- 染色
        FashionManager.SetActorFashionColor(self, ENUM_FASHION_TYPE.WEAPON, self:GetWeaponID(), self:GetWeaponColors())
    end;


    self:BeginLoadGuajian();
    self:RefreshPlaneShadowState();
end;
----------------------------------------------------------------------
-- 挂件
function Actor:DestroyGuajianModel()
    if self._guajianModel then
        AssetLoadManager.ReleaseAsset(nil,
        nil, self._guajianModel, true);

        self._guajianModel = nil;
    end;
    --	end;

    self._guajianLoadSerial = 0;
end;

function Actor:GetGuajianModel()
    return self._guajianModel;
end;

function Actor:GetGuaJianRender()
    if self._guajianRender == nil then
        local model = self:GetGuajianModel();
        if model == nil then return end;

        local arr = model.gameObject:GetComponentsInChildren(MeshRenderer.GetClassType());
        if arr.Length > 0 then
            self._guajianRender = arr[0];
        else
            --也有可能是SkinMeshRender
            arr = model.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType());
            if arr.Length > 0 then
                self._guajianRender = arr[0];
            end
        end
    end
    return self._guajianRender;
end

function Actor:GetGuajianModelConfig()
    if (self:GetType() == ActorType_Player or self:GetType() == ActorType_UIModel) and self._showData and self._showData._guajianID then
        local guajianConfig = EquipEffectManager.FindConfig(EquipEffectType.Equip_Guajian,
        self:GetPro(), self._showData._guajianID, self:GetSex());

        return guajianConfig, guajianConfig and EffectManager.GetConfig(guajianConfig.effectID);
    end;
end;
function Actor:BeginLoadGuajian()
    local guajianConfig, guajianModelConfig = self:GetGuajianModelConfig();
    if guajianConfig and guajianModelConfig then
        --error("Actor:BeginLoadWeapon()name = "..self:GetName());
        self._guajianLoadSerial = 0;
        self._guajianLoadSerial = AssetLoadManager.GetAssetFromCacheOrLoad(guajianModelConfig.assetBundle,
        guajianModelConfig.assetName, self.OnGuajianModelLoaded, self);

    else
        self:ProcessEquipEffects();
    end;

end;

function Actor:OnGuajianModelLoaded(guajianTrans, serial)
    local ifAttached = true;
    while true do
        if not guajianTrans or serial ~= self._guajianLoadSerial then
            break;
        end;

        local guajianConfig = self:GetGuajianModelConfig();
        if not guajianConfig then
            ifAttached = false;
            break;
        end;

        local attachNode = findRecursive(self:GetTransform(), guajianConfig.attachName);
        if not attachNode then
            ifAttached = false;
            break;
        end;

        guajianTrans:SetParent(attachNode, false);
        guajianTrans.localPosition = Vector3.zero;
        guajianTrans.localScale = Vector3.one*guajianConfig.scale;
        guajianTrans.localRotation = Quaternion.identity;
        guajianTrans.gameObject:SetActive(true);
        guajianTrans.gameObject.name = guajianConfig.name;
        Util.SetAllLayer(guajianTrans.gameObject, attachNode.gameObject.layer);

        self._guajianModel = guajianTrans;

        break;
    end;
    if not ifAttached then
        AssetLoadManager.ReleaseAsset(nil,
        nil, self._guajianModel, true);
    else

        -- 染色
        FashionManager.SetActorFashionColor(self, ENUM_FASHION_TYPE.PENDANT, self:GetGuajianID(), self:GetGuajianColors())
    end;

    self:ProcessEquipEffects();



    self:RefreshPlaneShadowState();
end;
----------------------------------------------------------------------
function Actor:ClearEquipEffects()
    if not self._equipEffecActiontList then
        return ;
    end;

    while #self._equipEffecActiontList > 0 do
        local effect = table.remove(self._equipEffecActiontList);
        if effect then
            effect:Stop();
        end;
    end;
end;

function Actor:DoAddEquipEffect(effect)
    if not self._equipEffecActiontList then
        self._equipEffecActiontList = {};
    end;
    table.insert(self._equipEffecActiontList, effect);
end;

function Actor:GetZhuJianTaoLv()
    if self._showData == nil then
        if AppConst.DebugMode then
            PromptPanel.ShowNewMessage("获取主件套等级 找不到主件套魂装等级")
        end
        return 1;
    end

    local effect = self:FindEquipEffect(EquipEffectType.SoulEquip_ZhujianTao);

    return effect and effect.effectLvl or 1;
end

function Actor:ProcessEquipEffects()
    if not self._showData or not self._model or not self._showData._equipEffectList then
        return ;
    end;

    for i = 1, #self._showData._equipEffectList do
        local effect = self._showData._equipEffectList[i];
        self:AddSingleEquipEffects(effect.effectType, effect.effectLvl);
    end;
    -- 挖个坑， 加载称号相关的脚步
    local effectId, attachname = TitleManager.GetTitleFootMarkEffect(self:GetTitleID())
    if self._riding == false and effectId ~= nil and effectId ~= 0 then
        local effect = FcAction_ActorEffect.New(effectId, self:GetActorKey(), attachname, false, 1);
        FcActionManager.AddEx(effect, -1, 0);
        effect:SetEffectName("FootMark");

        self:DoAddEquipEffect(effect);
    end

    --[[
    -- 激活等级都是以最小值来决定的
    local curLvl = self._showData.equip_soul_lvl_:byte(1);
    local minLvl = curLvl >= 255 and -1 or curLvl;
    -- 魂装主套件
    if minLvl > 0 then
        self:AddSingleEquipEffects(EquipEffectType.SoulEquip_ZhujianTao, minLvl);
    end;

    -- 魂副件特效
    curLvl = self._showData.equip_soul_lvl_:byte(2);
    minLvl = math.min(minLvl, curLvl >= 255 and -1 or curLvl);
    if minLvl > 0 then
        self:AddSingleEquipEffects(EquipEffectType.SoulEquip_FujianTao, minLvl);
    end;

    -- 全身特效
    curLvl = self._showData.equip_soul_lvl_:byte(3);
    minLvl = math.min(minLvl, curLvl >= 255 and -1 or curLvl);
    if minLvl > 0 then
        self:AddSingleEquipEffects(EquipEffectType.SoulEquip_ShipinTao, minLvl);
    end;

    -- 翅膀等级
    local wingLvl = self._showData.wing_lvl_;
    if wingLvl < 65535 then
        self:AddSingleEquipEffects(EquipEffectType.Equip_Wing, wingLvl);
    end;

    -- 挂件
    local guajianID = self._showData.guajian_id_;
    if guajianID < 65535 then
        self:AddSingleEquipEffects(EquipEffectType.Equip_Guajian, guajianID);
    end;
    --]]
end;

function Actor:AddSingleEquipEffects(type, lvl)
    --error("Actor:AddSingleEquipEffects(type, lvl):type = "..type.."; lvl = "..lvl);
    local equipEffectConfig = EquipEffectManager.FindConfig(type, self:GetPro(), lvl, self:GetSex());
    if not equipEffectConfig then
        return ;
    end;

    local effect = FcAction_ActorEffect.New(equipEffectConfig.effectID,
    self:GetActorKey(), equipEffectConfig.attachName, false, equipEffectConfig.scale);
    FcActionManager.AddEx(effect, -1, 0);
    effect:SetEffectName(equipEffectConfig.name);

    if type == 13 and lvl == 24 then
        if not IsNil(self._model) then
            local body_fxObj = self._model:Find("body_fx")
            local Bip001HeadObj = self._model:Find("Bip001 Head")
            if not IsNil(body_fxObj) and not IsNil(Bip001HeadObj) then
                body_fxObj.gameObject.transform:SetParent(Bip001HeadObj)
                body_fxObj.gameObject.transform.localPosition = Vector3.New(0,0,0)
                body_fxObj.gameObject.transform.localEulerAngles = Vector3.New(270,90,0)
                body_fxObj.gameObject.transform.localScale = Vector3.New(1,1,1)
            end
        end
    end

    self:DoAddEquipEffect(effect);
end;
------------------------------------------------
function Actor:GetStage()
    return self._stage;
end;

function Actor:IsAppearing()
    return self._stage == ActorStage_Appearing;
end;

function Actor:IsAlive()
    return self._stage == ActorStage_Alive;
end;

function Actor:IsDead()
    return self._isDead or false;
end;

function Actor:IsDisappearing()
    return self._stage == ActorStage_Disappearing;
end;

function Actor:CheckRoleState(stateValue)
    local currState = self:GetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_ROLE_CUR_STATE);
    if bit.band(currState, stateValue) == stateValue then
        return true
    else
        return false
    end;
end;

function Actor:IsDestroyed()
    return self._stage == ActorStage_Destroyed;
end;
------------------------------------------------
-- 更新
local tempVect4 = Vector4.New(0, 0, 0, 0);
function Actor:Update(deltaTime)

    if self._isDaemonMode then
        return ;
    end;

    self:UpdateAnim(deltaTime);
    self:UpdateHud(deltaTime);
    self:UpdateAi(deltaTime);

    if not self._isDaemonMode and self._waitLoadTime > 0 and self._ifOnTargetMap then
        self:UpdateWaitLoad(deltaTime);
    end;

    if self:IsAlive() then
        if self.manualFlyController and self.manualFlyController:Update(deltaTime) then
            --do nothing
        else
            self:UpdateNav(deltaTime);
        end;

    end;

    --
    if self:IsDisappearing() then
        self:UpdateDisappear(deltaTime);
    elseif self:IsDead() then
        self:UpdateDead(deltaTime);
    end;

    if self._shiftMove and not self:IsDead() then

        self._shiftMove:Update(Time.timeSinceLevelLoad);
    end;

    if self._routeInfo then
        self:UpdatePath();
    end;

    -- if self._needCreateHud and not MapLoadManager.IsLoading()  then
    -- self._needCreateHud = false;
    -- self:CreateHud()
    -- end;


    if self == LOCAL_CHAR then
        SkillButtonPanel.UpdateSkillDirPosInButtonDown();
        AutoFlyManager.LocalCharUpdate();
    end

    if self._bodyRangeObject then
        --		self._bodyRangeObject.transform.localPositioin = Vector3.zero;
    end

    if self == LOCAL_CHAR then
        --做个测试,停下来的时候就不设置了
        local localCharPos = LOCAL_CHAR:GetPos();

        if self._isMoving then

            tempVect4.x = localCharPos.x;
            tempVect4.y = localCharPos.y;
            tempVect4.z = localCharPos.z;
            tempVect4.w = 1;
            GrassManager.SetInteractivePos(tempVect4);
        else
            --这里会有个突变,暂时不用
            --[[tempVect4.x = 0;
            tempVect4.y = 0;
            tempVect4.z = 0;
            tempVect4.w = 1;
            GrassManager.SetInteractivePos(tempVect4);--]]
        end

        --		ShadowManager.UpdatePos(localCharPos.y + 0.05);
    end
end;

function Actor:UpdateAutoFly()
    do return end;
    if not self._nav then return end;
    --   if self._nav.isOnOffMeshLink then
    --  local d = self._nav.currentOffMeshLinkData;
    --  error("off mesh link end pos=".. d.endPos.x .. " ".. d.endPos.y .. " "..d.endPos.z);
    --   else

    --   end;

    if not self._autoFlying and self._nav.isOnOffMeshLink then
        AutoFlyManager.DoStartFly(self, self._nav.currentOffMeshLinkData.endPos);
    end;

    do return end;


    --if not InSingleMap then return end;
    if not self._autoFlying and self._nav.isOnOffMeshLink then

        AutoFlyManager.Start(self);

        if self._animator then
            self._animator:SetTrigger(Actor.AnimatorStringHash("flystart"));
            self._animator:SetBool(Actor.AnimatorStringHash("autoflying"), true);
        end;
        self._autoFlying = true;


    end;

    if self._autoFlying and not self._nav.isOnOffMeshLink then
        if self._animator then
            AutoFlyManager.Stop(self);
            self._animator:SetTrigger(Actor.AnimatorStringHash("flyend"));
            self._animator:SetBool(Actor.AnimatorStringHash("autoflying"), false);
            if self.autoFlySpeedTween then DoTweenHelper.StopTween(self.autoFlySpeedTween, false); self.autoFlySpeedTween = nil end;
            local speed = self._nav.speed;
            self._nav.speed = 5.5;

            Timer.New(function()self:ResetMaxSpeed() end, 0.8, 1):Start();

        end;
        self._autoFlying = false;


    end;
end;

function Actor:UpdateWaitLoad(deltaTime)
    if self._waitLoadTime > 0 then
        self._waitLoadTime = self._waitLoadTime - deltaTime;
        if self._waitLoadTime <= 0 then
            self:BeginLoad();
        end;
    end;
end;

function Actor:UpdateDead(deltaTime)
    self._deadTime = self._deadTime + deltaTime;
    if self._deadTime > 2 and self:GetType() == ActorType_Npc then
        self:BeginDisappear();
    end;
end;

function Actor:BeginDisappear()
	self:PlayDissolveEffect();
    self._stage = ActorStage_Disappearing;
    self._disappearTime = 0;
	
	--self:SetHideHud(true);
    self:DestroyHud();
end;

function Actor:UpdateDisappear(deltaTime)
    if not InSingleMap then
        return ;
    end;
    self._disappearTime = self._disappearTime + deltaTime;
    ----error("Actor:UpdateDisappear(deltaTime):_disappearTime = "..self._disappearTime);
	if self._disappearTime > 2 then
		self._transform:Translate(0, - deltaTime, 0);
	end;
	
    if self._disappearTime > 6 then
        self:Destroy();
    end;
end;

-- 动作做一个时间检查，如果时间结束，把优先级降为零
function Actor:UpdateAnim(deltaTime)
    if self._animTime and self._animTime > 0 then
        self._animTime = self._animTime - deltaTime;
        if self._animTime <= 0 then
            self._animPriority = 0;
        end;
    end;
end;

function Actor:UpdateNav(deltaTime)
    --ErrorFormat("Actor:UpdateNav(deltaTime):name = %s", self._name);
    if self:IsRideFlying() then
        return ;
    end;
    --ErrorFormat("Actor:UpdateNav(deltaTime):name = %s", self._name);
    if self._ifOnTargetMap and self._navAgentFailed then
        self:DisableNav();
        self:EnableNav();
    end;
    --ErrorFormat("Actor:UpdateNav(deltaTime):name = %s", self._name);
    if not self._isNaving or not self._nav or IsNil(self._nav) or not self._nav.enabled or not self._nav.isOnNavMesh then
        return;
    end;
    --ErrorFormat("Actor:UpdateNav(deltaTime):name = %s", self._name);
    if self._routeInfo then
        --     return;
    end;
    --ErrorFormat("Actor:UpdateNav(deltaTime):name = %s", self._name);

    if self._navTarget and Vector3.SqrDistance(self:GetPos(), self._navTarget) < self._navStopDistanceSqr then
        self:StopNav();
    end;

end;

function Actor:SetHudDirty()
    if self._hud then
        --        self._hud:SetDirty();
    end;
end

function Actor:DestroyHud()
    -- --error("Actor:DestroyHud(): Application.loadedLevelName = "..Application.loadedLevelName);
    --[[
     if self._hud then
         self._hud:Remove();
         self._hud = nil;
         self._hudTrans = nil;
     end;
     --]]
    --ErrorFormat("Actor:DestroyHud():name = %s; isDead = %s; key = %s", self:GetName(), tostring(self:IsDead()), self:GetActorKey());

    if self._hud then
        self._hud:Destroy();
        self._hud = nil;
        --   self._hudTrans = nil;
    end
end;

function Actor:GetHudNodeName()
    if self._ridingTrans then
        return "ridehud"
    else
        return "hud"
    end;
end;

function Actor:SetHideHud(bHide)
    if bHide ~= self._ifHideHud then
        self._ifHideHud = bHide;
        if self._ifHideHud then
            self:DestroyHud();
        elseif self:IsModelLoaded() then
            self:CreateHud();
        end;
    end;
end;


function Actor:PrepareHudNode()
    local hudTrans = nil;

    if self._ridingTrans then
        hudTrans = findRecursive(self._ridingTrans, "ridehud");
    elseif self._model then
        hudTrans = findRecursive(self._model, "hud");
    end;

    if hudTrans then
        hudTrans.localRotation =  Quaternion.identity;
    end

    if IsNil(hudTrans) == false then
        -- hud的位置x、z都清零
        local pos = hudTrans.localPosition;
        pos.x = 0;

        hudTrans.localPosition = pos;
    elseif not IsNil(self._modelRoot) then
        -- 如果在正常部位沒找到hud節點，則開始找newhud，這個是自己創建的代節點。
        hudTrans = self._modelRoot:Find("__newhud");
        if IsNil(hudTrans) then
            hudTrans = GameObject.New("__newhud").transform;
            hudTrans.parent = self._modelRoot;
        end;

        -- 有模型但是没Hud的可能是特效，所以挂低一点
        if self._model then
            hudTrans.localPosition = Vector3.New(0, 0.75, 0);
        else
            -- 没模型的，说明是角色，挂高点
            hudTrans.localPosition = Vector3.New(0, 2, 0);
        end;
    end;

    return hudTrans;
end;

function Actor:CreateHud()

    self:DestroyHud();

    --  ErrorFormat("Actor:CreateHud():name = %s; isDead = %s; key = %s", self:GetName(), tostring(self:IsDead()), self:GetActorKey());

    if self._ifHideHud or self._isDead or self:GetType() == ActorType_UIModel then
        return ;
    end;

    -- 如果hudtype == 0，不显示hud
    local typeConfig = self:GetTypeConfig();
    if not typeConfig or typeConfig.hudtype == 0 then
        return ;
    end;

    local hudTrans = self:PrepareHudNode();
    if hudTrans then
        local hud = HudEx:New(hudTrans);
        local titleBitNum = MapManager.GetCommonConfig().showIDTitle or 15
        hud:SetName(self._name);
        hud:SetNameColor(HudUtil_GetActorNameColor(self));
        hud:SetShowName( typeConfig.showname ~= 0);
        hud:SetNation(self:GetFixedCamp());
        hud:SetShowNation(self:GetType() == ActorType_Player);
        hud:SetMaxHp(self:GetMaxHp());
        hud:SetHp(self:GetHp());

        -- local mode = LOCAL_CHAR:IsEnemy(self) and 1 or 0;
        --PromptPanel.ShowDebugMessage("mode = "..tostring(mode)..", name = "..self:GetName())
        hud:SetHpMode(LOCAL_CHAR:GetHPMode(self));
        -- hud:SetHpMode(mode);
        hud:SetShowHp(self:CheckNeedShowHudHp());

        --local title = self._title or self:GetTipName() or "";
        local title = self._title or self:GetFuncName() or self:GetTipName() or "";
        -- if not self:GetFuncName() then
        -- title = self:ChangeColorWithPro(title)
        -- end
        hud:SetSimpleTitle(title, self:GetSimpleTitleColorHex());
        --hud:SetSimpleTitle("<color=#00ab37>"..title.."</color>");
        hud:SetShowSimpleTitle(title and #title > 0);

        -- hud:SetShowCoupleTitle(self._coupleTitle and #self._coupleTitle > 0);
        hud:SetCoupleTitle(self._coupleTitle);

        hud:SetFamilyInfo(HudUtil_GetActorFamilyNameAndColor(self));
        -- hud:SetShowFamilyInfo(self._familyName and #self._familyName > 0);
        hud:SetShowRealm(self:GetType() == ActorType_Player);

        hud:SetRealm(self:GetRealm());

        hud:SetTitleID(self._titleId);
        -- hud:SetShowIDTitle(titleBitNum == 1);

        hud:SetOfficialTitle(self._official);

        hud:SetShowFamilyInfo((self._familyName and #self._familyName > 0) and (bit.band(titleBitNum, 1) >= 1)) -- 帮派
        hud:SetShowCoupleTitle((self._coupleTitle and #self._coupleTitle > 0) and (bit.band(titleBitNum, 2) >= 2)) -- 情侣       
        hud:SetShowIDTitle(bit.band(titleBitNum, 4) >= 4) -- 称号
        local showOfficialID = FixedCampManager.GetOfficialNameSpriteID(self._official, self:GetFixedCamp())
        hud:SetShowOfficialTitle((showOfficialID ~= nil and #showOfficialID > 0) and (bit.band(titleBitNum, 8) >= 8)) -- 阵营

        hud:SetSayImage();
        hud:SetShowSayImage(false);

        --[[
        LOCAL_CHAR._hud:SetSayImage(1);
        LOCAL_CHAR._hud:SetShowSayImage(true);
        Timer.New(function() LOCAL_CHAR._hud:SetShowSayImage(false) end , 3, 1):Start()
        ]]

        hud:Start();

        self._hud = hud;
    end;
end;

function Actor:CheckNeedShowHudHp()
    local _gradeConfig  = MapManager.GetCommonConfig(MapManager.GetCurMapID());
    if _gradeConfig == nil or _gradeConfig.hudHpMode == nil then return false end
    local hudHpMode = 0
    if self:GetType() == ActorType_Npc then
        hudHpMode = _gradeConfig.hudHpMode % 10
    else
        hudHpMode = math.floor(_gradeConfig.hudHpMode / 10) % 10
    end

    if hudHpMode == 0 then
        return false
    elseif hudHpMode == 1 then
        return true
    else
        return self:IsFighting()
    end
end

function Actor:GetSimpleTitleColorHex()
	local color = "ffffffff";
	
	local cfg = self:GetTypeConfig()
	if cfg then
		if cfg.tips_pro == 1 then
			color = "7fff94ff";
		elseif cfg.tips_pro == 2 then
			color = "7fd6ffff";
		elseif cfg.tips_pro == 3 then
			color = "da8bffff";
		elseif cfg.tips_pro == 4 then
			color = "ffb32fff";
		end
	end;
	
	return color ;
end;

function Actor:ChangeColorWithPro(title)
    local cfg = self:GetTypeConfig()
    title = title or ""
    if cfg == nil then return title end
    if cfg.tips_pro == 1 then
        title = "<color=#7fff94>"..title.."</color>"
    elseif cfg.tips_pro == 2 then
        title = "<color=#7fd6ff>"..title.."</color>"
    elseif cfg.tips_pro == 3 then
        title = "<color=#da8bff>"..title.."</color>"
    elseif cfg.tips_pro == 4 then
        title = "<color=#ffb32f>"..title.."</color>"
    end
    return title;
end

function Actor:CheckCanAddHp()
    local mapId = MapManager.GetCurMapID();
    local isInFengMoTaMap = FengMoTaPanel.CheckIsInFengMoTaMap(mapId);

    if isInFengMoTaMap then
        --如果在封魔塔中，只有战斗的时候使用技能方可回血
        if not FengMoTaFightPanel.CheckIsInFight() then
            --PromptPanel.ShowNewMessage("封魔塔进入战斗以后才可以回血");
            return false;
        end
    end

    return true;
end

function Actor:OnHpChange()

    if self == LOCAL_CHAR and self:GetHp() == 0 then
        --error("卧槽啊")
    end

    self:SetHudDirty();
    --主角血量低于30%的时候做一个屏幕特效表现
    if self == LOCAL_CHAR  then
        if not self:IsDead() then
            local percent = self:GetHp() / self:GetMaxHp();
            --            error("OnHpChange percent = "..percent);
            if percent < 0.3 then
                CameraEffectsManager.BeginLowHpEffects();
            else
                CameraEffectsManager.EndLowHpEffects();
            end
        end;
        ---MainPanel.RefreshRoleHp(self:GetHp(), self:GetMaxHp());
    end

    --boss大血条
    if self._hpChangeHandler then
        self._hpChangeHandler.HpChangeHandler_OnRefresh(self:GetName(), self:GetLevel(), self:GetHp(), self:GetMaxHp());
    end;
    --[[if BossHpPanel and self == BossHpPanel.GetTarget() then
        BossHpPanel.Refresh();
    end;]]

        if self._ai then
            self._ai:OnHpChange(self:GetHp(), self:GetMaxHp());
        end;

        if self._hud then
            self._hud:SetMaxHp(self:GetMaxHp());
            self._hud:SetHp(self:GetHp());
        end

        Event.Brocast(CLIENT_EVENT.ON_ACTOR_HP_CHANGED, self, self:GetHp(), self:GetMaxHp());
    end;

    function Actor:UpdateHud(deltaTime)
        if self._hud then
            self._hud:Update(deltaTime);
        end;
    end;

    function Actor:DestroyModel()
        --error("Actor:DestroyModel():name = "..self:GetName().."serial = "..(tostring(self._modelLoadSerial)));
        --self:ClearEquipEffects(); -- 清空特效
        --	self:RevertDissolveEffect();

        self:DoUnBindRide(true);

        if not IsNil(self._model) then
            --error(" Actor:DestroyModel():name  "..self._template.model);

            Util.StopSimulateGravity(self._model.gameObject);
            local modelPath, model = self:GetShownModelPath();
            AssetLoadManager.ReleaseAsset(modelPath, model, self._model, true);
        end;

        self._model = nil;
        self._animator = nil;
        self._model_dir = nil;
        self._footDownEventHandler = nil;
        self._ifModelLoaded = false;
        self._modelLoadSerial = 0;
    end;

    -- function Actor:DestroyChangeBodyModel()
    -- if self._changeBodyModel then
    -- AssetLoadManager.ReleaseAsset(self._changeBodyTemplate.modelPath,  self._changeBodyTemplate.model, self._changeBodyModel, true);
    -- self._changeBodyModel = nil;
    -- self._changeBodyAnimator = nil;
    -- end;
    -- end;

    function Actor:DestroyShadow()
        if self._shadow then
            AssetLoadManager.ReleaseAsset(ACTOR_SIMPLE_SHADOW_AB, ACTOR_SIMPLE_SHADOW_ASSET, self._shadow, true)
            self._shadow = nil;
        end;
        self._shadowLoadSerial = 0;
    end;
    ------------------------------------------------
    -- 销毁，todo
    function Actor:Destroy()
        --  --error("Actor:Destroy():"..self:GetName());
        Event.Brocast(CLIENT_EVENT.ON_ACTOR_PRE_DESTROY, self:GetActorKey(), self);
        self._stage = ActorStage_Destroyed;
        --self:ClearEquipEffects(); -- 清空特效

        self:NtfDestroy();

        self:DestroyHud();
        self:ClearAllModel();
        --self:DestroyChangeBodyModel();

        self._animator = nil;
        -- self._changeBodyAnimator = nil;
        self._nav = nil;
        self._originalShaderList = nil;
        if self._updateShadowCom then
            self._updateShadowCom.enabled = false;
        end;

        if self._hierarchy then
            ActorManager.ReleaseActorHierarchy(self._hierarchy);
            self._hierarchy = nil;
        end;

        self._ridingFlyAgent = nil;
        self._transform = nil;
        self._actorRoot = nil;
        self._scaleRoot = nil;
        self._rideRoot = nil;
        self._modelRoot = nil;
        self._collider = nil;

        self._materials = {};

        if self._hpChangeHandler then
            MainPanel.HpChangeHandler_OnEnd(self);
            self._hpChangeHandler = nil;
        end;

        AutoFlyManager.Stop(self);
    end;

    function Actor:DisableAnimationState()

        for k, v in pairs(self._DestroyListenerList) do
            --		if k.name == "FcAction_Animation" then
            if k._animName ~= nil then
                --			error("Actor:DisableAnimationState() "..k._animName);
                k._isDisblaeEnd = true;
            end
        end
    end

    function Actor:AddDestroyListener(listener)
        --table.insert(self._DestroyListenerList, listener);
        self._DestroyListenerList[listener] = 1;
    end;

    function Actor:DelDestroyListener(listener)
        self._DestroyListenerList[listener] = nil;
    end;

    function Actor:NtfDestroy()
        for k, v in pairs(self._DestroyListenerList) do
            k:OnActorDestroyed(self);
            self._DestroyListenerList[k] = nil;
        end;
    end;

    function Actor:AddDeadListener(listener)
        self._DeadListenerList [listener] = 1;
    end;
    function Actor:DelDeadListener(listener)
        self._DeadListenerList [listener] = nil;
    end;
    function Actor:NtfDead()
        for k, v in pairs(self._DeadListenerList) do
            k:OnActorDeadNtf(self);
        end;
    end;

    ------------------------------------------------
    function Actor:SetActorKey(key)
        self._actorKey = key;
    end;

    function Actor:GetActorKey()
        return self._actorKey;
    end;

    function Actor:EnableDynamicShadow()
        if self._shadowProjector == nil then return end;
        self._shadowProjector.enabled = true;
    end

    function Actor:DisableDynamicShadow()
        if self._shadowProjector == nil then return end;
        self._shadowProjector.enabled = false;
    end

    function Actor:EnableFixShadow()
        if self._shadow == nil then return end;
        self._shadow.gameObject:SetActive(true);
    end

    function Actor:DisableFixShadow()
        if self._shadow == nil then return end;
        self._shadow.gameObject:SetActive(false);
    end

    function Actor:UpdateShadowState()
        if self._isCloseDynamicShadow == nil then self._isCloseDynamicShadow = false end;
        --	error("self._isCloseDynamicShadow = "..tostring(self._isCloseDynamicShadow));

        --	if not self._isCloseDynamicShadow then
        if not true then
            --error("Actor:EnableDynamicShadow();");
            self:EnableDynamicShadow();
            self:DisableFixShadow();
        else
            --error("Actor:DisableDynamicShadow();");
            self:EnableFixShadow();
            self:DisableDynamicShadow();
        end
    end

    function Actor:SetAudioListnerEnable(enable)
        if not self._audioListner then
            self._audioListnerObj = GameObject.New("audioListener");
            self._audioListnerObj.transform:SetParent(self._transform);
            self._audioListner = self._audioListnerObj:AddComponent(AudioListener.GetClassType());
        end;

        if enable then
            self._audioListnerObj.transform.localPosition = Vector3.New(0,0,0);
        else
            self._audioListnerObj.transform.localPosition = Vector3.New(-999,-999,-999);
        end;

    end;

    function Actor:CreateLocalCharSpecial()

        -- local_char 添加刚体和碰撞体
        local rigid = self._transform.gameObject:AddComponent(Rigidbody.GetClassType());
        rigid.isKinematic = true;
        rigid.mass = 60;
        rigid.useGravity = false;
        self.rigidbody = rigid;
        --self._transform.gameObject.tag = "LOCAL_CHAR";

        if self._collider then
            self._collider.size = Vector3.New(0.1, 2, 0.1);
        end;

        Actor.SetLocalCharAudioListenerEnable(LocalCharAudioListenerEnable);

        --临时设置一下方向定参数
        local sceneName = MapManager.GetCurMap().scene
        if sceneName == nil then sceneName = "nil" end;

        local dirInfo = ActorShadowDir[sceneName];
        if dirInfo == nil then
            --        PromptPanel.ShowMessageBox("dirInfo is nil, sceneName = "..sceneName);
            dirInfo = {x = 1, y = -1.5, z = 1};
        end

        --手动调用一下，防止globalProjectorManager不存在的问题
        self:DisableDynamicShadow();
        self:EnableFixShadow();
    end;


    function Actor:CreateAnimator()
        self._animator = self._model:GetComponent(Animator.GetClassType());
        -- self._animator = self._model:GetComponent("Animator");
        if self._animator then
            self._animator.enabled = true;

            -- self._animator.cullingMode = AnimatorCullingMode.CullUpdateTransforms;
            if self:IsMoving() then
                self._animator:SetFloat(Actor.AnimatorStringHash("speed"), self:GetMaxSpeed() / 10);
            end;

            if self._isFighting then
                self._animator:SetFloat(Actor.AnimatorStringHash("fighting"), 1);
            end;

            --        error(self:GetName().." animtime = "..self._animTime .. " anim = " .. self._curAnim)
            if self._animTime > 0 then
                self._animator:SetTrigger(Actor.AnimatorStringHash(self._curAnim));
            end;

            if self._isDead then
                self._animator:SetBool(Actor.AnimatorStringHash("die01"), true);
            end;

            if self:GetType() == ActorType_Player then
                if self:GetUid() ~= LOCAL_UIN then
                    self._animator.fireEvents = false;
                end;
            end;

            if self._animationCache then
                self._animator:SetTrigger(Actor.AnimatorStringHash(self._animationCache));
            end


        end;
    end;

    function Actor:GetTransform()
        return self._transform;
    end;

    function Actor:SetLayer(layer)
        self._layer = layer;
        if self._transform then
            Util.SetAllLayer(self._transform.gameObject, layer);
        end
    end

    function Actor:GetLayer()
        return self._layer;
    end

    -- function Actor:SetTag(tag)
    -- if self._transform then
    -- self._transform.gameObject.tag = tag;
    -- end;
    -- end;

    -- function Actor:GetTag()
    -- return self._transform.gameObject.tag;
    -- end;

    function Actor:GetType()
        return self._type;
    end;

    function Actor:SetType(t)
        self._type = t;
    end

    function Actor:GetCamp()
        return self._camp;
    end;

    function Actor:GetFixedCamp( )
        if self._relation_id == 0 then return 0 end
        return self._relation_id[QY_ROLE_RELATION_ID_TYPE.RELATION_ID_ROLE_FIXED_CAMP+1];
    end

    function Actor:GetTeamID()
        if self._relation_id == 0 then return 0 end
        return self._relation_id[QY_ROLE_RELATION_ID_TYPE.RELATION_ID_FOR_TEAM+1];
    end;

    function Actor:SetFixedCamp( campID )
        self._relation_id[QY_ROLE_RELATION_ID_TYPE.RELATION_ID_ROLE_FIXED_CAMP+1] = campID;
        --self:SetHudDirty();
        if self._hud then
            self._hud:SetNation(campID);
        end
    end

    function Actor:SetFixedCampOfficial(officialID)
        self._official = officialID;
        Event.Brocast(CLIENT_EVENT.ON_SCHOOL_INFO_CHANGED);
        -- self:SetHudDirty();
        if self._hud then
            self._hud:SetOfficialTitle(officialID);
            local titleBitNum = MapManager.GetCommonConfig().showIDTitle or 15
            self._hud:SetShowOfficialTitle((officialID ~= nil and officialID > 0) and (bit.band(titleBitNum, 8) >= 8)) -- 阵营
        end;
    end

    function Actor:GetFixedCampOfficial()
        return self._official;
    end

    function Actor:GetFuncType()
        if self._template then
            return self._template.functype;
        end;
        return 0;
    end;

    function Actor:RefreshNameColor()
        --     if self._hud and self:GetFuncType() == NpcFuncType_Fight then
        -- --error("<color=orange>Name"..self:GetName().."   isFighting = "..(self:IsFighting() and "T" or "F").."</color>")
        --         self._hud:SetHpVisible(self:IsFighting())
        --     end
        --self:SetHudDirty();

        if self._hud then
            -- self._hud:SetHpMode(LOCAL_CHAR:IsEnemy(self) and 1 or 0);
            self._hud:SetHpMode(LOCAL_CHAR:GetHPMode(self));
        end;

        --     if not self._hud then return end
        -- if LOCAL_CHAR == nil then return end

        -- if not InFightMap  then

        --     if self._type == ActorType_Player then

        --         if MapManager.GetCurMap().showHp then
        --             self._hud:SetActiveHp(true);
        --             if self == LOCAL_CHAR then
        --                 self._hud:SetHpColor(HUD_COLORS.Green)
        --             elseif self:IsEnemy(LOCAL_CHAR) then
        --                 self._hud:SetHpColor(HUD_COLORS.Red)
        --             else
        --                 self._hud:SetHpColor(HUD_COLORS.Green)
        --             end;
        --         else
        --             self._hud:SetActiveHp(false)
        --         end;
        --         if self == LOCAL_CHAR then
        --             self._hud:SetName(nil, HUD_COLORS.Green)
        --         else
        --             self._hud:SetName(nil, HUD_COLORS.White)
        --         end;

        -- 	elseif self._type == ActorType_Partner then
        -- 		 self._hud:SetActiveHp(false)
        --        -- else
        --        --     self._hud:SetActiveHp(true);
        --        -- end;
        --         self._hud:SetName(nil, HUD_COLORS.Blue)
        --         self._hud:SetHpColor(HUD_COLORS.Green)
        --     elseif self._type == ActorType_Npc then

        --         if self:GetFuncType() == NpcFuncType_Fight and self:IsFighting() then
        --             self._hud:SetActiveHp(true)
        --             if self:IsEnemy(LOCAL_CHAR) then
        --                 self._hud:SetHpColor(HUD_COLORS.Red)
        --                 self._hud:SetName(nil, HUD_COLORS.Red)
        --             else
        --                 self._hud:SetHpColor(HUD_COLORS.Blue)
        --                 self._hud:SetName(nil, HUD_COLORS.Blue)
        --             end
        --         else
        --             self._hud:SetActiveHp(false)
        --         end;


        --         if self._template.showname == 1 then
        --             self._hud:SetActiveName(true);
        --             self._hud:SetName(nil, HUD_COLORS.Blue)
        --         else
        --             self._hud:SetActiveName(false);
        --         end;
        --     end
        -- else
        --     if LOCAL_CHAR == self then
        --         self._hud:SetActiveHp(true)
        --         self._hud:SetHpColor(HUD_COLORS.Green)
        --         self._hud:SetName(nil, HUD_COLORS.Green)
        --     elseif self._type == ActorType_Npc then
        --         if self._template.functype == NpcFuncType_Fight and self:IsFighting() then
        --             self._hud:SetActiveHp(true);
        --             if self:IsEnemy(LOCAL_CHAR) then
        --                 self._hud:SetHpColor(HUD_COLORS.Red)
        --                 self._hud:SetName(nil, HUD_COLORS.Red)
        --             else
        --                 self._hud:SetHpColor(HUD_COLORS.Blue)
        --                 self._hud:SetName(nil, HUD_COLORS.Blue)
        --             end
        --         else
        --             self._hud:SetActiveHp(false);
        --         end;

        --         if self._template.showname == 1 then
        --             self._hud:SetActiveName(true);
        --         else
        --             self._hud:SetActiveName(false);
        --         end;
        --     else
        --         --其他玩家q
        --         self._hud:SetActiveName(true);
        --         self._hud:SetActiveHp(true);

        --         if self:IsEnemy(LOCAL_CHAR) then
        --             self._hud:SetHpColor(HUD_COLORS.Red)
        --             self._hud:SetName(nil, HUD_COLORS.Red)
        --         else
        --             self._hud:SetHpColor(HUD_COLORS.Blue)
        --             self._hud:SetName(nil, HUD_COLORS.White)
        --         end
        --         if ZhouYuanManager.IsZhouYuanMap(MapManager.GetCurMapID()) then
        --             self._hud:SetName(nil, Color.NewHex(_CH(40+self._camp)));
        --         end
        --     end;
        -- end
    end
    function Actor:SetCamp(camp)

        self._camp = camp;

        if MapFightType == ENUM_MAP_FIGHT_TYPE.PEACE then
            if self:GetType() == ActorType_Player or self:GetType() == ActorType_Partner then

                self._isLocalEnemy = false;
                return ;
            end;
        end;

        if self == LOCAL_CHAR then
            self._isLocalEnemy = false;
            MultiDumpLogic.ReCalcEnemyState(); --重新计算其他人
        else
            if (self:GetType() == ActorType_Npc and self:GetFuncType() == NpcFuncType_Fight) or self:GetType() == ActorType_Player or self:GetType() == ActorType_Partner then
                self._isLocalEnemy = MultiDumpLogic.IsEnemy(LOCAL_CHAR, self);
            else
                self._isLocalEnemy = false;
            end;
        end;



        self:RefreshNameColor();
    end;

    function Actor:SetName(name)
        self._name = name;

        -- self:SetHudDirty()

        if self._hud then
            self._hud:SetName(self._prefix..name);
        end;
    end;

    function Actor:GetName()
        return self._name;
    end;

    function Actor:GetFuncName()
        local funcName = self:GetTypeConfig().functionName
        if funcName == 0 then funcName = nil end
        return funcName or nil;
    end;

    function Actor:GetTipName()
        local cfg = self:GetTypeConfig()
        if cfg.tips_type ~= 0 then return end
        local tipName = cfg.tip_name
        if  tipName == 0 then
            tipName = nil
        end
        return tipName
    end

    function Actor:SetVip(vip)
        self._vip = vip;
        self:SetHudDirty();
    end

    function Actor:GetVip()
        return self._vip or 0;
    end

    function Actor:SetTempLevel(level)
        self._tempLevel = level
        self:SetHudDirty();
    end

    function Actor:GetTempLevel()
        return self._tempLevel or 0
    end

    function Actor:SetTempCamp(name)
        self._tempCamp = name
        self:SetHudDirty();
    end

    function Actor:GetTempCamp()
        return self._tempCamp or ""
    end

    function Actor:SetTitle(title)
        self._title = title;
        --self:SetHudDirty();

        if self._hud then
            self._hud:SetSimpleTitle(self._title, self:GetSimpleTitleColorHex());
            self._hud:SetShowSimpleTitle(self._title and #self._title > 0);
        end
    end;

    function Actor:SetCoupleTitle(coupleTitle)
        self._coupleTitle = coupleTitle;

        if self._hud then
            self._hud:SetShowCoupleTitle(self._coupleTitle and #self._coupleTitle > 0);
            self._hud:SetCoupleTitle(self._coupleTitle);
            local titleBitNum = MapManager.GetCommonConfig().showIDTitle or 15
        end
    end;

    function Actor:GetTitle()
        --  self._title = self:ChangeColorWithPro(self._title)
        return self:ChangeColorWithPro(self._title) or "";
    end;

    function Actor:SetTitleID(titleId)
        self._titleId = titleId;
        --   self:SetHudDirty();

        if self._hud then
            self._hud:SetTitleID(self._titleId);
            local titleBitNum = MapManager.GetCommonConfig().showIDTitle or 15
            self._hud:SetShowIDTitle(bit.band(titleBitNum, 4) >= 4) -- 称号
            --	self._hud:SetShowSimpleTitle(self._title and #self._title > 0);
        end

        if self:GetType() == ActorType_Player then
            self:ClearEquipEffects(); -- 清空特效
            self:ProcessEquipEffects();
        end
    end;

    function Actor:GetTitleID()
        return self._titleId or 0;
    end;

    function Actor:SetFamilyName(name)
        self._familyName = name;
        -- self:SetHudDirty();
        if self._hud then
            local titleBitNum = MapManager.GetCommonConfig().showIDTitle or 15
            self._hud:SetShowFamilyInfo((self._familyName and #self._familyName > 0) and (bit.band(titleBitNum, 1) >= 1));
            self._hud:SetFamilyInfo(HudUtil_GetActorFamilyNameAndColor(self));
        end
    end;

    function Actor:GetFamilyName()
        return self._familyName or "";
    end;

    function Actor:SetFamilyPos(position)
        self._familyPos = position;
        self:SetHudDirty();
    end

    function Actor:GetFamilyPos()
        return self._familyPos or 0;
    end

    function Actor:SetHp(hp, needCheckState)
        if needCheckState == nil then
            needCheckState = true;
        end

        if hp < 0 then hp = 0 end;

        --这不是挖坑，是以后要应对不能加血的情况，先客户端来做一下，改善体验
        local oldHp = self:GetHp();
        --	error(string.format("old hp  = %d, new hp = %d", oldHp, hp));
        --[[if needCheckState and hp > oldHp then
            if not self:CheckCanAddHp() then
                error("Actor:SetHp 当前状态不能回血");
                return;
            end
        end--]]

        self:SetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_CUR, hp);
        -- SetFightAttr 也会触发OnHpChange, 先屏蔽下面的
        --self:OnHpChange();
    end;

    function Actor:GetHp()
        return self:GetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_CUR);
    end;

    function Actor:SetMaxHp(maxHp)
        if type(maxHp) == "string" then
            --error("Actor:SetMaxHp maxHp is string: "..maxHp);
        end
        local oldMaxHp = self:GetMaxHp();
        self:SetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_MAX, maxHp);
    end;

    function Actor:GetMaxHp()
        return   self:GetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_MAX);

    end;

    -- 最大速度 -----------------------------
    function Actor:SetMaxSpeed(speed)
        self:SetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_RUN_SPEED, speed);
    end;

    --設置nav的速度統一到這裡  不要在外面調用！
    function Actor:SetNavSpeed(speed)

        if self._navSpeedUp  then return end;

        if AutoFlyManager.IsActorInFlying(self) then return end;

        speed = speed / 10;

        if self._nav then
            self._nav.speed = speed;
            -- if self._changeBodyAnimator then
            --   self._changeBodyAnimator:SetFloat("runactionspeed", math.clamp(speed / self._runAnimationRunSpeed, 0.1, 1.5));
            --else
            if IsNil(self._animator) == false and not self._ridingAnimator then
                self._animator:SetFloat(Actor.AnimatorStringHash("runactionspeed"), math.clamp(speed / self._runAnimationRunSpeed, 0.1, 1.5));
            end
        end
    end
    function Actor:GetMaxSpeed()
        local speed = self:GetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_RUN_SPEED);

        if speed <= 0.1 then
            return 3.33;
        else
            return speed;
        end;
        -- return self:GetFightAttr(ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_RUN_SPEED);
        -- return self:GetAttr(ActorAttr_MaxSpeed);
    end;

    -- 重新计算最大速度
    function Actor:ResetMaxSpeed()
        self:SetMaxSpeed(self:GetMaxSpeed());
    end;
    -- 瞬时速度 -----------------------------
    -- 不要在外部调用这个函数，如果要影响角色的速度，尽量使用SetMaxSpeed
    ---------------------------------------------------------------------------
    function Actor:SetBaseAttr(attrType, attrValue)
        --  --error("Actor:SetBaseAttr:: type = "..attrType.."  val = "..attrValue)
        local oldValue = self._roleBaseAttr[attrType];
        self._roleBaseAttr[attrType] = attrValue;
        if attrValue ~= oldValue then
            self:OnBaseAttrChange(attrType, oldValue, attrValue);
        end;
    end;

    function Actor:GetBaseAttr(attrType)
        return self._roleBaseAttr[attrType] or 0;
    end;
    ---------------------------------------------------------------------------
    function Actor:SetFighting(isFighting)

        if isFighting == self._isFighting then
            return ;
        end;

        self._isFighting = isFighting;
        -- self._animator:SetBool("isFighting", isFighting);
        -- if self._changeBodyAnimator then
        -- local value = 0;
        -- if isFighting then
        -- value = 1;
        -- end;
        -- self._changeBodyAnimator:SetFloat("fighting", value);
        -- else
        if not IsNil(self._animator) then
            local value = 0;
            if isFighting then
                value = 1;
            end;
            self._animator:SetFloat(Actor.AnimatorStringHash("fighting"), value);
        end;

        if self._ai then
            self._ai:OnSetFighting(isFighting);
        end;

        if self._hud then
            self._hud:SetShowHp(self:CheckNeedShowHudHp());
        end

        self:RefreshNameColor()

        Event.Brocast(CLIENT_EVENT.ON_ACTOR_FIGHT_STATE_CHANGED, self, isFighting);
    end;

    function Actor:IsFighting()
        return self._isFighting;
    end;

    --不想做成action, 因为这个会频繁创建dotween, 所以直接做到actor里面来, 并且缓存dotween
    --闪白效果
    function Actor:PlayBlinkWhite(render)
        if self:GetType() ~= ActorType_Npc then
            return;
        end

        if IsNil(render) or IsNil(render.material) then
            return;
        end

        if not render.material:HasProperty("_lerpVal") then
            return
        end;

        if self._blinkWhiteSeqList == nil then
            self._blinkWhiteSeqList = {};
        end;

        if self._blinkWhiteSeqList[render.name] == nil then
            self._blinkWhiteSeqList[render.name] = {}

            local sequence = DoTween.Sequence();
            local changeTween = DoTweenHelper.DoSetShaderProperty_Float(render.material, "_lerpVal", 2, 0, 0.1);
            --DoTweenSetting.AppendInterval(sequence, 1);
            DoTweenSetting.Append(sequence, changeTween);
            DoTweenHelper.SetAutoKill(sequence, false)

            self._blinkWhiteSeqList[render.name].seq = sequence;
            self._blinkWhiteSeqList[render.name].render = render;
        end

        if self._blinkWhiteSeqList[render.name] ~= nil then
            DoTweenExtensions.Restart(self._blinkWhiteSeqList[render.name].seq, true, -1);
        end
    end

    --强制恢复闪白效果, 避免死亡的那一瞬间, 全白的情况
    function Actor:ReverBlinkWhite()
        if self._blinkWhiteSeqList == nil then return end;
        for k,v in pairs(self._blinkWhiteSeqList) do
            if v ~= nil then
                if v.seq ~= nil then
                    DoTweenHelper.StopTween(v.seq, true);
                    if v.render ~= nil and v.render.material ~= nil then	--避免已经被卸载的情况
                        v.render.material:SetFloat("_lerpVal", 0);
                    end
                end
            end
        end
    end
    --[[function Actor:StopAllDissolveEffect()
        if self._dissolveList == nil then return end;
        for k,v in pairs(self._dissolveList) do
            if v ~= nil then
                DoTweenExtensions.StopTween(v);
            end
        end
    end--]]

    function Actor:PlayDissolveEffect()
        if self:GetType() ~= ActorType_Npc then
            return
        end;

        --PromptPanel.ShowDebugMessage("PlayDissolveEffect()");
        if self._dissolveList == nil then
            self._dissolveList = {};
        end

        local arr = self._modelRoot.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType())
        for i = 0, arr.Length - 1 do
            local render = arr[i];

            if self._dissolveList[render.name] == nil then
                self._dissolveList[render.name] = FcAction_DissolveEffect.CreateDissovleAction(self, render);
            end
        end
    end

    function Actor:RevertDissolveEffect()
        if IsNil(self._modelRoot) then return end;

        local arr = self._modelRoot.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType())
        for i = 0, arr.Length - 1 do
            local render = arr[i];
            if not IsNil(render) and not IsNil(render.material) then
                if render.material:HasProperty("_DissolveThreshold") then
                    render.material:SetFloat("_DissolveThreshold", 0);
                end
            end;
        end
    end

    function Actor:CreateDissolveTween(render)
        if IsNil(render) then
            PromptPanel.ShowDebugMessage("Actor:CreateDissolveTween(render) render is nil, actorName = "..self:GetName());
            return
        end;

        local mat = render.material;
        if IsNil(mat) then
            PromptPanel.ShowDebugMessage("mat is nil, actorName = "..self:GetName())
            return;
        end

        if not mat:HasProperty("_DissolveThreshold") then
            PromptPanel.ShowDebugMessage("角色没有 dissovle属性, 请检查shader, actorName = "..self:GetName())
            return;
        end

        mat:SetTexture("_DissolveMap", ABTextureManager._dissolveTex);

        local sequence = DoTween.Sequence();
        local changeTween = DoTweenHelper.DoSetShaderProperty_Float(mat, "_DissolveThreshold", 0, 1, 2);
        local reverTween = DoTweenHelper.DoSetShaderProperty_Float(mat, "_DissolveThreshold", 0, 0, 0.1);
        --DoTweenSetting.AppendInterval(sequence, 1);
        DoTweenSetting.Append(sequence, changeTween);
        DoTweenSetting.Append(sequence, reverTween);
        DoTweenHelper.SetAutoKill(sequence, false)
        return sequence;
    end

    function Actor:SetDead(dead)
        --self:PlayDissolveEffect();
        --ErrorFormat("Actor:SetDead():name = %s; isDead = %s; key = %s", self:GetName(), tostring(dead), self:GetActorKey());

        if self._isDead == dead then return end;
        self._isDead = dead;

        if self ~= LOCAL_CHAR then
            self:DisablePlaneDynamicShadow();
        end

        self:SetHudDirty();
        -- if self._changeBodyAnimator then
        -- self._changeBodyAnimator:SetBool("die01", dead);
        -- else
        if self._animator then
            self._animator:SetBool(Actor.AnimatorStringHash("die01"), dead);
        end

        if self._template.dieskill > 0 then
            SkillManager.OnRoleCastSkillNtf(self, nil, nil, self._template.dieskill, 0);
        end;

        -- if self._nav and self._ifOnTargetMap and self._nav.isOnNavMesh then
        -- self._nav.enabled = not dead;
        -- end;

        if dead then
            self:StopNav();
            self:DisableNav();
            self:ReverBlinkWhite();
        else
            self:EnableNav();
        end;

        if dead then
            self._stage = ActorStage_Dead;
            self._deadTime = 0;
            if self._shiftMove then
                self._shiftMove = nil;
            end;
        else
            self._stage = ActorStage_Alive;
            --		self:RevertDissolveEffect();
            -- self:DoAnimation("idle01")
        end;

        if self._type == ActorType_Npc and self._hud then
            self._hud:SetActive(not dead)

            -- if dead then
            -- 	self._hud:SetActiveHp(false);
            -- 	self._hud:SetActiveName(not dead);
            -- else
            -- 	self._hud:SetActiveHp(true);
            -- 	self._hud:SetActiveName(not dead);
            -- end
        elseif self._type == ActorType_Player and self._hud then

            -- TODO
            if dead then
                --  self._hud:SetActiveHp(false);
                --self._hud:SetActiveName(false);
            else
                --  self._hud:SetActiveHp(true);
                self:RefreshNameColor();
                --self._hud:SetActiveName(true);
            end
        end;

        if dead then
            Event.Brocast(CLIENT_EVENT.ON_CLIENTLOGIC_ACTOR_DEAD, self);
            local dieSound = self._template.diesound;
            if dieSound > 0 then
                local params = {type = FcAction_Sound; id = dieSound;lifetime=2;offsettime=0;}
                FcActionFactory.CreateAction(params, self, nil, nil);
            end;

            self:NtfDead();
        else
            Event.Brocast(CLIENT_EVENT.ON_CLIENTLOGIC_ACTOR_RELIVE, self);
        end;

        if self == LOCAL_CHAR   then
            if dead and MapManager.GetCommonConfig().map_type ~= 3 then
                CameraEffectsManager.EndLowHpEffects();
                CameraEffectsManager.BeginGray();
            else
                --复活
                Event.Brocast(CLIENT_EVENT.ON_LOACL_CHAR_RELIVE);
                CameraEffectsManager.EndGray();
            end
        end

        if self._ai then
            self._ai:OnDead(dead);
        end;
    end;

    function Actor:SetPos(pos)
        -- error(self:GetName() .. "set po")
        self:DisableNav();

        self._transform.position = pos;


        if   self._ifOnTargetMap then
            --	--error("Actor:SetPos(pos)");
            self:EnableNav();
        end;
    end;

    function Actor:GetPos()

        if self._transform and not IsNil(self._transform) then
            return self._transform.position;
        end;
        return Vector3.zero;
    end;

    function Actor:GetScale()
        return  self._scaleValue;
    end;

    function Actor:GetScaleRoot()
        return self._scaleRoot;
    end

    function Actor:SetScale(scale)
        self._scaleValue = scale;

        if self._scaleRoot then
            self._scaleRoot.localScale = scale;
        end;
    end;


    function Actor:AddScale(scaleValue) --乘法 保证多个缩放同时生效时 最后不会有bug，比如 action 开始乘以2 结束除以二

        if not self._targetScaleValue then
            self._targetScaleValue = self._scaleValue.x ;
        end;

        self._targetScaleValue = self._targetScaleValue * scaleValue ;
        self._scaleValue = Vector3.New(self._targetScaleValue,self._targetScaleValue,self._targetScaleValue);
        DoTweenHelper.DoScale(self._scaleRoot, self._targetScaleValue, 0.2 );
    end;

    function Actor:ToString()
        return "[Actor]name:" .. self._name
        .. "  hp:" .. self:GetHp() .. "/" .. self:GetMaxHp()
        .. "  defence:" .. self:GetDefence();
    end;

    function Actor:SetMoving(moving)
        if self == LOCAL_CHAR and moving == true then               --若要移动的是自己，检测交互状态并打断
            InteractionManager.CheckInteractionAndChange()
        end
        -- ErrorFormat(" Actor:SetMoving(moving):name = %s, isMoving = %s, speed = %s", self._name, tostring(moving), self:GetMaxSpeed());
        local oldMoving = self._isMoving;
        self._isMoving = moving;
        --    self._isNaving = true;

        if self._nav and self ~= LOCAL_CHAR and oldMoving ~= moving and (not InSingleMap  or  moving == true)then
            if self._nav.enabled ~= moving then
                self._nav.enabled = moving;
            end;
        end;

        local speed = self:GetMaxSpeed();
        if InSingleMap then
            speed = speed + (self.buffSpeedChange or 0);
            if speed <= 0.1 then
                speed = 0.1;
            end
        end;

        if not IsNil(self._ridingAnimator) then
            self._ridingAnimator:SetBool(Actor.AnimatorStringHash("moving"), moving);

            -- elseif self._changeBodyAnimator then
            -- if moving then
            -- self._changeBodyAnimator:SetFloat("speed", speed / 10);
            -- if self == LOCAL_CHAR then
            --error("Actor:SetMoving(moving)")
            -- end
            -- self:EndSkillAnimation();
            -- self:DisableAnimationState()
            -- else
            -- self._changeBodyAnimator:SetFloat("speed", 0);
            -- end

        elseif not IsNil(self._animator) then
            if moving then
                self._animator:SetFloat(Actor.AnimatorStringHash("speed"), speed / 10);
                if self == LOCAL_CHAR then
                    --				error("Actor:SetMoving(moving)")
                end
                self:EndSkillAnimation();
                self:DisableAnimationState();
            else
                self._animator:SetFloat(Actor.AnimatorStringHash("speed"), 0);
            end

        end;

        self:SetNavSpeed(speed);
        --self:SetSpeed(moving and speed);
    end;

function Actor:IsMoving()
    return self._isMoving;
end;

------------------------------------------------

-- 播放动作，事件默认是nil，也就是不计时
function Actor:DoAnimation(anim, animTime, force, params)

    -- if self ~= LOCAL_CHAR then
    -- error(self:GetName() .. "do animation " .. anim)
    -- end;

    if self._ridingAnimator then
        return ;
    end;

    local baseSpeed = 1;
    if params ~= nil then
        baseSpeed = params._baseSpeed or 1;
    end

    if self == LOCAL_CHAR and anim == "run01" then
        --error("Actor:DoAnimation run01");
        baseSpeed = 1;
        self:SetAnimSpeed(baseSpeed);
    end

    --error(string.format("anim: %s, baseSpeed %f", anim, baseSpeed));

    local currPriority = self._animPriority;
    if self:IsMoving() then
        currPriority = LogicConfig.AnimPriority["run01"]
    end;
    local newAnimPrior = LogicConfig.AnimPriority[anim] or 1;
    if force or newAnimPrior >= currPriority then

        self._curAnim = anim;
        self._animPriority = newAnimPrior;
        self._animTime = animTime;

        -- 有可能这个时候还没有model，也没有animator

        if self._animator then

            self:SetAnimSpeed(baseSpeed);

            -- if self._changeBodyAnimator then
            -- self._changeBodyAnimator:SetTrigger(self._curAnim);
            -- else
            if self._animator then
                self._animator:SetTrigger(Actor.AnimatorStringHash(self._curAnim));

            end;
        else
            self._animationCache = self._curAnim;
        end;

        return true;
    end;

    return false;
end;

function Actor:SetAnimatorBool(name, value)
    -- if( LOCAL_CHAR == self) then
    --     error("local char stop!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    -- end;
    -- if self._ridingAnimator then return end;
    -- if self._animator then

    if IsNil(self._animator) == false then
        self._animator:SetBool(Actor.AnimatorStringHash(name), value);
    end;
end;

function Actor:SetAnimatorFloat(name, value)
    -- if( LOCAL_CHAR == self) then
    --     error("local char stop!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    -- end;
    -- if self._ridingAnimator then return end;
    -- if self._animator then

        -- else
    if not self._animator then return end
    if IsNil(self._animator) == false then
        self._animator:SetFloat(Actor.AnimatorStringHash(name), value);
    end;
end;

function Actor:RawPlayAnimationState(name)
    -- if self._changeBodyAnimator then
    -- self._changeBodyAnimator:Play(name);
    -- else
    if self._animator then
        self._animator:Play(name);
    end;
end;

function Actor:GetCurAnimation()
    return self._curAnim;
end;

function Actor:ResetAnimation()
    -- if( LOCAL_CHAR == self) then
    --     error("local char stop!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    -- end;
    self:DoAnimation("idle01", nil, true);
end;

function Actor:SetCanBreakByMoveState(state)
    self._canBreakByMove = state;
end

function Actor:IsCanBreakByMove()
    if self._canBreakByMove == nil then
        return true;
    end
    return self._canBreakByMove;
end

function Actor:EndSkillAnimation()
    if AutoFlyManager.IsActorInFlying(self) then
        return ;
    end;

    if not self:IsCanBreakByMove() then return end;

    if not self._isInSkillAnimation then return end;

    if self._ridingAnimator then return end;

    self._beginSkillNum = self._beginSkillNum - 1;

    if self._beginSkillNum > 0 then
        return
    elseif self._beginSkillNum < 0 then
        -- error("Actor:EndSkillAnimation() is less than 0")
    end

    --	error("Actor:EndSkillAnimation() self._beginSkillNum = "..self._beginSkillNum);

    if not self:IsCanBreakByMove() then return end;
    --error("Actor:EndSkillAnimation() self._beginSkillNum = "..self._beginSkillNum);
    --if self._changeBodyAnimator then
    --		self._changeBodyAnimator:SetFloat("endSkill", 1);
    --	self._changeBodyAnimator:CrossFade("idle01", 0);
    --else
    if self._animator then
        --		self._animator:SetFloat("endSkill", 1);
        self._animator:CrossFade(Actor.AnimatorStringHash("idle01"), 0);
    end
    self._isInSkillAnimation = false;
end

function Actor:BeginSkillAnimation()
    if not self:IsCanBreakByMove() then return end;
    --error("Actor:BeginSkillAnimation()");
    self._isInSkillAnimation = true;

    if self._beginSkillNum == nil then
        self._beginSkillNum = 0;
    end

    self._beginSkillNum = self._beginSkillNum + 1;
    --[[if self._changeBodyAnimator then
        self._changeBodyAnimator:SetFloat("endSkill", 0);
    elseif self._animator then
        self._animator:SetFloat("endSkill", 0);
    end--]]
end

function Actor:SetAnimSpeed(speed)
    --	--error(string.format("SetAnimSpeed: %f", speed));
    -- if self._changeBodyAnimator then
    -- self._changeBodyAnimator.speed = speed;
    -- else
    if self._animator then
        self._animator.speed = speed;
    end
end;

function Actor:GetAnimSpeed()
    if self._animator then
        return self._animator.speed;
    end;
    return 1;
end;

function Actor:ResetAnimSpeed()
    self:SetAnimSpeed(self:GetBaseAnimSpeed());
end;

function Actor:GetBaseAnimSpeed()
    return self._baseAnimSpeed;
end;
function Actor:SetBaseAnimSpeed(baseAnimSpeed)
    self._baseAnimSpeed = baseAnimSpeed;
end;
-------------------------------------------------
-- 寻路 -----------------------------------------

function Actor:IsNavEnabled()
    return self._nav and self._nav.enabled and self._nav.isOnNavMesh;
end;



function Actor:EnableNav()
    -- error(self:GetName().." enable nav")
    if not self._ifOnTargetMap or self:GetType() == ActorType_UIModel then
        return ;
    end;

    if self._ridingFlying then
        self._navAgentFailed = true;

        --这里找个地方
        if self == LOCAL_CHAR then
            local targetPos = self._transform.localPosition;
            targetPos = MapManager.SamplePosition(targetPos.x, targetPos.y, targetPos.z, NavMeshLayerMask.Walkable);
            if targetPos then
                self._transform.localPosition = targetPos + Vector3.New(0,1,0)
            end;
        end
        return
    end;

    if self == LOCAL_CHAR and TraficManager.IsInTrafic() then
        return;
    end;

    if AutoFlyManager.IsActorInFlying(self) then
        if self == LOCAL_CHAR then
            return
        else
            AutoFlyManager.StopV3(self)
        end
    end;

    local targetPos = self._transform.position;
    --  --error("actor orig pos is :"..self:GetName().." pos = ");
    --  --errorTable(targetPos);

    targetPos = MapManager.SamplePosition(targetPos.x, targetPos.y, targetPos.z, NavMeshLayerMask.Walkable);
    if not targetPos then
        self._navAgentFailed = true;
        return ;
    end;

    self._transform.position = targetPos;

    if not self._nav and self:GetFuncType() ~= NpcFuncType_Obstacle and self:GetFuncType() ~= NpcFuncType_FreeFight and self._type ~= ActorType_UIModel then

        if true or (self == LOCAL_CHAR or InSingleMap) then
            self._nav = self._hierarchy._nav;
        else
            self._nav = self._hierarchy._liteNav;
        end;

        --	self._nav.enabled = true;
        self._nav.acceleration = 500;
        self._nav.angularSpeed = 999999;
        self._nav.stoppingDistance = 0.01;
        self._nav.radius = 0.01;

        self:SetMaxSpeed(self:GetMaxSpeed());
    end;

    --error(" Actor:EnableNav():2");
    if self._nav and self == LOCAL_CHAR then
        self._nav.enabled = true;
    end;

    self._navAgentFailed = false;
end;

function Actor:DisableNav()

    if self:GetType() == ActorType_UIModel or AutoFlyManager.IsActorInFlying(self) then
        -- self._navAgentFailed = true;
        return
    end;

    if self._nav then
        self._nav.enabled = false;
    end;
end;
function testnav()

    local v1 = Vector3.New(47.4,0,81.7);
    local v2 = Vector3.New(57.4,0,80.7);
    local v3 = Vector3.New(70.4,0,74.4);

    LOCAL_CHAR:SetPath(v1,v2,v3);
end;

--提交一个路径 这个路径必须是正确的路径 NavMeshPath对象
function Actor:SubmitNavPath(path)
    if self._nav and self._nav.enabled and self._nav.isOnNavMesh then
        self._nav:SetPath(path);
        if self == LOCAL_CHAR then
            SyncManager.ReqRoleWalk(path)
        end;
    end;
end;

local tmpNavMesh = UnityEngine.AI.NavMeshPath.New();
function Actor:StartNav(pos, stopDistance, speedScale, areaMask, noSamplePosition)
    if not pos then return end;

    if self:IsRideFlying() then
        -- if self == LOCAL_CHAR then
        --     RideFlyController.StartNav(pos, stopDistance, speedScale, areaMask, noSamplePosition)
        -- end;
        return;
    end;

    areaMask = areaMask or NavMeshLayerMask.Walkable;
    if self._nav then
        self._nav.areaMask = areaMask;
        self._nav.stoppingDistance = stopDistance or 0.1;
    end;
    --if  self._autoFlying then return end;

    local targetPos = nil;

    if not noSamplePosition then
        targetPos = MapManager.SamplePosition(pos.x, pos.y, pos.z, areaMask);
        if not targetPos then
            --error("sdfsdfsdfdsfdsfsdf")
            return ;
        end;
    else
        targetPos = pos:Clone();
    end;

    if self == LOCAL_CHAR and InSingleMap then
        BuffServer.DoLocalCharOperDeleteBuff();
    end;
    self._currTargetPos = targetPos;

    -- if self == LOCAL_CHAR then
    -- error(" Actor:StartNav(pos, stopDistance, speedScale, areaMask):realTarget = "..tostring(targetPos));
    -- end;
    self._isNaving = true;
    self:SetMoving(true);
    if self._nav and self._nav.enabled and self._nav.isOnNavMesh then

        self._nav.areaMask = areaMask;
        if not stopDistance then
            stopDistance = 0.1
        end;

        self._navTarget = targetPos;
        self._navStopDistanceSqr = stopDistance * stopDistance;

        if self == LOCAL_CHAR then
            local ret = self._nav:CalculatePath(targetPos, tmpNavMesh);
            if ret then
                self._nav:SetPath(tmpNavMesh);
                SyncManager.ReqRoleWalk(tmpNavMesh)
            else

                --  error("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv"..pos.x.." "..pos.y.." "..pos.z)
                return;
            end;
        else
            self._nav.areaMask = areaMask;
            self:SetNavSpeed(self:GetMaxSpeed() * (speedScale or 1));
            self._nav:SetDestination(targetPos);
        end;
    elseif self._transform then
        self._transform.position = targetPos;
        self:SetMoving(false)
    end;

    --   error("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"..pos.x.." "..pos.y.." "..pos.z)
    return targetPos;
end;

function Actor:GetCurrTargetPos()
    return self._currTargetPos;
end;

function Actor:IsNaving()
    return self._isNaving;
end;

function Actor:StopNav(noticServer)

    --error("Actor:StopNav(noticServer)");
    if self:IsRideFlying() then
        return
    end;

    if self == LOCAL_CHAR and AutoFlyManager.IsActorInFlying(self) then
        return;
    end;

    if self._nav then

        if self._nav.enabled and self._nav.isOnNavMesh then

            self._nav:ResetPath();
        end;
        --  error("gouridefangzhagn")
    end;
    self._isNaving = false;
    self:SetMoving(false);

    if self == LOCAL_CHAR and noticServer then
        SyncManager.ReqRoleWalkStop(self:GetPos())
    end;
    self._currTargetPos = self:GetPos();
    self._routeInfo = nil;
end;

function Actor:GetNavDestination()
    if self._nav then
        return self._nav.destination;
    end;
    return Vector3.zero;
end;

function Actor:SetTarget(targetActor)
    self._target = targetActor;
end;

function Actor:GetTarget()
    return self._target;
end;

function Actor:LookAt(target)

    if target then
        self:LookAtPoint(target:GetPos())
    end;
end;

function Actor:LookAtPoint(point)
    point.y = self:GetPos().y;
    self._transform:LookAt(point);
end


------------------------------------------------
-- 技能

function Actor:PushMoveLimit(time)
    if not time or time <= 0 then
        return;
    end;
    self:StopNav();
    time = Time.timeSinceLevelLoad + time;
    if time > self._moveLimitTime then
        self._moveLimitTime = time;
    end;

end

function Actor:PushAttackLimit(time)

    if not time or time <= 0 then
        return;
    end;
    time = Time.timeSinceLevelLoad + time;
    if time > self._attackLimitTime then
        self._attackLimitTime = time;
    end;
end

function Actor:PushNormalAttackLimite(time)
    if not time or time <= 0 then
        return
    end;

    time = Time.timeSinceLevelLoad + time;
    if time > self._normalAttackLimitTime then
        self._normalAttackLimitTime = time;
    end;
end;

function Actor:ResetAttackLimit()
    self._attackLimitTime = Time.timeSinceLevelLoad - 0.1;
end

function Actor:ResetMoveLimit()
    self._moveLimitTime = Time.timeSinceLevelLoad - 0.1;
end

function Actor:SetBorning(boring)
    self._isBorning = boring;
end;

function Actor:IsBorning()
    return self._isBorning;
end;



function Actor:CanAttack(isSkill)

    if isSkill then
        if Time.timeSinceLevelLoad <= self._attackLimitTime then
            return false;
        end
    else

        if Time.timeSinceLevelLoad <= self._normalAttackLimitTime then
            return false;
        end
    end;

    if self._shiftMove then
        return false;
    end;

    if self:IsDead() then
        return false;
    end

    if isSkill and not self._stateCanCastSkill then
        return false;
    end;

    if not isSkill and not self._stateCanAttack then
        return false;
    end;

    if AutoFlyManager.IsActorInFlying(self) then
        return false;
    end;

    return true;
end

function Actor:CanMove()
    if not self._stateCanMove then
        return false;
    end;

    if Time.timeSinceLevelLoad <= self._moveLimitTime then

        return false;
    end

    if self:IsDead() then
        return false;
    end;

    if self._shiftMove ~= nil then

        return false;
    end



    if self == LOCAL_CHAR and TraficManager.IsInTrafic() then return false end;

    if self == LOCAL_CHAR and  LOCAL_CHAR:IsRideFlying() then return true end;

    if not self._nav  then
        return false;
    end;

    if not self._nav.enabled  then
        return false;
    end;

    if not self._ifOnTargetMap then return false end;
    --if not self._nav.isOnNavMesh and not self._nav.isOnOffMeshLink then
    --   return false;
    --end;
    if not self._nav.isOnNavMesh and not self._nav.isOnOffMeshLink then return false end;

    return true;
end;

--
function Actor:TryMoveTo(pos, allow_curve, stopDistance, optimized, areaMask, noSamplePosition)

    self:SetMoving(true)
    if not self:CanMove() then
        --error("草碧草波动爱疯建安大搜附近安山东你放假")
        self:SetMoving(false)
        return false;
    end;
    -- if  self._autoFlying and not GlobalNavManager.IsNaving() then return false end;


    local realPos = pos;


    --self:SetAnimSpeed(1);


    --[[
        if not allow_curve then
            local ret, hit = NavMesh.Raycast(self._transform.position, pos, nil, 1);
            if ret == true then
                pos = hit.position;
                local hitNormal = hit.normal;
                local moveDir = realPos - self:GetPos();
                --这里判断一下  是否卡在墙上了 如果pos与人距离太短  就让他侧身一下咯

                if   (not optimized==true) and Vector3.Distance(pos, self._transform.position) < 0.7 then
                   --沿着墙两个方向
                 --  --error("fuck")
                   local dir1 = FightMathLib.VectorRotate(hitNormal, 90);
                   local dir2 = FightMathLib.VectorRotate(hitNormal, -90);

                   --对比移动方向 与哪一跟的夹角小 就往哪边走
                   local angle1 = Vector3.Angle(moveDir, dir1);
                   local angle2 = Vector3.Angle(moveDir, dir2);

                   local newDir = dir1 * 8 + hitNormal ;
                   if angle1 > angle2 then
                    newDir = dir2 * 8 + hitNormal;
                   end;

                   local newPos = self:GetPos() + newDir * 10;
                   self:TryMoveTo(newPos, true, stopDistance, true);
                   return;
                else

                end;
            end;


        end;
    ]]
    return self:StartNav(pos, stopDistance, nil, areaMask, noSamplePosition);
end

function Actor:IsTeamer(actor)
    if not TeamManager.IsInTeam() then return false end
    -- errorTable(actor:GetServerRoleKey(), ""..actor:GetName())
    return TeamManager.FindTeamMember(actor:GetServerRoleKey()) ~= nil
end


function Actor:IsEnemy(actor, includeDaemon)
    --if not InFightMap then
    --    return false;
    -- end;
    if not actor then
        return false;
    end;

    if not includeDaemon and actor:IsDaemonMode() then
        return false;
    end;

    if actor:CheckIsCollectNpc() or self:CheckIsCollectNpc() then
        return false;
    end;

    if InSingleMap then

        --单人地图
        if actor:GetFuncType() == NpcFuncType_FreeFight then
            return true; --管子怪也能打掉
        end;

        if actor:GetTypeConfig().functype == NpcFuncType_Obstacle then
            return false;
        end

        if self:GetTypeConfig().functype == NpcFuncType_Obstacle then
            return false;
        end;

        if self == LOCAL_CHAR or self:GetType() == ActorType_Partner then
            local actorFuncType = actor:GetFuncType();
            if actorFuncType  == NpcFuncType_Fight or actorFuncType == NpcFuncType_FreeFight then
                return true;
            end;
        else
            local selfFuncType = self:GetFuncType();
            if actor == LOCAL_CHAR or actor:GetType() == ActorType_Partner then
                if selfFuncType  == NpcFuncType_Fight or selfFuncType == NpcFuncType_FreeFight then
                    return true;
                end;
            end;
        end;


        return false;
    end;
    --多人地图的就要根据服务器下发的阵营来做了



    if self ==LOCAL_CHAR then

        return actor._isLocalEnemy;

    elseif actor ==LOCAL_CHAR then
        return self._isLocalEnemy;
    end;

    return false;
end

--获取血条模式，如果bit到16，则标识同帮派的蓝血条
function Actor:GetHPMode(actor, includeDaemon)
    if actor == LOCAL_CHAR then return 0 end
    local isEnemy = LOCAL_CHAR:IsEnemy(actor)
    local titleBitNum = MapManager.GetCommonConfig().showIDTitle or 15
    if bit.band(titleBitNum, 16) >= 16 and actor._type == ActorType_Player then
        local targetRelationID      = actor:GetRelationID(QY_ROLE_RELATION_ID_TYPE.RELATION_ID_FOR_FAMILY)
        local selfID                = LOCAL_CHAR:GetRelationID(QY_ROLE_RELATION_ID_TYPE.RELATION_ID_FOR_FAMILY)
        if targetRelationID ~= nil and selfID ~= nil and targetRelationID > 0 and selfID > 0 and targetRelationID == selfID then
            return 1 --2 现在没有蓝色血条
        else
            return (isEnemy and 1 or 0)
        end
        -- return 1
    else
        return (isEnemy and 1 or 0)
    end
end

function Actor:ShiftMove(startPos, endPos, startTime, endTime)
    if not startPos then
        startPos = self:GetPos();
    end;
    if self._nav then
        self._nav.enabled = false;
    end;

    self._shiftMove = CreateShiftMove(self, startPos, endPos, startTime, endTime);

    if self == LOCAL_CHAR then
        MainCameraManager.SetSpeed(9989);
    end;
end;

function Actor:OnShiftMove(x, y, z)
    self._transform.position = Vector3.New(x, y, z);
end;

function Actor:OnShiftMoveEnd(x, y, z)
    --	--error(" Actor:OnShiftMoveEnd(x, y, z)");
    if self._nav and self._ifOnTargetMap then
        self._transform.position = Vector3.New(x, y, z);
        self._nav.enabled = true;
        self._shiftMove = nil;
    end;

    if self == LOCAL_CHAR then
        MainCameraManager.ResetCameraSpeed();
    end;
end

-- table
function Actor:SetFightAttrs(fightAttrs)
    self._roleFightAttr = fightAttrs;
end;

function Actor:SetFightAttrsWithoutBuff(attrs)
    self._roleFightAttrWithoutBuff = attrs;
end

function Actor:GetFightAttrsWithoutBuff()
    return self._roleFightAttrWithoutBuff;
end

--获取人物基础属性
function Actor:GetFightAttr(attrEnum)

    if not self._roleFightAttr then
        return 0;
    end;

    local fightattrs = self._changeBodyFightAttr or self._roleFightAttr;


    if attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_16INT_NUM then

        return fightattrs.value_16_[attrEnum + 1] or 0;
    elseif attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_32INT_NUM then

        return fightattrs.value_32_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_16INT_NUM +1] or 0;
    elseif attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_64INT_NUM then
        if fightattrs.value_64_ then
            return fightattrs.value_64_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_32INT_NUM +1] or 0;
        else
            return 0;
        end;
    end;

    return 0;
end;

function Actor:GetFightAttrWithoutBuffByEnum(attrEnum)

    if not self._roleFightAttrWithoutBuff then
        return 0;
    end;

    if attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_16INT_NUM then

        return self._roleFightAttrWithoutBuff.value_16_[attrEnum + 1] or 0;
    elseif attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_32INT_NUM then

        return self._roleFightAttrWithoutBuff.value_32_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_16INT_NUM +1] or 0;
    elseif attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_64INT_NUM then
        if self._roleFightAttrWithoutBuff.value_64_ then
            return self._roleFightAttrWithoutBuff.value_64_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_32INT_NUM +1] or 0;
        else
            return 0;
        end;
    end;

    return 0;
end;

--获取人物当前属性 就是基础属性+buff属性
function Actor:GetFightAttrWithBuff(attrEnum)
    --做buff的时候再加咯
    local buffChange = 0;
    if self._buffAttrChange then
        buffChange = self._buffAttrChange[attrEnum] or 0;
    end;
    return self:GetFightAttr(attrEnum) + buffChange;
end;

function Actor:SetFightAttr(attrEnum, value)
    if not self._roleFightAttr then
        return;
    end;

    local fightattrs = self._changeBodyFightAttr or self._roleFightAttr;

    if attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_16INT_NUM then
        local oldValue = fightattrs.value_16_[attrEnum + 1] or 0;
        fightattrs.value_16_[attrEnum + 1] = value;
        self:OnFightAttrChange(attrEnum, oldValue, value);
    elseif attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_32INT_NUM then
        local oldValue = fightattrs.value_32_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_16INT_NUM + 1] or 0;
        fightattrs.value_32_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_16INT_NUM + 1] = value;
        self:OnFightAttrChange(attrEnum, oldValue, value);
    elseif attrEnum < ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_64INT_NUM then
        if not fightattrs.value_64_ then fightattrs.value_64_ = {} end;

        local oldValue = fightattrs.value_64_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_32INT_NUM + 1] or 0;
        fightattrs.value_64_[attrEnum - ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_32INT_NUM + 1] = value;
        self:OnFightAttrChange(attrEnum, oldValue, value);
    end;
end;

function Actor:OnFightAttrChange(attr, oldValue, newValue)
    if attr == ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_CUR or attr == ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_MAX then
        --error("oldValue = "..oldValue..", newValue = "..newValue);
        if oldValue ~= newValue then

            self:OnHpChange();
        end;
    elseif attr == ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_RUN_SPEED then


        self:SetNavSpeed(newValue);
    elseif attr == ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_ROLE_CUR_STATE then

        if oldValue ~= newValue then
            self:OnStateChange(oldValue, newValue);
        end;
    end;

    if self == LOCAL_CHAR and (attr == ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_CUR or attr == ENUM_ROLE_FIGHT_ATTR_ENUM.ATTR_HP_MAX) then
        UISyncManager.OnAttrChange(attr, oldValue, newValue)
    end

    -- ai相关
    if self._ai and self._ai:IsActive() then
        self._ai:OnFightAttrChanged(attr, oldValue, newValue);
    end;
end;

function Actor:OnBaseAttrChange(attr, oldValue, newValue)
    -- 通用部分
    if self ~= LOCAL_CHAR then return end
    -- 只针对主角部分
    -- 通知UI同步系统
    UISyncManager.OnAttrChange(attr, oldValue, newValue)
    -- 通知装备扩展信息刷新
    EquipExtraInfoManager.OnRoleAttrChanged(attr)
    -- 通知角色特权系统，玩家储备经验更新
    if attr == ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_SLAVE_EXP then
        PrivilegeManager.SetDoubleExpValue(newValue)
    end
    if attr == ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_JINGJIE then
        if self._hud then
            self._hud:SetRealm(self:GetRealm());
        end;
    end

    -- 特殊处理，用于处理Hud
    if oldValue ~= nil and newValue > oldValue then
        if attr == ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_EXP then
            -- 06/05/2017 经验冒泡又改为一段
            PromptPanel.ShowCoinChange(attr, oldValue, newValue, CoinChange_SpecialType.Exp)
        elseif attr == ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_XIUWEI then
            PromptPanel.ShowCoinChange(attr, oldValue, newValue, CoinChange_SpecialType.Exp)
        elseif attr == ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_STUDY
        or attr == ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_JUNGONG
        or attr == ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_WEIWANG then
            PromptPanel.ShowCoinChange(attr, oldValue, newValue, CoinChange_SpecialType.StoneMoney)

            UISyncManager.OnAttrChange(UISYNC_CLIENT_TYPE.STONE_COIN_UPDATE)

        elseif attr >= ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ATTR_DAOZANG_PAGE_1
        and attr <= ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ATTR_DAOZANG_PAGE_6 then
            PromptPanel.ShowCoinChange(attr, oldValue, newValue, CoinChange_SpecialType.DaoZangMoney)
        else
            PromptPanel.ShowCoinChange(attr, oldValue, newValue, CoinChange_SpecialType.Money)
        end
    end

    -- ai相关
    if self._ai and self._ai:IsActive() then
        self._ai:OnBaseAttrChanged(attr)
    end;
end;

--写死一些状态
local stateLimitMove =  --这几个状态就不让移动了
ROLE_STATE.ROLE_CUR_STATE_STILL +
ROLE_STATE.ROLE_CUR_STATE_SLEEP;


local stateLimitAttack = --这几个状态不让普通攻击
ROLE_STATE.ROLE_CUR_STATE_SHEEP +
ROLE_STATE.ROLE_CUR_STATE_SLEEP;

local stateLimitCastSkill = --这几个状态不让放技能
ROLE_STATE.ROLE_CUR_STATE_SHEEP +
ROLE_STATE.ROLE_CUR_STATE_SLEEP +
ROLE_STATE.ROLE_CUR_STATE_SILENCE;

function Actor:OnStateChange(oldState, newState)
    if bit.band(oldState, ROLE_STATE.ROLE_CUR_STATE_DEAD) > 0 and bit.band(newState, ROLE_STATE.ROLE_CUR_STATE_DEAD) == 0 then
        --由死亡复活
        self:SetDead(false);
        if self == LOCAL_CHAR then
            DeadPanel.HideDeadPanel();

        end;
    elseif bit.band(oldState, ROLE_STATE.ROLE_CUR_STATE_DEAD) == 0 and bit.band(newState, ROLE_STATE.ROLE_CUR_STATE_DEAD) > 0 then
        --切换到死亡状态
        warn(self:GetName().."死了")
        self:SetDead(true);
        TenBossFightPanel.ShowDeadPanel(self);
    end;

    if self ~= LOCAL_CHAR and self:GetType() == ActorType_Player then
        --其他玩家
        if bit.band(newState, ROLE_STATE.ROLE_CUR_STATE_RIDE_FLY ) > 0 then
            self:SetRideFly(true)
        else
            self:SetRideFly(false)
        end;
    end;

    if bit.band(stateLimitMove, newState) > 0.1 then --不可行走了
        if self == LOCAL_CHAR then
            --        --error("set move false");
        end;
        self._stateCanMove = false;
        if self._isMoving then
            self:StopNav();
        end;
    else
        if self == LOCAL_CHAR then
            --        --error("set move tre");
        end;
        self._stateCanMove = true;
    end;

    if bit.band(stateLimitAttack, newState) > 0.1 then --不可普通攻击
        self._stateCanAttack = false;

    else
        self._stateCanAttack = true;
    end;




    if bit.band(stateLimitCastSkill, newState) > 0.1 then --不可放节能
        self._stateCanCastSkill = false;
    else
        self._stateCanCastSkill = true;
    end;
    if self == LOCAL_CHAR then
        SkillButtonPanel.LockSkill(not self._stateCanCastSkill)
    end;

    if bit.band(ROLE_STATE.ROLE_CUR_STATE_INVINCIBLE, newState) > 0.1 then --无敌
        --  --error("無敵")
        self._stateCanBeAttack = false;

    else
        --   --error("解除無敵")
        self._stateCanBeAttack = true;
    end;
    if bit.band(ROLE_STATE.ROLE_CUR_STATE_FIGHT, newState) > 0.1 then

        self:SetFighting(true);
    else
        self:SetFighting(false);
    end;

    if bit.band(ROLE_STATE.ROLE_CUR_STATE_RIDE, newState) > 0.1 then

        -- self:SetFighting(true);
    else
        --self:SetFighting(false);
        --if self ==LOCAL_CHAR then error("my ride unset") end;
        -- error("unride in state change")
        self:UnRide();
    end;


    if bit.band(ROLE_STATE.ROLE_CUR_STATE_RIDE_FLY, newState) > 0.1 then
        self:SetRideFly(true)
    else
        self:SetRideFly(false)
        if self == LOCAL_CHAR then
            LOCAL_CHAR:EnableNav();
        end;
    end;

end

function Actor:SetFixedShow(bFixedShow)
    self._fixedShowIgnoreNumber = bFixedShow;
end

function Actor:GetFixedShow()
    return self._fixedShowIgnoreNumber;
end

function Actor:SetHide(hide)
    --  --error(" Actor:SetHide(hide):name = "..self:GetName().."; id = "..self:GetUid()..(hide and "hide" or "visible"));
    if hide then
        self._hideRef = self._hideRef + 1;
    else
        self._hideRef = self._hideRef - 1;
    end;

    self:DoHide(self._hideRef);

end;

function Actor:ForceResetHide()
    self._hideRef = 0;
    self:DoHide(self._hideRef);
end;

function Actor:ForceHide(bHide)
    self._hideRef = bHide and 1 or 0;
    self:DoHide(self._hideRef);
end;

function Actor:IsHide()
    return self._hideRef > 0;
end;

function Actor:DoHide(hideRef)
    --	error("Actor:DoHide(hideRef)");
    local hide = false;
    self._hideRef = hideRef;

    if hideRef > 0 then
        hide = true;
    end;

    if not IsNil(self._collider) then
        self._collider.enabled = not hide;
    end;

    if not IsNil(self._actorRoot) then
        if hide then
            if not IsNil(self._animator) then
                self._animator.enabled = false;
            end
            self._actorRoot.localPosition = Vector3.New(0, 9999, 0);
        else
            self._actorRoot.localPosition = Vector3.New(0, 0, 0);
            if not IsNil(self._animator) then
                self._animator.enabled = true;
            end;
            if not IsNil(self._hud) then
                self._hud:SetActive(true)
            end
        end;
    end;
end;

function Actor:IsDaemonMode()
    return self._isDaemonMode;
end;

function Actor:SetDaemonMode(isDeamonMode)
    if self._isDaemonMode ~= isDeamonMode then
        self._isDaemonMode = isDeamonMode;

        if self._isDaemonMode then
            self:OnEnterDaemonMode();
        else
            self:OnLeaverDaemonMode();
        end;
    end;
end;

function Actor:OnEnterDaemonMode()
    self:StopAi();
    self:StopNav();
    self:DisableNav();
    self:DestroyHud();
    self:ClearAllModel();
    self._shiftMove = nil;

    if self._transform then
        self._transform.gameObject:SetActive(false);
    end;
end;

function Actor:OnLeaverDaemonMode()
    if self._transform then
        self._transform.gameObject:SetActive(true);
    end;

    if self._ifOnTargetMap then
        self:OnGotoTargetMap();
    end;
end;

function Actor:SetPro(pro)
    self._pro = pro;
    KingOfFighters.SetPro(pro);

    if self._showData then
        self:SetRoleShowData(self._showData);
    end;
end;

function Actor:GetPro()
    return self._pro;
end;

function Actor:SetSex(sex)
    self._sex = sex;

    if self._showData then
        self:SetRoleShowData(self._showData);
    end;
end;

function Actor:GetSex()
    return self._sex;
end;

function Actor:ShowDir(target)
    if self._model_dir and self._model_dir_controller then
        self._model_dir:SetActive(true);
        self._model_dir_controller.target = target;
    end;
end;

function Actor:HideDir()
    if self._model_dir and self._model_dir_controller then
        self._model_dir:SetActive(false);
    end;
end;

function Actor:Bubble(bubbleType, msg, sourceType)
    if self._hud then
        self._hud:PlayBubble(bubbleType, msg, sourceType);
    end;
end;
local tmpPos = Vector3.New(0,0,0);
function Actor:PerformDeadFly(src)

    if self == src then
        return ;
    end;

    if self._template.performanceHard > 0.1 then
        return ;
    end;

    local speed = 5.5;
    local distance = 6+ math.random()*3;


    local out = false;
    local dir = self:GetPos() - src:GetPos();
    dir:SetNormalize();
    local pos = self:GetPos() + dir * distance;
    local ret, hit = NavMesh.Raycast(self._transform.position, pos, nil, 1);
    if ret == true then
        --不在路面上 那就 看是不是悬崖了
        tmpPos:Set(pos.x, pos.y+10, pos.z);
        local retCliff, hitCliff = Physics.Raycast(tmpPos, -Vector3.up, nil, 100,  LayerMask.MultiLayer("Cliff"));

        if retCliff and false then
            out = true;
        else
            pos = hit.position;
            distance = Vector3.Distance(pos, self:GetPos());
        end;


    end;
    if distance > 1 then

        local time = distance / speed;
        if self._shadow then
            self._shadow.gameObject:SetActive(false);
            if self._animator then
                self._animator.enabled = true;
            end;
        end;

        if self._model then
            if out then
                pos = self:GetPos() + dir * 20;
                time = 20 / 3;
                DG.Tweening.ShortcutExtensions.DOMove(self:GetTransform(), pos, time, false);
                Util.SimulateGravity(self._model.gameObject, 20,-10.8,10.8,0)
            else
                local tween = DG.Tweening.ShortcutExtensions.DOMove(self:GetTransform(), pos, time, false);
                DoTweenHelper.SetEase(tween,DG.Tweening.Ease.OutQuad);

                DoTweenHelper.DoPunchUp(self._model, 1.4,time)


                local params = {type = FcAction_ActorEffect; id=1000018;self:GetActorKey(); attachname = "actorroot"; leaveMap=false; offsettime = time + (self._template.deaddustoffset or 0); lifetime=1;deadLeave= true }
                FcActionFactory.CreateAction(params, self);


            end;
        end;
    end;
    --[[
        if self == src then
            return ;
        end;

        local speed = 6;
        local distance = 2+ math.random(3);



        local dir = self:GetPos() - src:GetPos();
        dir:SetNormalize();
        local pos = self:GetPos() + dir * distance;
        local ret, hit = NavMesh.Raycast(self._transform.position, pos, nil, 1);
        local out = false;
        if ret == true then
           -- pos = hit.position;
           -- distance = Vector3.Distance(pos, self:GetPos());
           out = true;
        end;
        if distance > 1 then

            local time = distance / speed;

            DG.Tweening.ShortcutExtensions.DOMove(self:GetTransform(), pos, time, false);

            if self._model then
                if out then
                    Util.SimulateGravity(self._model, 5,-6,-0.6 * time,0)
                else
                    DG.Tweening.ShortcutExtensions.DOPunchPosition(self._model.transform, Vector3.New(0, 1.5, 0), time*1.1, 8, 0.1, false);
                end;
            end;
        end;]]

end;

function Actor:SetPath(currPos, nextPos, nextNextPos, areaMask)
    areaMask = areaMask or NavMeshLayerMask.Walkable;
    if not self._ifOnTargetMap then
        self._routeToWalk = {currPos, nextPos, nextNextPos};
        return ;
    end;

    if not self._nav then
        return;
    end;
    if not currPos then
        return;
    end;
    local localPos = self:GetPos();
    currPos.y = localPos.y;

    --如果位置不同步了（比如说 误差大于2） 做一点迷惑性的东西~
    local dis = Vector3.Distance(localPos, currPos);

    if nextPos.x <0.1 then
        --这里表示收到停止包
        if dis < 0.5 then

            self:StopNav(false);
        else
            self:StartNav(currPos, 0.1, 2, areaMask);
        end;

        return ;
    end;
    if dis >= 2 then

        --看下这条路径最终走到哪里
        local dstPos = currPos;

        if nextNextPos and nextNextPos.x > 0.1 then
            dstPos = nextNextPos;
        elseif nextPos and nextPos.x > 0.1 then
            dstPos = nextPos;
        end;

        --我离最终路径多远
        local myDistance = Vector3.Distance(localPos, dstPos);

        if myDistance < 0.1 then
            self:StopNav(false);
            return ;
        end

        --路径本身有多长
        local pathDistance = 0;

        if nextPos and nextPos.x > 0.1 then
            pathDistance = pathDistance + Vector3.Distance(currPos, nextPos);
        end;

        if nextNextPos and nextNextPos.x >0.1 then
            pathDistance = pathDistance + Vector3.Distance(nextPos, nextNextPos);
        end

        --计算应该加速减速多少
        local speedScale = 1;
        if self ~= LOCAL_CHAR then
            if pathDistance > 0 then
                speedScale = myDistance / pathDistance;
            end;
        end;

        self:StartNav(dstPos, 0.1, speedScale, areaMask, false);
        return ;
    end

    if nextPos.x < 0 then
        self:StopNav();
    end;


    if nextPos.x <0.1 or currPos.x < 0.1 then

        return ;
    end;

    if self._routeDraw then
        self._routeDraw.Timer:Stop();
        GameObject.Destroy(self._routeDraw.Object);

        --  self._routeDraw.Object
    end;

    --一段路径 就让他走过去
    if nextNextPos.x <= 0.01 then
        self._routeInfo = nil;
        nextPos = self:StartNav(nextPos, nil, nil, areaMask, false);

        if self:GetTypeConfig().id == 1001 then
            --   --error("start move to nextPos")
            self._routeDraw = FightDebug.DrawLines(
            {
                currPos + Vector3.New(0,1,0), nextPos+ Vector3.New(0,1,0);
            },
            999
            );end;
    else
        --两段路径 走到第一个点 存下第二个点

        local ret = self:StartNav(nextPos, nil, nil, areaMask);

        self._routeInfo = {
            point1 = ret or nextPos;
            point2 = nextNextPos;
        }

    end;
end;

function Actor:UpdatePath()

    if not self._nav then
        return;
    end;

    if  Vector3.Distance(self:GetPos(), self._routeInfo.point1) < 0.2 then
        self:StartNav(self._routeInfo.point2, nil, nil, NavMeshLayerMask.Fly + NavMeshLayerMask.Walkable);
        self._routeInfo = nil;
    end;


end;

function Actor:GetBuffDatas()
    return self.buffDatas or {}
end

--外部接口  添加buff
function Actor:AddBuff(id)
    if self._ifOnTargetMap and self._ifModelLoaded then

        --模型已经有了  直接操作起来
        self:DoAddBuff(id)
    else
        --添加到一个列表
        if self._buffToAdd == nil then
            self._buffToAdd = {}
        end
        self._buffToAdd[id] = true;
    end
end;
--外部接口 移除buff
function Actor:RemoveBuff(id)
    if self._ifOnTargetMap and self._ifModelLoaded then
        --模型已经有了  直接操作起来
        self:DoRemoveBuff(id)
    else
        --添加到一个列表
        if self._buffToAdd  then
            self._buffToAdd[id] = nil;
        end

    end
end

--内部实现逻辑
function Actor:DoAddBuff(id)
    CharBuffData.ReplaceBuff(self, id);
end;
function Actor:DoRemoveBuff(id)
    CharBuffData.RemoveBuff(self, id);
end;

function Actor:GetBuffList()
    return CharBuffData.GetBuffList(self)
end;

function Actor:AddAllBuffAfterLoaded()
    if self._buffToAdd then


        for i,v in pairs(self._buffToAdd) do
            if v then
                self:DoAddBuff(i);
            end
        end
        self._buffToAdd = nil;
    end
end




--定格动作
function Actor:SetAnimationPause(pause)
    -- if self._changeBodyAnimator then
    -- if pause then

    -- self._changeBodyAnimator:StartPlayback();
    -- else
    -- self._changeBodyAnimator:StopPlayback();
    -- end;
    -- else
    if self._animator then
        if pause then

            self._animator:StartPlayback();
        else
            self._animator:StopPlayback();
        end;
    end;
end;

--相关ID
function Actor:SetRelationID(idList)
    self._relation_id = idList;
end

function Actor:GetRelationID(relation)
    -- printTable(self._relation_id, "relation");
    if self._relation_id == nil then
        return nil;
    end
    if relation == nil then
        return self._relation_id;
    else
        return self._relation_id[relation+1];
    end
end;

--获取目标与我方向的角度  正前方为0
function Actor:GetTargetAngle(target)
    if target == self then return 0 end;

    local t = target:GetPos() - self:GetPos();

    t . y = 0;

    return Vector3.Angle(t, self:GetTransform().forward);
end;

function Actor:SetLevel(level)
    self:SetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_LVL, level);
end

function Actor:GetLevel()
    if not InSingleMap then
        return self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_LVL);
    end;
    if self._type == ActorType_Npc then

        if self._unitConfig and self._unitConfig.level and self._unitConfig.level > 0 then
            return self._unitConfig.level;
        end;

        if self._template.level == 666 then
            return LOCAL_CHAR:GetLevel();
        end;
        return self._template.level;
    end;
    return self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_LVL);
end;

function Actor:IsGM()
    local isGM = self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_NTF_GM_STATE);
    return isGM == 1
end

function Actor:GetGMState()
    local GMState = self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_NTF_GM_STATE);
    return GMState
end

function Actor:SetRealm(realm)
    self:SetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_JINGJIE, realm);
    --  self:SetHudDirty();
end

function Actor:GetRealm()
    return self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_JINGJIE);
end;

function Actor:GetRein()
    return math.floor(self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_LVL) / 1000);
end

function Actor:GetFighting()
    return self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_FIGHT_CAPACITY);
end;

function Actor:GetAcmPoint()
    return self:GetBaseAttr(ENUM_ROLE_BASE_ATTR_ENUM.CHAR_ROLE_ACM_POINT);
end
------------------------------------------------------------------------
-- ai相关
function Actor:SetAi(ai, bStart)
    self._ai = ai;
    if ai then
        ai:SetActor(self);
        if bStart then
            ai:Start();
        end;
    end;
    return self._ai;
end;

function Actor:GetOrAddCanYingCom()
    if self._canYing == nil then
        self._canYing = self._transform.gameObject:AddComponent(CanYing.GetClassType());
    end
    return self._canYing;
end

function Actor:GetAi()
    return self._ai;
end;

function Actor:StartAi()
    if self._ai then
        self._ai:Start();
    end;
end;

function Actor:StopAi()
    if self._ai then
        self._ai:Stop();
    end;
end;

function Actor:UpdateAi(deltaTime)

    if self._ai and self._ai:IsActive() then
        if LoginManager.IsReconnecting() then
            return ;
        end;
        self._ai:Update(deltaTime);
    end;
end;

function Actor:RefreshPlaneShadowState()
    --error("refresh shadow state")
    if self:IsDestroyed() then return end;

    if self:IsRideFlying() then
        self:DisablePlaneDynamicShadow(true)
        return;
    end;

    if self == LOCAL_CHAR then
        if ShadowManager.IsOpenLOCAL_CHARShadow() then
            self:EnablePlaneDynamicShadow()
        else
            self:DisablePlaneDynamicShadow()
        end;
    else
        if false and ShadowManager.IsOpenOtherShadow() then
            self:EnablePlaneDynamicShadow()
        else
            self:DisablePlaneDynamicShadow()
        end;
    end;
end;

function Actor:EnableRideShadow()

end

function Actor:DisabledRideShadow()

end

function Actor:EnableShadowByTrans(trans)

end

function Actor:DisableShadowByTrans(trans)

end

function Actor:EnablePlaneDynamicShadow()
    --	do return end;

    if self:GetType() == ActorType_UIModel then
        self:DisablePlaneDynamicShadow();
        return;
    end;

    if self._updateShadowCom == nil then
        self._updateShadowCom = self._transform:GetComponent(UpdatePlaneShadowPosY.GetClassType());
        if not self._updateShadowCom then
            self._updateShadowCom = self._transform.gameObject:AddComponent(UpdatePlaneShadowPosY.GetClassType());
        end;

        self._updateShadowCom._rootTrans = self._transform;
    end;

    self._updateShadowCom.enabled = true;
    local matList = {};

    --	error("EnablePlaneDynamicShadow"..self._transform.name)
    if self._model == nil then
        --        error("找不到_model"..self._transform.name)
        self._updateShadowCom.enabled = false;
        return;
    end;


    local ifHasShadow = false;
    local toFindGo = self._rideRoot.gameObject;

    local skinedMeshrenderArr = toFindGo:GetComponentsInChildren(Renderer.GetClassType());
    --PromptPanel.ShowDebugMessage("skinedMeshrenderArr.Length = "..skinedMeshrenderArr.Length);
    for i = 0, skinedMeshrenderArr.Length-1 do
        if skinedMeshrenderArr[i].name ~= "Plane01" and skinedMeshrenderArr[i].gameObject.layer ~= HUD_LAYER  then
            local name = skinedMeshrenderArr[i].material.shader.name;
            table.insert(matList, skinedMeshrenderArr[i].material);
            if not string.find(name, "_Shadow") then
                if self == LOCAL_CHAR then
                    if not string.find(name, "_LOCAL") then
                        name = name.."_LOCAL";
                        --PromptPanel.ShowDebugMessage(string.format("skinedMeshrenderArr[i].name = %s", skinedMeshrenderArr[i].name));
                    end
                end;
                local shadowShader = Shader.Find(name.."_Shadow");
                if shadowShader ~= nil then
                    ifHasShadow = true;
                    skinedMeshrenderArr[i].material.shader = shadowShader;
                else
                    --                error(self._model.gameObject.name.."  找不到shadow shader: "..name.."_Shadow");
                end;
            else
                --有shadow, 但LOCAL_CHAR没有使用_LOCAL的shader
                if self == LOCAL_CHAR then
                    local curShaderName = skinedMeshrenderArr[i].sharedMaterial.shader.name;
                    if string.find(curShaderName, "CubeMap_Actor") then
                        local shadowShader = Shader.Find("ZTJ_Shaders/EnvCubeMap/CubeMap_Actor_LOCAL_Shadow");
                        if shadowShader ~= nil then
                            ifHasShadow = true;
                            skinedMeshrenderArr[i].material.shader = shadowShader;
                        end
                    end
                end
            end;
        end;
    end

    if ifHasShadow then
        self._isUseDynamic = true;
        if self._shadow ~= nil then
            self._shadow.localScale = Vector3.New(0.01, 0.01, 0.01);
        end;
    else
        if self._shadow ~= nil then
            self._shadow.localScale = Vector3.New(1, 1, 1);
        end
        self._isUseDynamic = false;
    end

    --	error("EnablePlaneDynamicShadow 2222222"..self._transform.name)
    self._updateShadowCom._matList = matList;
    matList = nil;
    ShadowManager.SyncShadowInfo(self._updateShadowCom);
end

function Actor:DisablePlaneDynamicShadow(noNormalShadow)
    if self._updateShadowCom ~= nil then
        self._updateShadowCom.enabled = false;
    end

    if self._model == nil then
        --   error(string.format("Actor:DisablePlaneDynamicShadow() %s 找不到model", self._name));
        return
    end;

    local skinedMeshrenderArr = self._rideRoot.gameObject:GetComponentsInChildren(Renderer.GetClassType());
    for i = 0, skinedMeshrenderArr.Length-1 do

        if skinedMeshrenderArr[i].name ~= "Plane01" and skinedMeshrenderArr[i].gameObject.layer ~= HUD_LAYER  then
            local name = skinedMeshrenderArr[i].material.shader.name;
            local pos = string.find(name, "_Shadow")

            if pos ~= nil then
                local originalName = string.sub(name, 0, pos - 1);
                --error("originalShader = "..originalName);
                local originalShader = Shader.Find(originalName);
                if originalShader ~= nil then
                    skinedMeshrenderArr[i].material.shader = originalShader;
                end;

            end;
        end;
    end

    if self._shadow ~= nil then
        if noNormalShadow then
            self._shadow.localScale = Vector3.New(0.01, 0.01, 0.01);
        else
            self._shadow.localScale = Vector3.New(1, 1, 1);
        end;

    end;
    self._isUseDynamic = false;
end



--强制打开Animator
function Actor:SetHideUnuseComData(isForceUpdate)
    if IsNil(self._hideCom) then return end;
    self._hideCom._isForceUpdate = isForceUpdate;
end

-------------------------------------------------------------------------
function Actor:ShowDialog(string, time)
    --    error("fuck adam")
    if self._hud then
        -- self._hud:ShowDialog(string, time);
    end;
end;

function Actor:SetOnWater(onWater)
    do return end;
    self._onTheWater = onWater;

    if self._footDownEventHandler then
        self._footDownEventHandler.inWater = onWater;
    end;
end;

function Actor:ChangeBody(typeid)
    if not self._needLoadModel then return end;

    self:ClearAllModel();

    local typeConfig = NpcTypeConfig.GetConfig(typeid);
    self._changeBodyTemplate = typeConfig;
    if not typeConfig then return end;

    self:SetLoadDirty();
end;

function Actor:RecoverChangeBody()
    self:ClearAllModel();
    self._changeBodyTemplate = nil;
    self:SetLoadDirty();
end;

function Actor:IsChangeBody()
    return self._changeBodyTemplate ~= nil;
end;
function Actor:SetIconImageCode(str)
    self.IconImageCode = str;
end
function Actor:GetIconImageCode()
    return self.IconImageCode or "";
end
function Actor.OnAnimatorEvent(actorKey, sValue)
    local actor = ActorManager.Find(actorKey);
    if actor then
        Event.Brocast(CLIENT_EVENT.ON_ANIMATOR_STRING_EVENT, actor, sValue);
    end;

end;

function Actor.OnAnimationSound(actorKey, soundID)
    local actor = ActorManager.Find(actorKey);
    if not actor then return end;

    -- local action = FcAction_Sound.New(soundID, actor:GetPos());
    SoundManager.PlaySound(soundID, actor:GetPos(), 6);
    --  action:SetLifeTime(3);
    --  FcActionManager.Add(action);
end;

function Actor.OnAnimationEffect(actorKey, effectID, attachName, lifeTime)
    local actor = ActorManager.Find(actorKey);
    if actor then
        FcAction_ActorEffect.ActorEffect(effectID, actorKey, "qinggong_fx", 2, 0)
    end
end


function Actor:Ride(assetBundle, assetName,config)

    --  error("ride" .. assetName)
    --self:UnRide();
    self._riding = true;
    self._ridingConfig = config;

    self._ridingAssetBundle = assetBundle;
    self._ridingAssetName = assetName;

    if self:IsModelLoaded() then
        self:DoRide(assetBundle, assetName,config);

        -- 有些效果骑乘时不显示，又没有简单的控制机制，
        -- 只能强行重置，这里超级蛋疼
        if self:GetType() == ActorType_Player then
            self:ClearEquipEffects(); -- 清空特效
            self:ProcessEquipEffects();
        end
    end;
    SkillButtonPanel.RefreshRideButtons()
end;

function Actor:UnRide()

    if not self._riding then return end;
    self._riding = false;
    self:DoUnBindRide();
    self._ridingassetBundle = "";
    self._ridingAssetName = "";
    self._ridingConfig = nil;
    SkillButtonPanel.RefreshRideButtons()

    if self:IsModelLoaded() then
        -- 有些效果骑乘时不显示，又没有简单的控制机制，
        -- 只能强行重置，这里超级蛋疼
        if self:GetType() == ActorType_Player then
            self:ClearEquipEffects(); -- 清空特效
            self:ProcessEquipEffects();
        end
    end
    --soldier_add 下坐骑后, 可以看得更近了
    --	MainCameraManager.SetMinDistance(0.1);
end
function Actor:GetRideConfig()
    return self._ridingConfig
end;
function Actor:DoRide(assetBundle, assetName,rideConfig)
    --	error("Actor:DoRide(assetBundle, assetName,rideConfig)");
    -- self._ridingConfig = rideConfig;

    -- self._ridingAssetBundle = assetBundle;
    -- self._ridingAssetName = assetName;

    -- if rideConfig == nil then

    -- end;

    -- if not self._model then
    -- return ;
    -- end;
    -- if self == LOCAL_CHAR then
    -- error("reqrideload!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    -- end;
    self._ridingLoadSerial = 0;
    self._ridingLoadSerial = AssetLoadManager.GetAssetFromCacheOrLoad(assetBundle, assetName,
    self.OnRideModelLoaded, self);

    --soldier_add 骑上坐骑需要重新设置一下摄像机的焦点
    --	MainCameraManager.SetMinDistance(0.35);
end;



function Actor:OnRideModelLoaded(effectTrans,  serial, assetBundle, assetName)
    --error("Actor:OnRideModelLoaded(effectTrans,  serial, assetBundle, assetName)1");
    if (effectTrans == nil) or (serial > 0 and serial ~= self._ridingLoadSerial) or self._riding == false or self:IsDestroyed() then
        AssetLoadManager.ReleaseAsset(assetBundle, assetName, effectTrans, true);
        if self._ridingTrans then
            --干掉之前 把model 挪到root下
            if IsNil(self._model) == false then
                self._model:SetParent(self._modelRoot);
            end;
            AssetLoadManager.ReleaseAsset(self._ridingTransAssetBundle, self._ridingTransAssetName, self._ridingTrans, true);
        end;
        return ;
    end;
    --error("Actor:OnRideModelLoaded(effectTrans,  serial, assetBundle, assetName)2");
    -- if self._ridingTransAssetBundle == assetBundle and self._ridingTransAssetName == assetName then
    -- AssetLoadManager.ReleaseAsset(assetBundle, assetName, effectTrans, true);
    -- return ;
    -- end;
    --error("Actor:OnRideModelLoaded(effectTrans,  serial, assetBundle, assetName)3");
    --如果已经有一个了 干掉
    if self._ridingTrans then
        --干掉之前 把model 挪到root下
        if self._model then
            self._model:SetParent(self._modelRoot);
        end;
        AssetLoadManager.ReleaseAsset(self._ridingTransAssetBundle, self._ridingTransAssetName, self._ridingTrans, true);
    end;
    --error("Actor:OnRideModelLoaded(effectTrans,  serial, assetBundle, assetName)4");
    FastSetActive(effectTrans.gameObject, true)
    self._ridingTrans = effectTrans;
    self._ridingTransAssetBundle = assetBundle;
    self._ridingTransAssetName = assetName;
    self._ridingAnimator = effectTrans.gameObject:GetComponentInChildren(Animator.GetClassType());
    --self._ridingAssetBundle = assetBundle;
    --self._ridingAssetName = assetName;
    Util.SetAllLayer(effectTrans.gameObject, self._modelRoot.gameObject.layer);
    --error("Actor:OnRideModelLoaded(effectTrans,  serial, assetBundle, assetName)5");
    self:DoBindRide();

    --error("Actor:OnRideModelLoaded(effectTrans,  serial, assetBundle, assetName)6");
end;

function Actor:DoBindRide()

    if (not self._model) or (not self._ridingTrans) then
        return ;
    end;

    self._ridingTrans:SetParent(self._rideRoot);

    if self._ridingConfig then
        local height = self._ridingConfig.bestheight or 0.8;
        if self:GetType() == ActorType_UIModel then
            height = 0;
        end;
        self._ridingTrans.localPosition = Vector3.New(0, height, 0);

    else
        self._ridingTrans.localPosition = Vector3.zero;
    end;

    self._ridingTrans.localScale = Vector3.one;
    self._ridingTrans.localRotation = Quaternion.identity;

    local ridePoint = findRecursive(self._ridingTrans, "rideroot");

    if ridePoint then
        self._modelRoot:SetParent(ridePoint);

        self._modelRoot.localPosition = Vector3.zero;
        self._modelRoot.localScale = Vector3.one;
        self._modelRoot.localRotation = Quaternion.identity;

        local height = self._ridingConfig.bestheight or 0.8;
        if self:GetType() == ActorType_UIModel then
            height = 0;
        end;

        self._midCamFocus.transform.localPosition = Vector3.New(0, height + 1.5, 0);
    else
        error("no rideroot");
        -- return ;
    end;

    self._ridingFlyAgent:SetRideRoot(self._ridingTrans)

    if self._animator and not AutoFlyManager.IsActorInFlying(self) then
        if self.lastRideAnimation then
            self:SetAnimatorBool(self.lastRideAnimation, false);
        end;
        self.lastRideAnimation = self._ridingConfig.rideAnimation;
        self:SetAnimatorBool(self.lastRideAnimation, true);
    end;

    self:RefreshPlaneShadowState();

    --self:CreateHud()
    --self:DestroyHud();
    -- self._needCreateHud = true;

    if self._ridingAnimator then
        self._ridingAnimator:SetBool(Actor.AnimatorStringHash("moving"), self._isMoving);
        self._ridingFlyAgent.rideAnimator = self._ridingAnimator;
    end;

    local params = {type = FcAction_ActorEffect; id=1000068;self:GetActorKey(); attachname = "actorroot"; leaveMap=false; offsettime = 0;lifetime=1 }
    FcActionFactory.CreateAction(params, self);

    if self._hud then
        self._hud:SetAttachNode(self:PrepareHudNode());
    end;
end;

function Actor:DestroyRideModel()

end;

function Actor:DoUnBindRide(noChangeHud)
    --	error("Actor:DoUnBindRide(noChangeHud)1");
    if IsNil(self._ridingFlyAgent) then
        return ;
    end;

    if self._ridingFlyAgent then
        self._ridingFlyAgent.rideAnimator = nil;
    end;

    --error("Actor:DoUnBindRide(noChangeHud)2");
    if not IsNil(self._modelRoot) then
        self._modelRoot:SetParent(self._rideRoot);
        self._modelRoot.localPosition = Vector3.zero;
        self._modelRoot.localScale = Vector3.one;
        self._modelRoot.localRotation = Quaternion.identity;
    end;
    --self:SetAnimatorBool("ride", true);

    if not IsNil(self._ridingTrans) then
        AssetLoadManager.ReleaseAsset(self._ridingTransAssetBundle, self._ridingTransAssetName, self._ridingTrans, true);

        --  error("saldkjfalksdjflkdsflkadslfkdsalkfjladksfjlkdasjfkladsjlkfadslkfjdsalkj")
        local params = {type = FcAction_ActorEffect; id=1000068;self:GetActorKey(); attachname = "actorroot"; leaveMap=false; offsettime = 0;lifetime=1 }
        FcActionFactory.CreateAction(params, self);

        if self._midCamFocus then
            self._midCamFocus.transform.localPosition = Vector3.New(0,1.5,0);
        end;
    end;

    -- error("Actor:DoUnBindRide(noChangeHud)3");
    self._ridingTrans = nil;
    self._ridingTransassetBundle = "";
    self._ridingTransAssetName = "";
    self._ridingAnimator = nil;

    if self._animator and self:GetType() == ActorType_Player and not AutoFlyManager.IsActorInFlying(self) then
        if self.lastRideAnimation then
            self:SetAnimatorBool(self.lastRideAnimation, false);
            self.lastRideAnimation = nil;
        end;
    end;

    self:SetMoving(self._isMoving)

    self._ridingFlyAgent:SetRideRoot(nil)

    self:RefreshPlaneShadowState();

    -- if not noChangeHud then
    --    self:CreateHud()
    -- self:DestroyHud();
    -- self._needCreateHud = true;
    -- end;

    if self.UnRideCastSkill then
        KingOfFighters.CastSkill(unpack(self.UnRideCastSkill))
        self.UnRideCastSkill = nil;
    end;

    if self._hud then
        self._hud:SetAttachNode(self:PrepareHudNode());
    end;
end;

function Actor:GetRideTrans()
    return self._ridingTrans
end;

function Actor:SetRideFly(flying)
    if self._ridingFlying == flying then return end;

    self._ridingFlying = flying;

    if not flying then
        self._ridingFlyAgent:Stop()
    end;

    local target = flying and 1 or 0
    if self._nav then
        self._nav.enabled = not flying;
        target = 0
    end
    -- self._animator:SetFloat(Actor.AnimatorStringHash("flying"), target);

    if not flying then
        self:DisableNav()
        self:EnableNav();

    end;

    if self == LOCAL_CHAR then
        self:RefreshPlaneShadowState();
    end;

end;

function Actor:IsRideFlying()
    return self._ridingFlying
end;

function Actor:IsNotRideFlying()
    -- error("检查是否notflying")
    return not self._ridingFlying;
end;

function Actor:RideFlyMoving()
    return self._ridingFlyAgent:IsMoving();
end;

function Actor:SetRideFlySpeed(speed )
    self._ridingFlyAgent.speed = speed;
end;

function Actor:GetRideFlyAgent()
    return self._ridingFlyAgent
end;

function Actor:RideFlyTo(pos)
    -- if self == LOCAL_CHAR then
    -- error("my ride fly to")
    -- end;
    if not self._ridingFlying then self:SetRideFly(true) end;
    self._ridingFlyAgent.destination = pos;

end;

function Actor:GetColorSuitMat()
    if self._model == nil then
        return
    end;


    --	if self._skinRenderArr == nil then
    self._skinRenderArr = nil;
    local skinedMeshrenderArr = self._model.gameObject:GetComponentsInChildren(SkinnedMeshRenderer.GetClassType());

    if skinedMeshrenderArr.Length > 0 then
        self._skinRenderArr = {};
    end;

    for i = 0, skinedMeshrenderArr.Length - 1 do
        self._skinRenderArr[i+1] = skinedMeshrenderArr[i];
    end
    --	end;

    if self._skinRenderArr == nil then
        if AppConst.DebugMode then
            PromptPanel.ShowNewMessage(string.format("装备换色: 找不到skinReder actorName = %s", self:GetName()));
        end;
        return;
    end;

    if self._skinRenderArr ~= nil then
        for k,v in pairs(self._skinRenderArr) do
            if not IsNil(v) and not IsNil(v.gameObject)  then
                if not string.find(v.gameObject.name, "wuqi") then
                    return v.material;
                end
            end;
        end
    end

end

function Actor:RideFlyStop()
    -- error("stop ride fly")
    self._ridingFlyAgent:Stop()

end;

function Actor:IsRiding()
    return self._riding;
end;

function Actor:SqrDistanceToLocalChar()
    return Vector3.SqrDistance(self:GetPos(), LOCAL_CHAR:GetPos());

end;

function Actor:DistanceToLocalChar()
    return Vector3.Distance(self:GetPos(), LOCAL_CHAR:GetPos())
end;

function Actor:SetUdpCmdLastSerial(dataKey, serial)
    if not self.udpCmdSerial then
        self.udpCmdSerial = {};
    end;

    self.udpCmdSerial[dataKey] = serial;
end;

function Actor:GetUdpCmdLastSerial(dataKey)
    if not self.udpCmdSerial then return 0 end;
    return  self.udpCmdSerial[cmd] or 0;
end;


function Actor:GetManualFlyController()
    if not self.manualFlyController then
        self.manualFlyController = ManualFlyController.New(self);
    end;
    return self.manualFlyController
end;

function Actor:IsAutoMoving()
    if AutoFlyManager.IsActorInFlying(self) then
        return true;
    elseif self == LOCAL_CHAR and TraficManager.IsInTrafic() then

        return true;
    end;
    return false;

end;

local animatorStringHash = {}
local platformChecked =false;
local isios =  false;
function Actor.AnimatorStringHash(str)
    if platformChecked == false then
        isios = AppConst.IsIOS or false;
        platformChecked = true;
    end

    if isios then return str end;


    local ret = animatorStringHash[str]
    if not  ret then
        local i = Animator.StringToHash(str);
        animatorStringHash[str] = i;
        return i;
    end

    return ret;
end

function Actor:SetHelpFight(value,notSend)
    self._helpFight = value;
    TeamMiniPanel.ChangedHelpFightBtn(value)
    if notSend then
        return;
    end
    UISyncManager.OnAttrChange(UISYNC_CLIENT_TYPE.HELPFIGHT_CHANGE)

end

function Actor:GetHelpFight()
    return self._helpFight;
end

function Actor:SetInteraction(state)
    self._isInteraction = state;
end

function Actor.GetInteraction()
    return self._isInteraction
end