--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

--这个文件名是不是很吊

--这里处理技能释放的操作
--还有cd啊 什么

--endregion
require("logic/EnemySelUtil")
KingOfFighters = {
    firstChooseTargetType = -1;
};
local this = KingOfFighters;
local inputBuffer = {
    inputTime = 0;
    skillID = 0;
}

local lastCastSkill = 0;
local lastCastTime = 0;

local lastCanAttackTime = 0; --上次转换到可攻击状态的时间

local normalAttackList = {}; --当前角色的普通攻击id数组
local skillList = {}; --当前角色的技能列表 skillconfig 的数组

local idToIndex = {};
local idToLevel = {};

local CDList = {};

local tmpSkillInfo = nil; --这里存一些临时技能列表  暂时给变身用  有这个值就用这个  没有就用自己的技能


local isSingleFightMap = false; --当前是否在单机战斗副本


local autoChooseTargetKey = ""; --记录一个最后选中的人的key

local lastUserOperTime = 0;

local nextSkillDatas = {}; --连招的信息记录
--[[
    节本结构为
    nextSkillDatas[masterskillid] = {
        skillid = xx;
        timer = 定时器 用来移除这个结构 并且主技能进入cd
    }

]]

local lockTargetV2 = nil;


local waitingRsp = false; --正在等技能回包  回来之前所有逻辑不让按
local startWaitingTime = 0;

function KingOfFighters.Init()
    UpdateBeat:Add(this.Update, nil, "KingOfFighters.Update");
    Event.AddListener(CLIENT_EVENT.ON_GOTO_TARGET_MAP, KingOfFighters.OnMapChange);
    Event.AddListener(CLIENT_EVENT.ON_ACTOR_DEL, KingOfFighters.OnActorDel);
    Event.AddListener(CLIENT_EVENT.ON_CLIENTLOGIC_ACTOR_DEAD, KingOfFighters.OnActorDead);
    
end;
function KingOfFighters.SetFirstChooseType(type)
    KingOfFighters.firstChooseTargetType = type;
    KingOfFighters.ResetTargetV2();
end
function KingOfFighters.PushInputBuffer(skillID)
    inputBuffer.skillID = skillID;
    inputBuffer.inputTime = Time.timeSinceLevelLoad;
end;

function KingOfFighters.PopInputBuffer()
    local skillID = inputBuffer.skillID;
    local inputTime = inputBuffer.inputTime;
    inputBuffer.skillID = 0;
    return skillID,inputTime;
end;

local lastNormalAttackInfo =
{
    index = 0;
    time = 0;
}
function KingOfFighters.GetSkillList()
    return skillList;
end;

function KingOfFighters.GetNormalAttackSkillID()
    local num = #normalAttackList;
    if lastNormalAttackInfo.index >= num then
        return normalAttackList[1];
    end
    return normalAttackList[lastNormalAttackInfo.index + 1];
end

function KingOfFighters.GetSkillID(buttonIdx)
    if buttonIdx < 0 then return end;

    if buttonIdx == 0 then
        return KingOfFighters.GetNormalAttackSkillID();
    end
    if skillList[buttonIdx] == nil then return end;
    return skillList[buttonIdx].id;
end

function KingOfFighters.SkillIsNeedCheckLimit(skillID)
    if not isSingleFightMap then
        return true, true
    end

    if skillID == nil then
        PromptPanel.ShowMessage("KingOfFighters.SkillIsNeedCheckLimit skillID is nil ");
        return true, true;
    end

    local skillConfig = SkillManager.GetSkillConfig(skillID);
    if skillConfig == nil then
        PromptPanel.ShowMessage("KingOfFighters.SkillIsNeedCheckLimit skillConfig is nil: "..skillID);
        return true, true;
    end

    local checkMoveLimit = true;
    if skillConfig.checkMoveLimit ~= nil then
        checkMoveLimit = skillConfig.checkMoveLimit;
    end

    local checkAttackLimit = true;
    if skillConfig.checkAttackLimit ~= nil then
        checkAttackLimit = skillConfig.checkAttackLimit;
    end

    return checkMoveLimit, checkAttackLimit;
end

function KingOfFighters.GetNextNormalAttackSkillID()
    local num = #normalAttackList;
    if lastNormalAttackInfo.index < num then
        return normalAttackList[lastNormalAttackInfo.index+1];
    else
        return normalAttackList[1];
    end

end

function KingOfFighters.OnClickNormalAttack()


    --重新做一版 普通玩法
    local num = #normalAttackList;
    if num == 0 then
        return false;
    end;

    if waitingRsp then
        if Time.unscaledTime - startWaitingTime < 5 then
            return false;
        end;
    end;

    --[[soldier_add
    普通攻击, 例如剑客, 第4段的攻击硬直影响了翻滚,导致了第1段的autoBlink无法生效,
    这里单独做一个处理:
    1.判断前方选敌范围内是不是有怪物
    2.如果有 	--> 进入autoBlink并充值attackLimit 和 moveLimit
    3.如果没有	-->	寻找非前方范围内是否有敌人可以攻击
    ]]

    --soldier 临时屏蔽掉, castSkill里面会有这个的判断, 这个应该不损耗强大CPU的性能
    --这里需要拿到skillID做判断

    --[[	local nextNormalAttackID = KingOfFighters.GetNextNormalAttackSkillID();
        local isCheckMove, isCheckAttack = KingOfFighters.SkillIsNeedCheckLimit(nextNormalAttackID);

        if not isCheckAttack then
            LOCAL_CHAR:ResetAttackLimit();
            LOCAL_CHAR:ResetMoveLimit();
        end
        --error("normalAttack skillID: "..nextNormalAttackID);--]]
    if not LOCAL_CHAR:CanAttack() then
        return false;
    end;

    local skillID = 0;
    if Time.timeSinceLevelLoad - lastNormalAttackInfo.time < 2 then
        if lastNormalAttackInfo.index < num then
            lastNormalAttackInfo.index = lastNormalAttackInfo.index + 1;
            skillID = normalAttackList[lastNormalAttackInfo.index];
        else
            lastNormalAttackInfo.index = 1;
            skillID = normalAttackList[1];
        end;
    else
        lastNormalAttackInfo.index = 1;
        skillID = normalAttackList[1];
    end;



    if not LOCAL_CHAR:CanAttack() then
        return false;
    end

    if skillID and skillID > 0 then
        lastNormalAttackInfo.time =  Time.timeSinceLevelLoad

        return this.CastSkill(skillID)
    end;

    do return end;
    --[[if LOCAL_CHAR:CanAttack() then
        if Time.timeSinceLevelLoad - lastCanAttackTime < 0.3 then
            if lastCastSkill == normalAttackList[1] then
                this.CastSkill(normalAttackList[2]);
            elseif lastCastSkill == normalAttackList[2] then
                 this.CastSkill(normalAttackList[3]);
             elseif lastCastSkill == normalAttackList[3] and normalAttackList[4] then
                  this.CastSkill(normalAttackList[4]);
             elseif lastCastSkill == normalAttackList[4] and normalAttackList[5] then
                  this.CastSkill(normalAttackList[5]);
            else
                this.CastSkill(normalAttackList[1]);
            end;
        else
            this.CastSkill(normalAttackList[1]);
        end;


         --先写死 后面根据职业来做功能
    else
        if Time.timeSinceLevelLoad - lastCastTime > 0.1 then
            if lastCastSkill == normalAttackList[1] then
                KingOfFighters.PushInputBuffer(normalAttackList[2]);
            elseif lastCastSkill == normalAttackList[2] then
                KingOfFighters.PushInputBuffer(normalAttackList[3]);
            end;
        end;

    end;--]]

end;

function KingOfFighters.OnClickSkillButton(index, params)

    if waitingRsp then
        if Time.unscaledTime - startWaitingTime < 5 then
            return ;
        end;
    end;

    if skillList[index] == nil then
        --error("KingOfFighters.OnClickSkillButton" ..index);
        return;
    end
    local skillID = skillList[index].id;
    if LOCAL_CHAR:CanAttack(true) then

        return this.CastSkill(skillID, params);
    elseif Time.timeSinceLevelLoad - lastCastTime > 0.2 then
        KingOfFighters.PushInputBuffer(skillID);
        return false
    end;

    return true;
end;

local lastCanAttackState = true;
local lastCanMoveState = true;
function KingOfFighters.Update(deltaTime)


    if not LOCAL_CHAR then
        return;
    end;
    local state = LOCAL_CHAR:CanAttack();

    if lastCanAttackState == false and state == true then
        KingOfFighters.OnTransToCanAttack();
    end;

    local moveState = LOCAL_CHAR:CanMove();
    if lastCanMoveState == false and  moveState == true then
        JoyStickPanel.OnCastSkill();
    end

    lastCanMoveState = moveState;
    lastCanAttackState = state;

    KingOfFighters.UpdateTrace();

end;

--可攻击了
function KingOfFighters.OnTransToCanAttack()
    SkillButtonPanel.OnTransToCanAttack();


    --检查输入缓冲
    JoyStickPanel.OnCastSkill();
    local skillID, inputTime = KingOfFighters.PopInputBuffer();


    if skillID >0.5 and Time.timeSinceLevelLoad - inputTime < 0.5 then
        this.CastSkill(skillID);
    end;

    JoyStickPanel.OnCastSkill();
    lastCanAttackTime = Time.timeSinceLevelLoad;
end;


--技能成功的回调

function KingOfFighters.OnCastSkill(skillID)


    lastCastSkill = skillID;
    lastCastTime = Time.timeSinceLevelLoad;
    JoyStickPanel.OnCastSkill();

    local skillConfig = SkillManager.GetSkillConfig(skillID);
    if not skillConfig then
        return ;
    end;

    --看下有没有next技能

    local masterSkillID = skillConfig.masterskill or 0;

    if masterSkillID > 0 then --连招技能都会配这个值
        local nextSkill = skillConfig.nextskill or 0;
        local index = idToIndex[masterSkillID];
        --打开连招UI
        if masterSkillID == skillID and nextSkill > 0 then

            if index then
                local image = SkillButtonPanel.GetSkillImage(index);
                ComboSkillPanel.StartComboSkill(image, skillConfig.combocount or 5, skillConfig.nextskilltime);
                SkillButtonPanel.StartShine(index);
            end
        end

        --连招进行中
        local currCombo = skillConfig.currcombo or 0;
        if currCombo > 1 then
            ComboSkillPanel.OnCastCombo(currCombo, skillConfig.nextskilltime);
        end


        if nextSkill > 0 then
            --非结束段
            if not nextSkillDatas[masterSkillID] then
                nextSkillDatas[masterSkillID] = {};
            end
            nextSkillDatas[masterSkillID].skill = nextSkill;

            local timerFunc = function()
                --时间到了进cd 并且清空掉
                KingOfFighters.DoSetCD(nil, masterSkillID);
                nextSkillDatas[masterSkillID] = nil;
                ComboSkillPanel.EndComboSkill();--结束连招UI
                if index then
                    SkillButtonPanel.EndShine(index);
                end;
            end;

            if nextSkillDatas[masterSkillID].timer then
                nextSkillDatas[masterSkillID].timer:Reset(timerFunc, skillConfig.nextskilltime, 1, true, nil, true);
            else
                nextSkillDatas[masterSkillID].timer = Timer.New(timerFunc, skillConfig.nextskilltime, 1, true, nil):Start();

            end;

        else
            --  结束段
            if nextSkillDatas[masterSkillID] and nextSkillDatas[masterSkillID].timer then
                nextSkillDatas[masterSkillID].timer:Stop()
            end;
            nextSkillDatas[masterSkillID] = nil;
            ComboSkillPanel.EndComboSkill();--结束连招UI
            KingOfFighters.DoSetCD(nil, masterSkillID);
            if index then
                SkillButtonPanel.EndShine(index);
            end;
        end;
        return ;
    end;


    --计入cd

    KingOfFighters.DoSetCD(skillConfig);
    --[[if skillConfig and skillConfig.cd then
        local CDExpireTime = Time.timeSinceLevelLoad + skillConfig.cd;
        --没cd 或者这个cd更大
        if not CDList[skillConfig.cdtype] or CDExpireTime > CDList[skillConfig.cdtype] then 
            CDList[skillConfig.cdtype] = CDExpireTime;
            SkillButtonPanel.ShowCoolDown(idToIndex[skillID], skillConfig.cd,skillConfig.cd );
        end;

    end;]]
end;

function KingOfFighters.DoSetCD(skillConfig, skillID, cd)
    if not skillConfig then
        skillConfig = SkillManager.GetSkillConfig(skillID);
    end;
    if not skillConfig then
        return ;
    end;

    cd = cd or skillConfig.cd;
    --cd = 2;
    local CDExpireTime = Time.unscaledTime + cd;
    if not CDList[skillConfig.cdtype] or CDExpireTime > CDList[skillConfig.cdtype] then
        CDList[skillConfig.cdtype] = CDExpireTime;
        SkillButtonPanel.ShowCoolDown(idToIndex[skillConfig.id], cd,cd );
    end;
end;

function KingOfFighters.RefreshAllCD()
    for k,skillConfig in pairs(skillList) do
        if skillConfig then
            if CDList[skillConfig.cdtype] then
                local leftTime = CDList[skillConfig.cdtype] - Time.unscaledTime;
                if leftTime < 0 then leftTime = 0 end;
                SkillButtonPanel.ShowCoolDown(idToIndex[skillConfig.id], skillConfig.cd, 0 );
            else
                SkillButtonPanel.ShowCoolDown(idToIndex[skillConfig.id], skillConfig.cd, 0 );
            end


        end;
    end;
    CDList = {}
    if LOCAL_CHAR then
        LOCAL_CHAR.fightServerCDInfo = nil;
    end
end;


function KingOfFighters.CastSkill(skillID, params)
    --if not LOCAL_CHAR:CanAttack() then
    --   return ;
    -- end;
    InteractionManager.CheckInteractionAndChange()
    if  LOCAL_CHAR._autoFlying then return end;
    if TraficManager.IsInTrafic() then return end;

    if LOCAL_CHAR:IsRiding() then
        if LOCAL_CHAR:IsRideFlying() then
            RideManager.ChangeRideState();
            return false;
        else
            LOCAL_CHAR.UnRideCastSkill = {skillID, params};
            RideManager.ReqUnRide();
        end;
        return false;
    end;

    if nextSkillDatas[skillID] then
        skillID = nextSkillDatas[skillID].skill;
    end;

    if GlobalNavManager.IsNaving() then
        if GlobalNavManager.CanBreak() then
            GlobalNavManager.StopNav()
        else
            return false;
        end;

    end;

    local ret, distanceSub, shiftPos, wantedTarget = KingOfFighters.PreCastSkill(skillID, params);
    if not ret then
        return false;
    end;
    local level = KingOfFighters.GetSkillLevel(skillID);
    --  LOCAL_CHAR:StopNav(InSingleMap);

    --  --error("local char castskill="..skillID);
    waitingRsp = true;
    startWaitingTime = Time.unscaledTime;
    local skillConfig = SkillManager.GetSkillConfig(skillID);
    FightNetwork.ReqCastSkill(skillID, distanceSub, shiftPos, level, wantedTarget, not (skillConfig.readbar ~= nil and skillConfig.readbar > 0));
    return true;
end;

function t(config)

end;

function KingOfFighters.PreCastSkill(skillID, params)
    local skillConfig = SkillManager.GetSkillConfig(skillID);
    if not skillConfig then
        return false;
    end;

    local CDExpireTime = 0;
    if skillConfig.cdtype and CDList[skillConfig.cdtype] then
        CDExpireTime = CDList[skillConfig.cdtype];
    end;

    if CDExpireTime > Time.unscaledTime then
        return false;
    end;
    local distanceSub = 0;

    --一些比较特殊的目标选取
    if skillConfig.GetTargetInfo then
        return skillConfig:GetTargetInfo()
    end;

    local shiftPos = nil;
    if skillConfig.GetShiftPos then
        shiftPos = skillConfig.GetShiftPos();
        if shiftPos then
            LOCAL_CHAR:LookAtPoint(shiftPos);
        end;
    end

    local tmp , manual = EnemySelUtil.GetLockEnemy();
    if tmp and manual then
    else
        if lockTargetV2 then
            EnemySelUtil.LockEnemy(lockTargetV2);
        else
            lockTargetV2 = KingOfFighters.TryReGetTargetV2(skillConfig.lockDistance);
            if lockTargetV2 then
                EnemySelUtil.LockEnemy(lockTargetV2);
            end;
        end;
        EnemySelUtil.SetCurrIsManualLock(false);
    end
    --在这里做一个选择 V2


    --先看锁定目标技能
    if skillConfig.mustLock then
        local currTarget = EnemySelUtil.GetLockEnemy();

        if SkillButtonPanel.IsUseSkillDir() then
            local t = SkillSelectDirManager.GetTargetPos();
            local dir = t - LOCAL_CHAR:GetPos();
            currTarget = KingOfFighters.FindMustLockTargetByDir(dir, skillConfig.lockDistance, currTarget)
            if currTarget then
                -- EnemySelUtil.LockEnemy(currTarget)
            else
                --ErrorCodeShow.Show(1000030)
                --return false; --锁定技能无需目标
            end;
        elseif not currTarget or not currTarget:IsEnemy(LOCAL_CHAR) then
            --要选一个目标
            currTarget = EnemySelUtil.SelNextMonster()
        end;

        if not currTarget then
            --ErrorCodeShow.Show(1000023)
            --return false --锁定技能无需目标
        end

        --看距离
        if currTarget then
            if Vector3.SqrDistance(LOCAL_CHAR:GetPos(), currTarget:GetPos()) <= (skillConfig.castDistance + currTarget:GetHitRange())^2 then
                LOCAL_CHAR:LookAt(currTarget)
                return true, nil, nil, currTarget
            else
                this.SetTraceTarget(currTarget, skillConfig.castDistance, skillID)
                return false;
            end;
        end

    end;

    --先看看技能摇杆

    if SkillButtonPanel.IsUseSkillDir() then
        --error("SkillButtonPanel.IsUseSkillDir() is true");
        local t = SkillSelectDirManager.GetTargetPos();
        if t then
            LOCAL_CHAR:LookAtPoint(t);
        end;

        local selectLen = nil;
        if params ~= nil and params ~= nil then
            selectLen = params.selectLen;
        end

        --当没有移动的时候, selectLen 设置为nil值
        --为了自动选怪
        if selectLen ~= nil and skillConfig.skillDirInfo ~= nil then
            distanceSub = skillConfig.skillDirInfo.selectRadius - selectLen;
        end
        this.StopTrace()
        if shiftPos then
            LOCAL_CHAR:LookAtPoint(shiftPos);
        end;


        --应某些玩家需求 试试 再从这选个怪看看

        local tryReLock =true;

        local currTarget = EnemySelUtil.GetLockEnemy();

        if currTarget then
            local dis = Vector3.Distance(currTarget:GetPos(), LOCAL_CHAR:GetPos());
            if dis > (skillConfig.lockDistance or 10) then
                tryReLock = true;
            end;

            if this.CalcTargetAngle(currTarget) < 8 then
                tryReLock = false;
            end;
        end;

        if tryReLock   then
            local oldTarget = EnemySelUtil.GetLockEnemy();
            EnemySelUtil.LockEnemy(nil);

            local tryLockTarget = KingOfFighters.ChooseTargetByForward(skillConfig.lockDistance or 15);
            if tryLockTarget then
                EnemySelUtil.LockEnemy(tryLockTarget);
                EnemySelUtil.SetCurrIsManualLock(true);
            else
                EnemySelUtil.LockEnemy(oldTarget);
                EnemySelUtil.SetCurrIsManualLock(true);
            end;
        end;


        return true, distanceSub, shiftPos, nil;
    end

    if not skillConfig.autoChooseTarget then
        return true;
    end




    --local lockDistance =  skillConfig.lockDistance or 0;
    --local castDistance =  skillConfig.castDistance or 999;
    local lockDistance =  skillConfig.lockDistance or 15;
    local castDistance =  skillConfig.castDistance or 3;
    local currDistance = 999;

    local currLockTarget, ismanual = EnemySelUtil.GetLockEnemy();



    if not currLockTarget or Vector3.Distance(LOCAL_CHAR:GetPos(), currLockTarget:GetPos()) > lockDistance then
        --这里表示要重新选个目标啦
        if ismanual then
            EnemySelUtil.LockEnemy(nil);
            EnemySelUtil.SetCurrIsManualLock(false);
        end
        local newChoose = KingOfFighters.ChooseTarget(lockDistance, true);
        if newChoose then
            currLockTarget = newChoose;
            EnemySelUtil.LockEnemy(currLockTarget);
        else
            --没选到 那么就直接trace当前这个
            if lockDistance > 0 and currLockTarget then
                if Vector3.Distance(LOCAL_CHAR:GetPos(), currLockTarget:GetPos()) < lockDistance then
                    this.SetTraceTarget(currLockTarget, castDistance, skillID)
                    return false
                end
            end;

        end;
    end;

    if currLockTarget then
        --当前锁定了一个目标  
        local currDistance = Vector3.Distance(LOCAL_CHAR:GetPos(), currLockTarget:GetPos());

        if currDistance <= castDistance then
            --这个家伙就在释放范围内 那就看着他 放技能


            if skillConfig.autoChooseDistanceSub == true then
                distanceSub = skillConfig.autoChooseDistanceMax - currDistance;
            end;
            if shiftPos then
                LOCAL_CHAR:LookAtPoint(shiftPos);
            else
                LOCAL_CHAR:LookAt(currLockTarget);
            end;

            this.StopTrace();
            return  true, distanceSub, shiftPos, currLockTarget;
        elseif Vector3.Distance(LOCAL_CHAR:GetPos(), currLockTarget:GetPos()) < lockDistance  then
            --距离不够 追踪 todo

            this.SetTraceTarget(currLockTarget, castDistance, skillID)
            return false;
        end;
    end;

    --到这里 表示没有合适的锁定目标  直接释放
    this.StopTrace();
    if shiftPos then
        LOCAL_CHAR:LookAtPoint(shiftPos);
    end;
    return true , 0, shiftPos, nil;



end;

function KingOfFighters.GetAngle(dir, target)
    local dir2 = target:GetPos() - LOCAL_CHAR:GetPos();
    dir2.y = 0;
    return Vector3.Angle(dir, dir2);
end
local mustLockFindAngle = 30;
function KingOfFighters.FindMustLockTargetByDir(dir, range, defaultTarget)
    local retActor = nil;
    local retActorAngle = mustLockFindAngle + 0.1;

    if defaultTarget and Vector3.SqrDistance(LOCAL_CHAR:GetPos(), defaultTarget:GetPos()) <= range * range then
        local newAngle = this.GetAngle(dir, defaultTarget);
        if newAngle < mustLockFindAngle then
            return defaultTarget;
        end;
    end;



    local fun = function (id, actor)
        if actor:IsDead() then return false; end; --死亡的忽略
        if actor:IsHide() then return false; end; --藏起来了的 忽略
        if actor:GetFuncType() == NpcFuncType_FreeFight then return false; end; --箱子罐子  先忽略
        if not LOCAL_CHAR:IsEnemy(actor) then return false ; end; --不是敌人  忽略
        if Vector3.SqrDistance(LOCAL_CHAR:GetPos(), actor:GetPos()) > range * range then return false end;

        local newAngle = KingOfFighters.GetAngle(dir, actor)
        if newAngle < retActorAngle then
            retActor = actor;
            retActorAngle = newAngle;
        end;

    end;

    ActorManager.EnumActors(fun, nil);

    return retActor;
end;

--[[if skillConfig.autoChooseDistanceSub == true and nearestEnemy then
			if skillConfig.autoChooseDistanceMax > nearestEnemyDistance then
				distanceSub = skillConfig.autoChooseDistanceMax - nearestEnemyDistance;
			end;
		end;]]

function KingOfFighters.PreCastSkill_back(skillID, params)

    local skillConfig = SkillManager.GetSkillConfig(skillID);
    if not skillConfig then
        return false;
    end;

    local CDExpireTime = 0;
    if skillConfig.cdtype and CDList[skillConfig.cdtype] then
        CDExpireTime = CDList[skillConfig.cdtype];
    end;

    if CDExpireTime > Time.unscaledTime then
        return false;
    end;


    local nearestEnemy = nil;
    local nearestEnemyDistance = 0;





    local lockTarget =  EnemySelUtil.GetLockEnemy();
    if lockTarget and skillConfig.normalattack then
        --追杀这个哥们
        local nowdistance = Vector3.Distance(LOCAL_CHAR:GetPos(), lockTarget:GetPos())
        if nowdistance < skillConfig.autoChooseDistance then
            LOCAL_CHAR:LookAt(lockTarget);
            return true;
        elseif nowdistance < 20 then
            KingOfFighters.SetTraceTarget(lockTarget, skillConfig.autoChooseDistance - 0.5)
            return false;
        end;
    end;




    --需要滚动到敌人旁边的
    if isSingleFightMap and skillConfig.autoBlink == true then

        local localPos = LOCAL_CHAR:GetPos();
        local joystickForward = JoyStickPanel.GetLastDir();
        nearestEnemy, nearestEnemyDistance = KingOfFighters.ChooseTarget(skillConfig.autoBlinkMaxDistance, false);
        if nearestEnemy then

            local distance = nearestEnemyDistance;
            distance = distance - nearestEnemy._hitRange;

            if distance > skillConfig.autoBlinkMinDistance and distance < skillConfig.autoBlinkMaxDistance then
                --ok 计算那个需要滚动到的位置

                local dir = nearestEnemy:GetPos() - localPos;
                dir:SetNormalize();

                local moveDistance = distance - skillConfig.autoBlinkLeftDistance;
                if moveDistance > 0.5 then
                    --计算移动到的位置
                    local dstPos = localPos + dir * moveDistance;

                    --看看是否穿障碍 以及把目标点放到navmesh上
                    local ret,hit = NavMesh.Raycast(localPos, dstPos, nil, 1);
                    if not ret then

                        --没穿障碍 那么放到navmesh上来
                        local ret, hit = NavMesh.SamplePosition(dstPos, nil, 50, 1);
                        if ret == true then
                            dstPos = hit.position;

                            local moveTime = moveDistance / skillConfig.autoBlinkSpeed;
                            LOCAL_CHAR:ShiftMove(nil, dstPos, Time.timeSinceLevelLoad, Time.timeSinceLevelLoad + moveTime);
                            LOCAL_CHAR:PushAttackLimit(moveTime);
                            --						   LOCAL_CHAR:BeginSkillAnimation();
                            LOCAL_CHAR:PushMoveLimit(moveTime);
                            KingOfFighters.PushInputBuffer(skillID);
                            lastCastSkill = 0;
                            LOCAL_CHAR:LookAt(nearestEnemy);

                            --来个滚动的动作
                            FcActionFactory.CreateAction({type = FcAction_Animation; animation = skillConfig.autoBlinkAnimation;lifetime=moveTime;offsettime=0;}, LOCAL_CHAR);
                            --动作根据时间来调整速度
                            --  local speed = skillConfig.autoBlinkAnimationTime / moveTime;
                            -- FcActionFactory.CreateAction({type = FcAction_AnimSpeed; speed = skillConfig.autoBlinkAnimation;lifetime=moveTime;offsettime=0;}, LOCAL_CHAR);
                            return false;

                        end
                    end;

                end;


            end;
        end;
    end;


    --自动选怪的方向

    if skillConfig.autoChooseTarget == true then
        -- local joystickForward =  JoyStickPanel.GetLastDir();
        -- local actor, d = SkillButtonPanel.GetPreCastSkillInfo();
        local actor, d = KingOfFighters.ChooseTarget(skillConfig.autoChooseDistance or 5,  skillConfig.autoChooseOnlyPlayer);
        if actor then
            LOCAL_CHAR:LookAt(actor);
            nearestEnemy = actor;
            nearestEnemyDistance = d;

            EnemySelUtil.SelEnemy(actor)
        end;
    end;

    --[[--瞬间精确方向 摇杆指哪打哪
    if skillConfig.immediateDir == true then
        local joystickForward = JoyStickPanel.GetLastDir();
        if joystickForward then
            LOCAL_CHAR:GetTransform().forward = joystickForward;
        end;
    end;--]]

    local distanceSub = 0;--需要缩减的距离
    local selectLen = nil;
    if params ~= nil and params ~= nil then
        selectLen = params.selectLen;
    end

    --当没有移动的时候, selectLen 设置为nil值
    --为了自动选怪
    if selectLen ~= nil and skillConfig.skillDirInfo ~= nil then
        --按照玩家自己选择的来
        --error("selectLen = "..selectLen);
        distanceSub = skillConfig.skillDirInfo.selectRadius - selectLen;
    else
        if skillConfig.autoChooseDistanceSub == true and nearestEnemy then
            if skillConfig.autoChooseDistanceMax > nearestEnemyDistance then
                distanceSub = skillConfig.autoChooseDistanceMax - nearestEnemyDistance;
            end;
        end;
    end




    if SkillButtonPanel.IsUseSkillDir() then
        --error("SkillButtonPanel.IsUseSkillDir() is true");
        local t = SkillSelectDirManager.GetTargetPos();
        if t then
            LOCAL_CHAR:LookAtPoint(t);
        end;
    end

    local shiftPos = nil;
    if skillConfig.GetShiftPos then
        shiftPos = skillConfig.GetShiftPos();
        if shiftPos then
            LOCAL_CHAR:LookAtPoint(shiftPos);
        end;
    end


    return true, distanceSub, shiftPos, nearestEnemy;

end;

function KingOfFighters.ChooseNearstEnemyOfPos(pos, dis)
    local currNearestDistance = dis;
    local retActor = nil;

    local fun = function (id, actor)
        if LOCAL_CHAR:IsEnemy(actor) and (not actor:IsDead()) and (not actor:IsHide()) and actor:GetFuncType() ~= NpcFuncType_FreeFight then

            local t = actor:GetPos() - pos;
            t . y = 0;

            local currDistance = Vector3.Distance(pos, actor:GetPos());
            if currDistance < dis then
                if currDistance < currNearestDistance then
                    retActor = actor;
                    currNearestDistance = currDistance;
                end;
            end;
        end;
    end;

    ActorManager.EnumActors(fun, nil);
    return retActor, currNearestDistance;
end;

function testfind()
    local a = KingOfFighters.ChooseTarget(10, false);
    if a then
        EnemySelUtil.SelEnemy(a);
        error("find");
    end;

end;

function KingOfFighters.CalcTargetAngle(actor)
    local t = actor:GetPos() - LOCAL_CHAR:GetPos();
    if t.x == 0 and t.y==0 and t.z==0 then return 0 end;
    return Vector3.Angle(t, LOCAL_CHAR:GetTransform().forward);
end;
--重新理一遍，
function KingOfFighters.ChooseTargetByForward(maxDistance)
    local ret = nil
    local retDistance = 9999;
    local retAngle = 9999;
    local fun = function (id, actor)
        if actor:IsDead() then return false; end; --死亡的忽略
        if actor:IsHide() then return false; end; --藏起来了的 忽略
        if actor:GetFuncType() == NpcFuncType_FreeFight then return false; end; --箱子罐子  先忽略
        if not LOCAL_CHAR:IsEnemy(actor) then return false ; end; --不是敌人  忽略


        if ret == nil then
            ret = actor;
            retDistance = Vector3.Distance(LOCAL_CHAR:GetPos(), ret:GetPos());
            if retDistance > maxDistance then
                retDistance = 9999
                ret=nil;
                return false;
            end;
            retAngle = this.CalcTargetAngle(ret)
            return false;
        end;

        local currDistance = Vector3.Distance(LOCAL_CHAR:GetPos(), actor:GetPos());
        local currAngle = this.CalcTargetAngle(actor)


        if currAngle < retAngle and currDistance < maxDistance then
            --这个比上个要正
            local delta = retAngle - currAngle;
            if delta >= 45 then --超过了30度了 直接看距离
                if currDistance < maxDistance then
                    ret = actor;
                    retDistance = currDistance;
                    retAngle = currAngle
                    return false
                end;
            elseif delta >= 15 then
                if currDistance < retDistance - 1.5 then
                    ret = actor;
                    retDistance = currDistance;
                    retAngle = currAngle
                    return false
                end;
            else
                if currDistance < retDistance - 3 then
                    ret = actor;
                    retDistance = currDistance;
                    retAngle = currAngle
                    return false
                end;
            end;
        end;

    end;
    ActorManager.EnumActors(fun, nil);
    return ret;

end;
function KingOfFighters.ChooseTarget(maxDistance, onlyPlayer)
    if InSingleMap then maxDistance = maxDistance + 4; end;
    local retTarget = nil;
    local retAngle = 360;
    local retDistance = maxDistance;
    local joystickForward = JoyStickPanel.GetLastDir();

    if joystickForward then
        error("有方向啊我曹尼玛")
    end;

    local selTarget = EnemySelUtil.GetCurrSelEnemy();
    if selTarget then--当前选择了一个敌对目标

        if onlyPlayer and not selTarget:GetType() ~= ActorType_Player then
            --这个目标不是人  但我这次需要选人 那么就啥都不干咯

        elseif joystickForward then
            --按下了摇杆  那就看这个目标与我的方向对应否 距离对应否
            local distance = Vector3.Distance(LOCAL_CHAR:GetPos(), selTarget:GetPos());
            local t = selTarget:GetPos() - LOCAL_CHAR:GetPos(); --拿到到目标的向量
            t . y = 0;
            local angle =  Vector3.Angle(t, joystickForward);

            if angle < 30--[[60度除以2]] and distance < maxDistance + selTarget:GetHitRange() then
                return selTarget , distance;
            end;
        else
            --没有 就看距离是否对

            local distance = Vector3.Distance(LOCAL_CHAR:GetPos(), selTarget:GetPos());
            if distance < maxDistance + selTarget:GetHitRange() then
                --error("我曹咋回事")
                return selTarget, distance
            end;
        end;
    end;


    local retActorInFront = false;
    local fun = function (id, actor)
        if onlyPlayer and actor:GetType() ~= ActorType_Player then  return false end; --只能选人的就无视
        if actor:IsDead() then return false; end; --死亡的忽略
        if actor:IsHide() then return false; end; --藏起来了的 忽略
        if actor:GetFuncType() == NpcFuncType_FreeFight then return false; end; --箱子罐子  先忽略
        if not LOCAL_CHAR:IsEnemy(actor) then return false ; end; --不是敌人  忽略

        local distance = Vector3.Distance(LOCAL_CHAR:GetPos(), actor:GetPos());



        --有按着方向吗 分开两种情况处理
        if joystickForward then
            local distance = Vector3.Distance(LOCAL_CHAR:GetPos(), actor:GetPos());
            local t = actor:GetPos() - LOCAL_CHAR:GetPos(); --拿到到目标的向量
            t . y = 0;
            local angle =  Vector3.Angle(t, joystickForward);

            if angle < 30 and  distance < maxDistance then

                if retActorInFront  then --选了一个前面的角色了 那就看距离
                    if distance < retDistance then
                        retTarget = actor;
                        retDistance = distance;
                    end;
                else--那就直接这个咯 第一个遇到的front的角色
                    retTarget = actor;
                    retDistance = distance;
                    retActorInFront = true;
                end;
                retAngle = angle;

            elseif not retActorInFront and angle < retAngle and distance < maxDistance then -- infront false 表示没选到过面前的怪 才可以走到这里哟
                retTarget = actor;
                retDistance = distance;
                retAngle = angle;
            end;


        else
            --error("daoel")
            if distance < retDistance then
                --error("xuanle"..retTarget)
                retDistance = distance;
                retTarget = actor;
            end
        end;


    end;
    ActorManager.EnumActors(fun, nil);
    return retTarget, retDistance;



end;

--朝向优先啦
function KingOfFighters.ChooseNearstEnemy(distance, forward, chooseAngle, onlyPlayer)


    local angle = 180;
    local maxDistance = distance;
    if not chooseAngle then
        chooseAngle = 22.5
    else
        chooseAngle = chooseAngle /2; --下面计算用的是夹角的一半哟
    end;

    local needForward = forward; --应该往那边开始搞
    if not needForward then needForward = LOCAL_CHAR:GetTransform().forward; end;

    --重做一版
    --先不管当前选择的人 选一个最好的目标先
    local choosedBestTarget = nil;
    local chooseLastAngle = 180;
    local choseLastDistance = 999;
    local fun = function (id, actor)

        if onlyPlayer and actor:GetType() ~= ActorType_Player then  return false end; --只能选人的就无视
        if actor:IsDead() then return false; end; --死亡的忽略
        if actor:IsHide() then return false; end; --藏起来了的 忽略
        if actor:GetFuncType() == NpcFuncType_FreeFight then return false; end; --箱子罐子  先忽略
        if not LOCAL_CHAR:IsEnemy(actor) then return false ; end; --不是敌人  忽略

        local t = actor:GetPos() - LOCAL_CHAR:GetPos(); --拿到到目标的向量
        t . y = 0;

        local currDistance = Vector3.Distance(LOCAL_CHAR:GetPos(), actor:GetPos());
        if currDistance > chooseAngle then return false; end; --距离太远  忽略

        local currAngle =  Vector3.Angle(t, needForward);
        if currAngle > chooseAngle then return false end;--夹角太大 忽略



        --ok 这个人在选择范围内 那么我就选一个最近的 但是 如果他们距离隔得不远 那就选夹角最小的


        if choosedBestTarget == nil then
            choosedBestTarget = actor;
            chooseLastAngle = currAngle;
            choseLastDistance = currDistance;
            return false; --记住 这个return false 是表示 continue
        end;

        local lastActorType = choosedBestTarget:GetType();
        local currActorType = actor:GetType();
        --[[
         if currActorType == ActorType_Player and lastActorType == ActorType_Npc and SkillButtonPanel.GetPlayerFirst() then --优先选人咯
             choosedBestTarget = actor;
             chooseLastAngle = currAngle;
             choseLastDistance = currDistance;
             return false; --记住 这个return false 是表示 continue
         elseif  lastActorType == ActorType_Player and currActorType == ActorType_Npc and SkillButtonPanel.GetPlayerFirst() then
             return false; --当前是npc 上一个是人 直接忽略
         end;]]

        if currDistance < choseLastDistance - 0.5 then
            -- 近0.5米了 就无视角度了
            choosedBestTarget = actor;
            chooseLastAngle = currAngle;
            choseLastDistance = currDistance;
            return false;
        elseif currAngle < chooseLastAngle then
            choosedBestTarget = actor;
            chooseLastAngle = currAngle;
            choseLastDistance = currDistance;
            return false;
        end;

        local comp = chooseAngle;
        if not retActor then
            comp = angle;
        end;

        if((not onlyPlayer) or actor:GetType() == ActorType_Player) and (currAngle <= chooseAngle or retActor == nil) and currDistance < maxDistance then
            if currDistance < distance then
                retActor = actor;
                distance = currDistance;
                angle = currAngle;
            end;
        end;

    end;
    ActorManager.EnumActors(fun, nil);

    if choosedBestTarget then
        EnemySelUtil.SelEnemy(choosedBestTarget)
    else
        local selEnemy = EnemySelUtil.GetCurrSelEnemy();
        if selEnemy  then
            if onlyPlayer and selEnemy:GetType() ~= ActorType_Player then return nil, 0 end;
            return selEnemy, Vector3.Distance(LOCAL_CHAR:GetPos(), selEnemy:GetPos())
        end;
    end;

    return choosedBestTarget, choseLastDistance;


    --[[ local retActor = EnemySelUtil.GetCurrSelEnemy();
     if (not joystickForward) and  retActor and (not retActor:IsHide()) and ((not onlyPlayer) or retActor:GetType() == ActorType_Player) then
         local currDistance = Vector3.Distance(LOCAL_CHAR:GetPos(), retActor:GetPos());

         if forward then
             --传了一个forward来了  看看在不在范围内 不在就不管这个选择了
             local t = retActor:GetPos() - LOCAL_CHAR:GetPos();
             t . y = 0;

             if Vector3.Angle(t, forward) < 22.5 and currDistance < distance then
                 return retActor, currDistance;
             end;
         else
             return retActor,currDistance;
         end;
     else

         retActor = nil;
     end;

     local needForward = forward;
     if not needForward then needForward = LOCAL_CHAR:GetTransform().forward; end;

     local fun = function (id, actor)
         if LOCAL_CHAR:IsEnemy(actor) and (not actor:IsDead()) and (not actor:IsHide()) and actor:GetFuncType() ~= NpcFuncType_FreeFight then

             local t = actor:GetPos() - LOCAL_CHAR:GetPos();
             t . y = 0;
             local currAngle =  Vector3.Angle(t, needForward);
             local currDistance = Vector3.Distance(LOCAL_CHAR:GetPos(), actor:GetPos());

             local comp = chooseAngle;
             if not retActor then
                 comp = angle;
             end;

             if((not onlyPlayer) or actor:GetType() == ActorType_Player) and (currAngle <= chooseAngle or retActor == nil) and currDistance < maxDistance then
                 if currDistance < distance then
                     retActor = actor;
                     distance = currDistance;
                     angle = currAngle;

                 end;
             end;
         end;
     end;

     ActorManager.EnumActors(fun, nil);

     if retActor then
         EnemySelUtil.SelEnemy(retActor)
     end;
     return retActor, distance;]]
end;

function KingOfFighters.ChooseNearstCollectNpc(distance)
    local retActor = nil;
    local fun = function (id, actor)
        if not actor:IsDead() and actor:CheckIsCollectNpc() then
            local currDistance = Vector3.Distance(LOCAL_CHAR:GetPos(), actor:GetPos());
            if currDistance < distance then
                retActor = actor;
                distance = currDistance;
            end;
        end;
    end;

    ActorManager.EnumActors(fun, nil);

    return retActor, distance;
end

function KingOfFighters.OnMapChange(mapID)
    isSingleFightMap = false;
    local mapConfig = MapManager.GetMapConfig(mapID);
    if mapConfig then
        if mapConfig.single == true and mapConfig.type==MapType_Fight then
            isSingleFightMap = true;
        end;
    end;

    if #normalAttackList == 0 then
        KingOfFighters.ReloadSkills()
    end;
    CDList = {};


    KingOfFighters.isSingleFightMap = isSingleFightMap;

    KingOfFighters.ResetTargetV2()

end;

--重新加载当前角色的技能列表 传一个mapid过来  表示要特殊处理某个map的技能列表
function KingOfFighters.ReloadSkills(useServerData)
    if LOCAL_CHAR == nil then return end
    local skillIDList = nil;
    local skillLevelList = nil;
    local mapID = MapManager.GetCurMap().id;
    --新手第一个国窖惨案需要弄一些技能
    if  mapID == 1001 and LOCAL_CHAR then

        if LOCAL_CHAR:GetPro() == 11 then

            skillIDList = { 1011, 1021,1031, nil, nil};
        elseif LOCAL_CHAR:GetPro() == 21 then

            skillIDList = { 2021, 2011,2031,nil,nil};
        elseif LOCAL_CHAR:GetPro() == 31 then

            skillIDList = { 3011, 3021,3031,nil,nil};
        elseif LOCAL_CHAR:GetPro() == 41 then

            skillIDList = { 4021, 4011,4031,nil,nil};
        end;
        skillLevelList = {1,1,1,1,1};
    else
        if tmpSkillInfo then
            skillIDList, skillLevelList = unpack(tmpSkillInfo, 2);
        else
            skillIDList, skillLevelList = MartialArtsManager.GetSkillList();
            if not skillIDList then  return end;
        end;

    end;



    if tmpSkillInfo then
        normalAttackList = tmpSkillInfo[1];
    else
        if LOCAL_CHAR:GetPro() == 11 then
            normalAttackList = {1001,1002,1003,1004};
        elseif LOCAL_CHAR:GetPro() == 21 then
            normalAttackList = {2001,2002,2003,2004};
        elseif LOCAL_CHAR:GetPro() == 31 then
            normalAttackList = {3001,3002,3003, 3004};
        elseif LOCAL_CHAR:GetPro() == 41 then
            normalAttackList = {4001,4002,4003,4004};
        end;
    end;


    local skillNum = #skillIDList;

    skillList = {};
    idToIndex = {};
    for i = 1,skillNum do
        local skillConfig = SkillManager.GetSkillConfig(skillIDList[i]);
        -- if not skillConfig then
        --     --error("cannot find skill config "..skillIDList[i]);
        -- end;
        skillList[i] = skillConfig;
        idToIndex[skillIDList[i]] = i;
        idToLevel[skillIDList[i]] = skillLevelList[i];

    end

    SkillButtonPanel.RefreshButtons();
end;

function KingOfFighters.LoadSkills()

    do return end;
    --这里再根据下发的包 填充 技能列表
    local skillIDList = {};
    if LOCAL_CHAR == nil then return end
    if LOCAL_CHAR:GetPro() == 11 then
        normalAttackList = {1001,1002,1003,1004};
        skillIDList = { 1011, 1031,1021,1101, 500203};
    elseif LOCAL_CHAR:GetPro() == 21 then
        normalAttackList = {2001,2002,2003,2004};
        skillIDList = { 2011, 2031,2021,2101,500201};
    elseif LOCAL_CHAR:GetPro() == 31 then
        normalAttackList = {3001,3002,3003, 3004};
        skillIDList = { 3021, 3031,3011,3101,500202};
    elseif LOCAL_CHAR:GetPro() == 41 then
        normalAttackList = {4001,4002,4003,4004};
        skillIDList = { 4021, 4031,4011,4101,500204};
    end;

    local skillNum = #skillIDList;

    skillList = {};
    idToIndex = {};
    for i = 1,skillNum do
        local skillConfig = SkillManager.GetSkillConfig(skillIDList[i]);
        if not skillConfig then
            --error("cannot find skill config "..skillIDList[i]);
        end;
        skillList[i] = skillConfig;
        idToIndex[skillIDList[i]] = i;

    end
end;

function  KingOfFighters.GetAllSkillList()
    return skillList, normalAttackList;
end

function KingOfFighters.SetPro(pro)
    KingOfFighters.LoadSkills();
end;

function KingOfFighters.OnUserInput()

    lastUserOperTime = Time.timeSinceLevelLoad;
end

function KingOfFighters.GetUserLastOperTime()
    return lastUserOperTime;
end

function KingOfFighters.ResetLastOperTime()
    lastUserOperTime = 0;
end

function KingOfFighters.GetSkillLevel(skillID)
    local skillConfig = SkillManager.GetSkillConfig(skillID);
    if not skillConfig then return 1 end;

    if skillConfig.normalattack then
        local roleLevel = LOCAL_CHAR:GetLevel();
        -- 这里是个很特别的逻辑：仙道秘法系统会增加普通攻击的等级
        local extraLvl  = ArcaneManager.GetNormalSkillExtraLvl();

        if roleLevel < 1000 then
            return math.min(math.ceil(roleLevel / 3), 50) + extraLvl;
        elseif roleLevel < 2000 then
            roleLevel = roleLevel - 1000;
            return math.min(math.ceil((roleLevel+20) / 3), 50) + extraLvl;
        elseif roleLevel < 3000 then
            roleLevel = roleLevel - 2000;
            return math.min(math.ceil((roleLevel+40) / 3), 50) + extraLvl;
        else
            return 50 + extraLvl;
        end;
    end;

    return idToLevel[skillID] or 1;


end;

function KingOfFighters.OnRsp()
    waitingRsp = false;
end;


function KingOfFighters.SetTmpSkillInfo(info)
    tmpSkillInfo = info;
    this.ReloadSkills(true);
    KingOfFighters.RefreshAllCD()
end;



-----------------------------------------------------------------trace target
local currTraceTarget = nil;
local currTraceJoyStickDir = nil;
local currTraceSkill = 0;
local currTraceDistance = 999;
function KingOfFighters.SetTraceTarget(actor, distance, skill)
    currTraceTarget = actor;
    currTraceDistance = distance or 999;
    --currTraceDistance = currTraceDistance + actor:GetHitRange() - 0.3
    Util.LogError("fuck distrance = " .. currTraceDistance)
    if actor then
        currTraceJoyStickDir = JoyStickPanel.GetLastDir();
    else
        currTraceJoyStickDir = nil;
    end;

    currTraceSkill = skill;
end;

function KingOfFighters.StopTrace()
    currTraceTarget = nil;
    currTraceJoyStickDir = nil;
    currTraceDistance = 999;
    currTraceSkill = 0;
end;

function KingOfFighters.GetTraceJoyStickDir()
    return currTraceJoyStickDir;
end;
local lastTraceMoveTime = 0;
function KingOfFighters.UpdateTrace()
    if not currTraceTarget then return end ;
    if not LOCAL_CHAR:IsEnemy(currTraceTarget) or currTraceTarget:IsDead() or currTraceTarget:IsHide() then --当追踪目标状态变化，及时停止追踪
        KingOfFighters.StopTrace();
        return
    end
    local distance = Vector3.Distance(LOCAL_CHAR:GetPos(), currTraceTarget:GetPos());
    if distance  <= currTraceDistance  then
        Util.LogError("getfucke")
        LOCAL_CHAR:LookAt(currTraceTarget);
        --KingOfFighters.OnClickNormalAttack();
        KingOfFighters.CastSkill(currTraceSkill, {});
        KingOfFighters.StopTrace();
    else
        if not LOCAL_CHAR:IsMoving() then
            lastTraceMoveTime = Time.unscaledTime
            LOCAL_CHAR:TryMoveTo(currTraceTarget:GetPos())
        else

            if Time.unscaledTime > lastTraceMoveTime + 1 then
                LOCAL_CHAR:TryMoveTo(currTraceTarget:GetPos())
                lastTraceMoveTime = Time.unscaledTime
            end;
        end;

    end;

end;

function KingOfFighters.OnActorDead(actor)
    if actor == lockTargetV2 then
        KingOfFighters.ResetTargetV2()
    end;
end;

function KingOfFighters.LockTargetV2(target)
    lockTargetV2 = target;
end;

function KingOfFighters.OnActorDel(key, actor)
    if actor == lockTargetV2 then
        KingOfFighters.ResetTargetV2()
    end;
end;

function KingOfFighters.GetTargetV2()
    return lockTargetV2
end;
function KingOfFighters.ResetTargetV2()
    if AutoFightManager.IsAutoFighting() then return end;
    lockTargetV2 = nil;
end;
function KingOfFighters.TryReGetTargetV2(dis)

    lockTargetV2 = KingOfFighters.GetNearstTargetV2(dis or 5, true)
    return lockTargetV2;
end;
function KingOfFighters.GetNearstTargetV2(range, playerFirst)
    local ret = nil;
    local sqrDistance = 0;
    local sqrRange = range * range;
    local funcCheck = function (id,actor)


        if actor:IsDead() then return false end;
        if actor:IsHide() then return false; end; --藏起来了的 忽略
        if actor:GetFuncType() == NpcFuncType_FreeFight then return false; end; --箱子罐子  先忽略
        if not actor:IsEnemy(LOCAL_CHAR) then return false end;

        local currSqrDistance = Vector3.SqrDistance(LOCAL_CHAR:GetPos(), actor:GetPos());

        if currSqrDistance > sqrRange then return false end;

        if not ret then ret = actor; sqrDistance = currSqrDistance; return false; end;


        if  ret:GetType() ~= actor:GetType() and actor:GetType() ==  KingOfFighters.firstChooseTargetType then
            ret = actor;
            sqrDistance = currSqrDistance;
            return false;
        end;

        if  ret:GetType() ~= actor:GetType() and ret:GetType() ~=  KingOfFighters.firstChooseTargetType then
            if currSqrDistance < sqrDistance  then
                ret = actor;
                sqrDistance = currSqrDistance
            end;
        end

        if ret:GetType() == actor:GetType() then
            if currSqrDistance < sqrDistance  then
                ret = actor;
                sqrDistance = currSqrDistance
            end;
        end

    end;
    ActorManager.EnumActors(funcCheck);
    return ret;
end;
--找一个最虚弱的友方
function KingOfFighters.FindWeakestFriend(range)
    local ret = LOCAL_CHAR;
    local hp = LOCAL_CHAR:GetHp()/LOCAL_CHAR:GetMaxHp();

    local funcCheck = function (id,actor)

        if actor:GetType() ~= ActorType_Player then return false end;
        if actor:IsDead() then return false end;
        if actor:IsEnemy(LOCAL_CHAR) then return false end;

        local currHp = actor:GetHp()/actor:GetMaxHp();
        if currHp < hp then
            ret = actor;
            hp = currHp
        end;
    end;
    ActorManager.EnumActors(funcCheck);
    return ret;
end;
