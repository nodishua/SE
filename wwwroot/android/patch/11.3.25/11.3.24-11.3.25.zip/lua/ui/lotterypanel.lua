LotteryPanel = UIManager.AddPanel("Lottery", "Normal", true)
LotteryPanel:SetType(PanelType.Child);

--OpenPanel("Lottery")
local _this = LotteryPanel

local _pointer = nil
local _pointerBack = nil
local _pointerFront = nil
local _content = nil
local _valueContent = nil
local _rewardBtnList = {}
local _valueRewardList = nil
local _widgetScript = nil
local _numberText = nil
local _btnStart = nil
local _btnGet = nil
local _btnGot = nil
local _btnRedraw = nil
local _btnDraw = nil
local _buyEffect = nil
local _btnBuy = nil
local _slider = nil
local _timesText = nil
local _msgText = nil
local _msgNode = nil
local _buyTipText = nil
local _redrawTipText = nil
local _redrawTipIcon = nil
local _chosenImage = nil
local _keyImage = nil
local _bonus = {}
local _keyFlagList = {}
local _desList = {}
local _toggleList = {}
local _msgSeqence = nil
local _maxRewardNum = 12
local _maxValuedRewardNum = 15
local _size = 85
local _btnSize = 80
local _radius = 190
local _firstOpen = true

local _startShowParValue = 1

local _colors = {21,22,23}
local _hasShown = false
local _rotating = false
local _rotatongAnim = nil

local _allRewardPage = nil
local _getRewardPage = nil
local _lock = nil
local _imageBG = nil

local _uiParList = {}
local _uiParIsShowList = {}

local bgName = {
    [1] = "BigIcon01_007",
    [2] = "BigIcon01_006",
    [3] = "BigIcon01_005",
}

---------------------------------------------------------------------------
function LotteryPanel.Init()
end

function LotteryPanel.OnCreate(obj)
    subGetAsyncImage(_this._trans, "Node_Main").spriteId = "BigIcon03_007"

    _pointer = child(_this._trans, "Node_Main/Image_Table/Node_Pointer")
    _content = child(_this._trans, "Node_Main/Image_Table/Node_Rewards")

    _imageBG = subGetAsyncImage(_this._trans, "Node_Main/Image_Table/Image_Bg")
    -- _imageDepend = subGetRes(_this._trans, "Node_Main/Image_Table/Image_Bg")
    
    _numberText = subGetText(_this._trans, "Node_Main/Node_Toggle/Image_KeyNumber/Text")

    _btnBuy = subGetAsyncButton(_this._trans, "Node_Main/Node_Toggle/Button_Buy")
    _msgText = subGetText(_this._trans, "Node_Main/Image_Lucky/Text")
    _msgNode = child(_this._trans, "Node_Main/Image_Lucky")
    _slider = subGetSlider(_this._trans, "Node_Main/Node_Bonus/Slider")
    _timesText = subGetText(_this._trans, "Node_Main/Node_Bonus/Text_Number/Text")
    _buyTipText = subGetText(_this._trans, "Node_Main/Node_Toggle/Text_BuyTip")

    _chosenImage = subGetRectTrans(_this._trans, "Node_Main/Image_Table/Node_Rewards/Image_Chosen")
    _keyImage = subGetAsyncImage(_this._trans, "Node_Main/Node_Toggle/Image_KeyNumber/Image")
    _widgetScript = _this:FindChildComponent("Node_Main/Image_Table/Node_Rewards", "UIWidgetList")
    _btnStart = subGetAsyncButton(_this._trans, "Node_Main/Image_Table/Button_Start")
    _buyEffect = child(_this._trans, "Node_Main/Node_Toggle/Image_KeyNumber/UI_choujiangtexiao_bao")

    _redrawTipText = subGetText(_this._trans, "GetReward/Button_ReStart/Text_Tip")
    _redrawTipIcon = subGetAsyncImage(_this._trans, "GetReward/Button_ReStart/Image_Coin")
    _lock = subGetRectTrans(_this._trans,"Lock")

    _this._behaviour:AddClick("Node_Main/Image_Table/Button_Start", _this.OnBtnStartClicked)
    _this._behaviour:AddClick("Node_Main/Node_Toggle/Button_Buy", _this.OnBtnBuyClicked)
    _this:AddClick("Node_Main/Node_Toggle/Image_KeyNumber/Image", _this.OnKeyClicked)

    _this:AddClick("Node_Main/Button_ShowAll",_this.ShowAllReward)
    _this:AddClick("AllReward/Image_Bg/Btn_Exit",_this.CloseAllReward)

    _valueContent = subGet(_this._trans, "AllReward/Scroll_ValueReward/Viewport/Content", "UIWidgetList")

    _allRewardPage = subGetRectTrans(_this._trans,"AllReward")
    _getRewardPage = subGetRectTrans(_this._trans,"GetReward")

    _btnGet = subGetAsyncButton(_this._trans, "GetReward/Button_Get")
    _btnRedraw = subGetAsyncButton(_this._trans, "GetReward/Button_ReStart")
    -- _btnDraw = subGetAsyncButton(_this._trans, "Node_Main/Image_Result/Button_Start")
    _btnGot = child(_this._trans, "GetReward/Node_Got/RewardCircleItem")
    _this._behaviour:AddClick("GetReward/Button_Get", _this.OnBtnGetClicked)
    _this._behaviour:AddClick("GetReward/Button_ReStart", _this.OnBtnRedrawClicked)
    -- _this._behaviour:AddClick("Node_Main/Image_Result/Button_Start", _this.OnBtnStartClicked)


    for i = 1, 3 do
        _this._behaviour:AddToggle("Node_Main/Node_Toggle/Toggle"..i, _this.OnToggleClicked, i)
        _toggleList[i] = subGetAsyncToggle(_this._trans,"Node_Main/Node_Toggle/Toggle"..i)
        _keyFlagList[i] = child(_this._trans, "Node_Main/Node_Toggle/Toggle"..i.."/Flag")
        _desList[i] = subGetRectTrans(_this._trans, "Node_Main/Des" .. i)
    end

    for i = 1, 2 do
        LotteryManager.ReqGetRewardPool(i)
    end

    for i = 1, _maxRewardNum do
        _rewardBtnList[i] = child(_this._trans, "Node_Main/Image_Table/Node_Rewards/RewardItem"..i)
    end
    _this.SetRewardBtnListLayOut()

    for i = 1, 4 do
        _bonus[i] = {}
        _bonus[i].rewardToggle = subGetAsyncToggle(_this._trans, "Node_Main/Node_Bonus/Slider/Toggle"..i)
        _bonus[i].conditionText = subGetText(_this._trans, "Node_Main/Node_Bonus/Slider/Toggle"..i.."/Label")
        _bonus[i].getBtn = subGetAsyncButton(_this._trans, "Node_Main/Node_Bonus/Slider/Toggle"..i.."/Button")
        _bonus[i].rednode = subGetRectTrans(_this._trans, "Node_Main/Node_Bonus/Slider/Toggle"..i.."/Flag")
        _bonus[i].background = subGetAsyncImage(_this._trans, "Node_Main/Node_Bonus/Slider/Toggle"..i.."/Background")
        _this._behaviour:AddClick("Node_Main/Node_Bonus/Slider/Toggle"..i.."/Button", _this.OnBonusClicked, i)
        _this._behaviour:AddClick("Node_Main/Node_Bonus/Slider/Toggle"..i.."/Background", _this.OnBonusCheckBtnClicked, i)
    end

    _this.RefreshBonusProgress()
    LotteryPanel.RefreshBonus()

end

function _this.OnReset()    
    _pointer = nil
    _pointerBack = nil
    _pointerFront = nil
    _content = nil
    _valueContent = nil
    _rewardBtnList = {}
    _valueRewardList = nil
    _widgetScript = nil
    _numberText = nil
    _btnStart = nil
    _btnGet = nil
    _btnGot = nil
    _btnRedraw = nil
    _btnDraw = nil
    _buyEffect = nil
    _btnBuy = nil
    _slider = nil
    _timesText = nil
    _msgText = nil
    _msgNode = nil
    _buyTipText = nil
    _redrawTipText = nil
    _redrawTipIcon = nil
    _chosenImage = nil
    _keyImage = nil
    _bonus = {}
    _keyFlagList = {}
    _desList = {}
    _toggleList = {}
    _msgSeqence = nil
    _rotatongAnim = nil
    _allRewardPage = nil
    _getRewardPage = nil
    _lock = nil
    _imageBG = nil
    _uiParList = {}
    _uiParIsShowList = {}
end

function LotteryPanel.OnSelfShow()
    BindInOpenServerActivityPanel(_this:GetName(), _this._trans)
    _hasShown = true
    _firstOpen = false
    _lock.gameObject:SetActive(false)
    _this:ToTop()
    local curTy = LotteryManager.GetPoolType()
    LotteryManager.RegisterListener()
    for i = 1,3 do
        LotteryManager.SetValuedRewards(i)
        _toggleList[i].isOn = (i == curTy)
    end
    _this.ShowLuckyMsg()
    _this.InitValuedRewards()
    _this.SetTableStyle()
    _this.ResetTableRotation()
    _this.InitKeyNumber()
    _this.InitRewardBtn()
    _this.RefreshRedPoints()
    _this.RefreshBonusState()
    _this.RefreshDes(curTy)
    _this.RefreshBonusProgress()
end

function LotteryPanel.OnSelfHide()
    _hasShown = false
    _buyEffect.gameObject:SetActive(false)
    if _msgSeqence then
        DoTweenExtensions.Kill(_msgSeqence, true)
    end
    if _rotatongAnim then
        DoTweenExtensions.Kill(_rotatongAnim, true)
        _rotatongAnim = nil
    end
    LotteryManager.RemoveListener()
    LotteryManager.ClearValuedPool()
    --LotteryManager.ReqGetAllRewards()
end
---------------------------------------------------------------------------
function LotteryPanel.SetRewardBtnListLayOut()
    if _rewardBtnList then
        local rad = 360/_maxRewardNum
        for i= 1, _maxRewardNum do
            local reward = _rewardBtnList[i]
            local rectTrans = subGetRectTrans(reward)
            rectTrans.sizeDelta = Vector2.New(_btnSize, _btnSize)
            reward.transform.localPosition = Vector3.New(math.sin(math.rad(rad*(i-1)))*_radius, math.cos(math.rad(rad*(i-1)))*_radius, 0)
        end
    end
end
--:SetAsLastSibling()
function LotteryPanel.InitRewardBtn()
    if _hasShown == false then
        return
    end
    _this.CloseGetReward()
    _btnStart.gameObject:SetActive(true)
    _btnGet.interactable = true
    _btnRedraw.interactable = true
    if LotteryManager.GetPoolType() == LOTTERY_TYPE.SLIVER then
        -- _btnBuy.gameObject:SetActive(true)
        _btnBuy.gameObject.transform.localPosition = Vector3.New(17.2,-114.3,0)
        local value, name = LotteryManager.GetSliverBuyConsume()
        _buyTipText.text = _I18N("lottery_need")..value..name
    else--  0 -276 0 
        _buyTipText.text = ""
        _btnBuy.gameObject.transform.localPosition = Vector3.New(9999,-114.3,0)
        -- _btnBuy.gameObject:SetActive(false)
    end
    _btnRedraw.gameObject:SetActive(false)
    -- _btnDraw.gameObject:SetActive(true)
    _this.ResetTableRotation()
    local rewards = LotteryManager.GetRewardPool()
    if _rewardBtnList and rewards and #rewards > 0 then
        local gotList= LotteryManager.GetGarbageRewards()
        for i =1, _maxRewardNum  do
            local info = {
               mode     = rewards[i].mode_item,
               id       = rewards[i].id_item,
               num      = rewards[i].number_item,
               param    = 0,
            }
            if rewards[i].quality then
                info.quality = rewards[i].quality
            end
            _rewardBtnList[i].gameObject:SetActive(true)
            
            _uiParList[i]       = child(_rewardBtnList[i].transform, "Choujiangzhuanpan")
            _uiParIsShowList[i] = rewards[i].valued >= _startShowParValue
            _uiParList[i].gameObject:SetActive(_uiParIsShowList[i])

            local multi = rewards[i].multiple_item;
            if AppConst.ReleaseCompany == "Korea" and multi > 1 then
                multi = "x"..multi;
            end
            RewardSamplePanel.DoShowSingleReward(_rewardBtnList[i].transform, info, _this, multi, 2)

            -- Util_SetImage(_rewardBtnList[i].transform,"Item","baikuai2")

            local cover = child(_rewardBtnList[i].transform, "Image_Cover")
            if table.contains(gotList, i-1) then
                cover.transform:SetAsLastSibling()
                cover.gameObject:SetActive(true)
                local ima = subGetAsyncImage(_rewardBtnList[i].transform, "Item")
                ima.spriteId = QUALITY_CIRCLE_SPRITE_BACK[0]
                -- Util_SetImage(_rewardBtnList[i].transform,"00_0_60")
            else    
                cover.gameObject:SetActive(false)
            end
        end
    elseif rewards == nil then
        --error("Can't get config of lottery.")    
    end

    if LotteryManager.GetRewardIndex() ~= nil then
        _btnStart.gameObject:SetActive(false)
        local limitID = {CONSUME_FOR_RESTRICT_D[1].charStateLimitID,CONSUME_FOR_RESTRICT_D[2].charStateLimitID}
        if LotteryManager.GetPoolType() == LOTTERY_TYPE.GOLDEN then
            _btnRedraw.gameObject:SetActive(false)
        else
            _btnRedraw.gameObject:SetActive(charStateLimitID==nil or CharStateLimitManager.IsStateLimitOk(limitID))
        end
        -- _btnDraw.gameObject:SetActive(false)
        _this.ShowRewardGot()
        _pointer.transform.localRotation = Quaternion.Euler(_this.GetTableRotation())
        local rad = 360/_maxRewardNum
        _chosenImage.transform.localRotation = Quaternion.Euler(_this.GetTableRotation())
        -- _chosenImage.transform:SetAsLastSibling()
        _chosenImage.gameObject:SetActive(true)
        _rotatongAnim = nil
    else
        _this.CloseGetReward()
    end
    LotteryPanel.ShowRedrawTip()

    _this.CloseAllReward()
end

function LotteryPanel.ShowGarbageReward()
    local gotList= LotteryManager.GetGarbageRewards()
    for i =1, _maxRewardNum  do
        local cover = child(_rewardBtnList[i].transform, "Image_Cover")
        local textO = child(_rewardBtnList[i].transform, "Text")
        if table.contains(gotList, i-1) then
            -- _rewardBtnList[i].transform:GetComponent("Image").sprite = "00_0_60"
            local ima = subGetAsyncImage(_rewardBtnList[i].transform, "Item")
            ima.spriteId = QUALITY_CIRCLE_SPRITE_BACK[0]
            -- Util_SetImage(_rewardBtnList[i].transform,"00_0_60")
            cover.transform:SetAsLastSibling()
            textO.transform:SetAsLastSibling()
            cover.gameObject:SetActive(true)
        else    
            cover.gameObject:SetActive(false)
        end
    end
end

function LotteryPanel.InitValuedRewards()
    local rewards = LotteryManager.GetCurValuedPool()
    _maxValuedRewardNum = #rewards
    _valueContent:SetActiveItemNumEx(_maxValuedRewardNum, _this.OnValueItemLoaded, rewards)
end

function LotteryPanel.OnValueItemLoaded(trans, index, list)
	if _this:IsReseted() then return end
    local reward = list[index+1]
    if reward and CharStateLimitManager.IsStateLimitOk(reward.state_limit) and CharStateLimitManager.CheckTimeLimiteState(SyncManager.GetServerTime(), reward.time_limit) then
        trans.gameObject:SetActive(true)
        RewardSamplePanel.DoShowSingleReward(trans, reward, _this, reward.param,2)
        local uiPar = child(trans, "Choujiangzhuanpan")
        local isshowpar = reward.valued >= _startShowParValue
        uiPar.gameObject:SetActive(isshowpar)
    else
        trans.gameObject:SetActive(false)
    end
end

function LotteryPanel.InitKeyNumber()
    if _hasShown == false then return end
    _numberText.text = "X"..LotteryManager.GetKeyNumber()
end

function LotteryPanel.RefreshRedPoints()
    if _hasShown == false then
        return
    end
    for i = 1, 3 do
        _keyFlagList[i].gameObject:SetActive(LotteryManager.CheckKeyFlag(i))
    end
end

function LotteryPanel.StartRotateTable()
    if not _this:IsCreated() or not _this:IsVisible() then return end
    _btnStart.gameObject:SetActive(false)
    -- _btnDraw.gameObject:SetActive(false)
    local limitID = {CONSUME_FOR_RESTRICT_D[1].charStateLimitID,CONSUME_FOR_RESTRICT_D[2].charStateLimitID}
    if LotteryManager.GetPoolType() == LOTTERY_TYPE.GOLDEN then
        _btnRedraw.gameObject:SetActive(false)
    else
        _btnRedraw.gameObject:SetActive(charStateLimitID==nil or CharStateLimitManager.IsStateLimitOk(limitID))
    end
    _btnGet.interactable = false
    _btnRedraw.interactable = false

    _lock.gameObject:SetActive(true)
    local cb = function()
        _btnGet.interactable = true
        _btnRedraw.interactable = true
        LotteryPanel.ShowRedrawTip()
        local rad = 360/_maxRewardNum
        _chosenImage.transform.localRotation = Quaternion.Euler(_this.GetTableRotation())
        -- _chosenImage.transform:SetAsLastSibling()
        _chosenImage.gameObject:SetActive(true)
        _rotatongAnim = nil
        local ca = function()
            if _hasShown == false then
                return;
            end
            _lock.gameObject:SetActive(false)
            _this.ShowRewardGot()
        end
        Timer.New(ca,1,1,false):Start()
    end
    _this.ResetTableRotation()
    --DoTweenShort46.DOFade(_pointerBack, 1, 0.1)
    --DoTweenShort46.DOFade(_pointerFront, 0, 0.1)
    local sequence = DoTween.Sequence()
    local rotation = _this.GetTableRotation()
    local rotate = DoTweenShort.DOLocalRotate(_pointer.transform, rotation, 1, DoTweenRotateMode.Fast)
    DoTweenHelper.SetEase(rotate, DoTweenEase.OutQuad)
    --DoTweenHelper.SetEase(rotate1, DoTweenEase.OutQuad)
    DoTweenSetting.Append(sequence, rotate)
    --DoTweenSetting.Join(sequence, rotate1)
    DoTweenSetting.AppendCallback(sequence, DelegateFactory.DG_Tweening_TweenCallback(cb))
    _rotatongAnim = sequence
end

function LotteryPanel.SetTableStyle()
    local poolType = LotteryManager.GetPoolType()
    _keyImage.spriteId = LOTTERY_KEY_IMAGE[poolType]
end

function LotteryPanel.ResetTableRotation()
    --_pointerBack.alpha = 0
    --_pointerFront.alpha = 1
    _chosenImage.gameObject:SetActive(false)
    _pointer.transform.localRotation = Quaternion.Euler(Vector3.zero)
end

function LotteryPanel.GetTableRotation()
    local rad = 360/_maxRewardNum
    return Vector3.New(0,0,-3600-(rad*(LotteryManager.GetRewardIndex())))
end

function LotteryPanel.ShowRewardGot()  
    if _hasShown == false or _btnGot == nil then
        return
    end 
    _this.ShowGetReward()
    local index = LotteryManager.GetRewardIndex()
    if index then
        index = tonumber(index)+1
    end
    local pool = LotteryManager.GetRewardPool()
    if index and pool and pool[index] then
        local info = {
           mode=pool[index].mode_item,
           id=pool[index].id_item,
           num=pool[index].number_item,
           param=0,
        }
        RewardSamplePanel.DoShowSingleReward(_btnGot.transform, info, _this, pool[index].multiple_item,2)
    else
        RewardSamplePanel.DoShowSingleReward(_btnGot.transform, nil, _this,2)
    end
end

function LotteryPanel.ShowRedrawTip()
    local consumeIDs = {CONSUME_FOR_RESTRICT_D[1].consumeID,CONSUME_FOR_RESTRICT_D[2].consumeID, CONSUME_FOR_RESTRICT_D[3].consumeID}
    local times = LotteryManager.GetRedrawTimes()-1
    if times < 0 then
        _redrawTipText.text = ""
        _redrawTipIcon.spriteId = "0"
        _btnRedraw.gameObject:SetActive(true)
        _btnGet.gameObject.transform.localPosition = Vector3.New(-167.6,6.6,0)
    elseif times >= (_maxRewardNum - 1) then
        _redrawTipText.text = ""
        _redrawTipIcon.spriteId = "0"
        _btnRedraw.gameObject:SetActive(false)
        _btnGet.gameObject.transform.localPosition = Vector3.New(-167.6,38.8,0)
        -- _btnRedraw.interactable = false
    else
        local cfg = ConsumeManager.BuildConsumeData(consumeIDs[LotteryManager.GetPoolType()], times)
        -- _redrawTipText.text = _I18N("xiaohao")..cfg[1].Value
        _redrawTipText.text = cfg[1].Value
        _redrawTipIcon.spriteId = cfg[1].LittleIcon
    end
end

function LotteryPanel.ShowLuckyMsg()
    if _hasShown == false then
        return
    end
    local msg = LotteryManager.GetLuckyMsg()
    if msg and not _msgSeqence then
        _msgNode.gameObject:SetActive(true)
        local poolType = msg.draw_type_
        local name = msg.role_name_..""
        local quality = _C(_colors[poolType]).._I18N("lottery_type"..poolType).._CE()
        local item = _C(0)
        if COIN_CFG[msg.item_id_] then
            item = item..COIN_CFG[msg.item_id_].name.."("..msg.luck_num_.._I18N("lottery_multiple")..")".._CE()
        else
            local itemConfig = ItemManager.GetTypeCfgById(msg.item_id_)
            if itemConfig then
                item = _C(70 + itemConfig.Color)
                item = item..itemConfig.Name.."("..msg.luck_num_.._I18N("lottery_multiple")..")".._CE()
            end
        end
        
        local text = ""
        if msg.redraw_time_ == 0 then
            text = string.format(_I18N("lottery_lucky"), name, quality, item)
        else
            text = string.format(_I18N("lottery_lucky_re"), name, quality, msg.redraw_time_, item)            
        end
        _msgText.text = text
        _msgText.transform.localRotation = Quaternion.Euler(Vector3.New(270,0,0))
        _msgSeqence = DoTween.Sequence()
        local rotate1 = DoTweenShort.DOLocalRotate(_msgText.transform, Vector3.New(360,0,0),0.3,DoTweenRotateMode.Fast)
        local rotate2 = DoTweenShort.DOLocalRotate(_msgText.transform, Vector3.New(90,0,0),0.3,DoTweenRotateMode.Fast)
        DoTweenHelper.SetDelay(rotate2, 3)
        DoTweenSetting.Append(_msgSeqence, rotate1)
        DoTweenSetting.Append(_msgSeqence, rotate2)
        local callback = function()
            _msgSeqence = nil
            _this.ShowLuckyMsg()
        end
        DoTweenSetting.AppendCallback(_msgSeqence, DelegateFactory.DG_Tweening_TweenCallback(callback))
    else
        _msgNode.gameObject:SetActive(false)
        LotteryManager.ReqGetLuckyMsg()
    end
end

function LotteryPanel.RefreshBonusProgress()
    if _hasShown == false then
        return
    end
    local times, per = LotteryManager.GetProgress()
    local space = ""
    if AppConst.ReleaseCompany == "Vietnam" then
        space = " "
    end
    _timesText.text = times..space.._I18N("lottery_times")
    _slider.value = per
end

function LotteryPanel.RefreshBonus()
    local poolType = LotteryManager.GetPoolType()
    local bonus = CHOUJIANG_BONUS[poolType] 
    local condition = CHOUJIANG_TIMES[poolType]
    for i = 1, 4 do
        --RewardSamplePanel.ShowSingleReward(_bonus[i].rewardBtn, bonus[i])
        _bonus[i].conditionText.text = condition[i].._I18N("lottery_times")
    end
end

function LotteryPanel.RefreshBonusState()
    if _hasShown == false then
        return
    end
    for i = 1, 4 do
        _bonus[i].rewardToggle.isOn = LotteryManager.IsBonusBeingGot(i)
        _bonus[i].background.enabled = not LotteryManager.CheckBonusFlag(i)
        _bonus[i].getBtn.gameObject:SetActive(LotteryManager.CheckBonusFlag(i))
        _bonus[i].rednode.gameObject:SetActive(LotteryManager.CheckBonusFlag(i))
    end   
end

function LotteryPanel.ShowBuyEffect()
    _buyEffect.gameObject:SetActive(false)
    _buyEffect.gameObject:SetActive(true)
end
---------------------------------------------------------------------------
function LotteryPanel.OnBtnStartClicked(obj)
    if LotteryManager.GetKeyNumber() > 0 then
        _this.ResetTableRotation()
        LotteryManager.ReqStartDraw()
    else
        local keyID = {322100001, 322100002, 322100003}
        SourcePanel.Show(2,keyID[LotteryManager.GetPoolType()])
        ShowErrorCode(1000008)
    end
end

function LotteryPanel.OnBtnGetClicked(obj)
    LotteryManager.ReqGetReward()
end

function LotteryPanel.OnBtnRedrawClicked(obj)

    local times = LotteryManager.GetRedrawTimes()-1
    local cfgList = {CONSUME_FOR_RESTRICT_D[1],CONSUME_FOR_RESTRICT_D[2]}
    local poolType = LotteryManager.GetPoolType()
    if CharStateLimitManager.IsStateLimitOk(cfgList[poolType].charStateLimitID) == false then
        PromptPanel.ShowErrorCodeStr(CharStateLimitManager.GetCheckFailedDesc(cfgList[poolType].charStateLimitID))
        return
    end
    if times >= 0 and times <= (_maxRewardNum - 1) then
        local cfg = ConsumeManager.BuildConsumeData(cfgList[poolType].consumeID, times)
 
        if poolType == 1 then
            ConsumeManager.CheckSliverIngotCost(cfg[1].Value, function()
                    _this.CloseGetReward()
                    LotteryManager.ReqReDraw()
                end, true, _this:GetName())
        elseif poolType == 2 or poolType == 3 then
            LotteryManager.ReqReDraw()
        end

    else
        _this.CloseGetReward()
        LotteryManager.ReqReDraw()    
    end
    
end

function LotteryPanel.OnBtnBuyClicked(obj)
    LotteryManager.ReqBuySliverKey()
end

function LotteryPanel.OnBtnExitClicked(obj)
    ClosePanel("Lottery")
end

function LotteryPanel.OpenSelf(index)
    local selectIndex = index or 1
    LotteryManager.SetPoolType(selectIndex)
    OpenServerActivityPanel.Open("Lottery")
end

function LotteryPanel.OnToggleClicked(obj, isOn, index)
    if isOn == false then
        return
    end
    if _rotatongAnim then
        DoTweenExtensions.Kill(_rotatongAnim, true)
        _rotatongAnim = nil
    end
    LotteryManager.SetPoolType(index)
    --LotteryManager.ReqGetAllRewards()
    _this.SetTableStyle()
    _this.InitRewardBtn()
    _this.InitValuedRewards()
    _this.InitKeyNumber()
    _this.RefreshBonusProgress()
    LotteryPanel.RefreshBonus()
    LotteryPanel.RefreshBonusState()
    _this.RefreshRedPoints()
    _this.RefreshDes(index)
end

function LotteryPanel.RefreshDes(index)
    local ind = index or 1
    for count = 1, 3 do
        _desList[count].gameObject:SetActive(ind == count)
    end
    _imageBG.spriteId = bgName[ind]-- = _imageDepend:GetSprite(bgName[ind])
end

function LotteryPanel.OnBonusClicked(obj, index)
    LotteryManager.ReqGetBonus(index)
end

function LotteryPanel.OnKeyClicked()
    local keyID = {322100001, 322100002, 322100003}
    -- local keyNumber = LotteryManager.GetKeyNumber()
    -- local str = _I18N("lib_own")..keyNumber
    SourcePanel.Show(2,keyID[LotteryManager.GetPoolType()])
    -- SourcePanel.Show(2,keyID[LotteryManager.GetPoolType()],function()
    --     ClosePanel("Lottery")
    -- end, str)
end

function LotteryPanel.OnHelpBtnClicked(obj)
    CommonHelpPanel.HelpBtn_OnClick(obj, COMMON_HELP_IDS.LOTTERY)
end

function LotteryPanel.OnBonusCheckBtnClicked(obj, index)
    local poolType = LotteryManager.GetPoolType()
    local bonus = CHOUJIANG_BONUS[poolType] 
    ScheduleBonusPanel.Show(bonus[index].title, bonus[index].id)
end

-------------------*******************************************************
function _this.ShowAllReward()
    _allRewardPage.gameObject:SetActive(true)
    for i =1, _maxRewardNum  do
        _uiParList[i].gameObject:SetActive(false)
    end
end
function _this.CloseAllReward()
    _allRewardPage.gameObject:SetActive(false)
    for i =1, _maxRewardNum  do
        if not _uiParList[i] then break end
        _uiParList[i].gameObject:SetActive(_uiParIsShowList[i] or false)
    end
end
function _this.ShowGetReward()
    if not IsNil(_getRewardPage) then
        _getRewardPage.gameObject:SetActive(true)
    end
end
function _this.CloseGetReward()
    if not IsNil(_getRewardPage) then
        _getRewardPage.gameObject:SetActive(false)
    end
end